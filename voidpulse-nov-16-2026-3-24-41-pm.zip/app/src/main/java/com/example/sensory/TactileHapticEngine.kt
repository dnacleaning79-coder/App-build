package com.example.sensory

import android.content.Context
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager

class TactileHapticEngine(context: Context) {

    private val vibrator: Vibrator? = try {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val manager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
            manager?.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        }
    } catch (_: Throwable) {
        null
    }

    @Volatile
    var isEnabled: Boolean = true

    private var lastCollisionTickMs = 0L
    private var lastVortexPulseMs = 0L

    fun tickParticleCollision(intensity: Float = 0.6f) {
        if (!isEnabled) return
        val now = System.currentTimeMillis()
        if (now - lastCollisionTickMs < 40L) return
        lastCollisionTickMs = now

        val amp = (intensity.coerceIn(0.15f, 1f) * 160).toInt().coerceIn(28, 255)
        vibrateOneShot(durationMs = 8L, amplitude = amp)
    }

    fun pulseVortexTouch(strength: Float = 0.8f) {
        if (!isEnabled) return
        val now = System.currentTimeMillis()
        if (now - lastVortexPulseMs < 70L) return
        lastVortexPulseMs = now

        val amp = (strength.coerceIn(0.25f, 1f) * 215).toInt().coerceIn(45, 255)
        vibrateOneShot(durationMs = 15L, amplitude = amp)
    }

    fun crystalShatterCrunch() {
        if (!isEnabled) return
        vibrateWaveform(
            timings = longArrayOf(0L, 16L, 18L, 24L, 20L, 35L),
            amplitudes = intArrayOf(0, 220, 0, 255, 0, 180)
        )
    }

    fun bumperBounceSnap() {
        if (!isEnabled) return
        vibrateWaveform(
            timings = longArrayOf(0L, 10L, 14L, 14L),
            amplitudes = intArrayOf(0, 240, 0, 150)
        )
    }

    fun snapUiButton() {
        if (!isEnabled) return
        vibrateWaveform(
            timings = longArrayOf(0L, 12L, 22L, 8L),
            amplitudes = intArrayOf(0, 210, 0, 125)
        )
    }

    fun epicModesButtonCascade() {
        if (!isEnabled) return
        vibrateWaveform(
            timings = longArrayOf(0L, 14L, 20L, 18L, 24L, 32L),
            amplitudes = intArrayOf(0, 155, 0, 225, 0, 255)
        )
    }

    fun coinHarvestTick() {
        if (!isEnabled) return
        vibrateWaveform(
            timings = longArrayOf(0L, 7L, 16L, 11L),
            amplitudes = intArrayOf(0, 130, 0, 195)
        )
    }

    fun celebrateUnlock() {
        if (!isEnabled) return
        vibrateWaveform(
            timings = longArrayOf(0L, 18L, 28L, 22L, 28L, 28L, 32L, 55L),
            amplitudes = intArrayOf(0, 145, 0, 190, 0, 230, 0, 255)
        )
    }

    private fun vibrateOneShot(durationMs: Long, amplitude: Int) {
        val vib = vibrator ?: return
        try {
            if (!vib.hasVibrator()) return
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vib.vibrate(VibrationEffect.createOneShot(durationMs, amplitude.coerceIn(1, 255)))
            } else {
                @Suppress("DEPRECATION")
                vib.vibrate(durationMs)
            }
        } catch (_: Throwable) {
        }
    }

    private fun vibrateWaveform(timings: LongArray, amplitudes: IntArray) {
        val vib = vibrator ?: return
        try {
            if (!vib.hasVibrator()) return
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vib.vibrate(VibrationEffect.createWaveform(timings, amplitudes, -1))
            } else {
                @Suppress("DEPRECATION")
                vib.vibrate(25L)
            }
        } catch (_: Throwable) {
        }
    }
}
