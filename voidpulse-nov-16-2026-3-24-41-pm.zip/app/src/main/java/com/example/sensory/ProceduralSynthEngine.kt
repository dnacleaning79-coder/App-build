package com.example.sensory

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import com.example.model.SoundSynthStyle
import kotlin.concurrent.thread
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin

class ProceduralSynthEngine {

    private class Voice(
        var active: Boolean = false,
        var freqHz: Float = 440f,
        var targetFreqHz: Float = 440f,
        var phase: Double = 0.0,
        var detunePhase: Double = 0.0,
        var subPhase: Double = 0.0,
        var envTime: Float = 0f,
        var duration: Float = 0.45f,
        var amplitude: Float = 0.25f,
        var harmonicMix: Float = 0.35f,
        var fmDepth: Float = 0f
    )

    private val sampleRate = 24000
    private val voices = Array(18) { Voice() }
    private val voiceLock = Any()

    // Lush cosmic echo/reverb circular delay line (~185ms echo)
    private val delaySamples = 4440
    private val delayLine = FloatArray(delaySamples)
    private var delayCursor = 0

    @Volatile
    var isEnabled: Boolean = true

    @Volatile
    var activeStyle: SoundSynthStyle = SoundSynthStyle.CELESTIAL_HARP

    @Volatile
    private var running = true
    private var audioThread: Thread? = null

    init {
        startSynthThread()
    }

    private fun startSynthThread() {
        audioThread = thread(start = true, isDaemon = true, name = "VoidPulseLushSynth") {
            var track: AudioTrack? = null
            try {
                val minBuf = AudioTrack.getMinBufferSize(
                    sampleRate,
                    AudioFormat.CHANNEL_OUT_MONO,
                    AudioFormat.ENCODING_PCM_16BIT
                ).coerceAtLeast(1024)

                track = AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_GAME)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                            .build()
                    )
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(sampleRate)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                            .build()
                    )
                    .setBufferSizeInBytes(minBuf * 2)
                    .setTransferMode(AudioTrack.MODE_STREAM)
                    .build()

                track.play()

                val chunkSize = 256
                val buffer = ShortArray(chunkSize)
                val dt = 1f / sampleRate.toFloat()
                val twoPi = 2.0 * PI

                while (running) {
                    if (!isEnabled) {
                        buffer.fill(0)
                        track.write(buffer, 0, chunkSize)
                        Thread.sleep(16)
                        continue
                    }

                    val style = activeStyle
                    synchronized(voiceLock) {
                        for (i in 0 until chunkSize) {
                            var dryMix = 0f
                            for (vIndex in voices.indices) {
                                val v = voices[vIndex]
                                if (!v.active) continue

                                v.envTime += dt
                                if (v.envTime >= v.duration) {
                                    v.active = false
                                    continue
                                }

                                v.freqHz += (v.targetFreqHz - v.freqHz) * 0.01f

                                // Crisp pluck attack + smooth warm exponential decay
                                val attack = (v.envTime / 0.004f).coerceAtMost(1f)
                                val decay = exp((-4.8f * v.envTime / v.duration).toDouble()).toFloat()
                                val env = attack * decay * v.amplitude

                                val mod = if (v.fmDepth > 0f) {
                                    sin(v.subPhase) * v.fmDepth
                                } else {
                                    0.0
                                }

                                // Chorus detuned dual-oscillator + octave shimmer + fifth harmonic
                                val mainOsc = sin(v.phase + mod).toFloat()
                                val chorusOsc = sin(v.detunePhase).toFloat() * 0.45f
                                val octave = sin(v.phase * 2.0).toFloat() * v.harmonicMix * 0.55f
                                val fifth = sin(v.phase * 1.498).toFloat() * (v.harmonicMix * 0.35f)

                                dryMix += (mainOsc + chorusOsc + octave + fifth) * env * 0.65f

                                val step = twoPi * v.freqHz / sampleRate
                                v.phase += step
                                if (v.phase > twoPi) v.phase -= twoPi
                                v.detunePhase += step * 1.0045
                                if (v.detunePhase > twoPi) v.detunePhase -= twoPi
                                v.subPhase += step * 0.5
                                if (v.subPhase > twoPi) v.subPhase -= twoPi
                            }

                            // Cosmic Echo Delay Buffer
                            val delayed = delayLine[delayCursor]
                            val wetMix = dryMix + delayed * style.echoFeedback
                            delayLine[delayCursor] = wetMix.coerceIn(-1.2f, 1.2f)
                            delayCursor = (delayCursor + 1) % delaySamples

                            val totalOut = dryMix + delayed * 0.36f
                            val clamped = (totalOut / (1f + kotlin.math.abs(totalOut * 0.6f))).coerceIn(-0.96f, 0.96f)
                            buffer[i] = (clamped * Short.MAX_VALUE).toInt().toShort()
                        }
                    }

                    track.write(buffer, 0, chunkSize)
                }
            } catch (_: Throwable) {
            } finally {
                try {
                    track?.stop()
                    track?.release()
                } catch (_: Throwable) {
                }
            }
        }
    }

    private fun allocateVoice(
        freqHz: Float,
        targetFreqHz: Float = freqHz,
        duration: Float = 0.42f,
        amplitude: Float = 0.20f,
        harmonicMix: Float = activeStyle.harmonicMix,
        fmDepth: Float = activeStyle.fmDepth
    ) {
        if (!isEnabled) return
        val scaledDuration = duration * activeStyle.decayMultiplier
        synchronized(voiceLock) {
            var target = voices.firstOrNull { !it.active }
            if (target == null) {
                target = voices.maxByOrNull { it.envTime / it.duration } ?: voices[0]
            }
            target.active = true
            target.freqHz = freqHz
            target.targetFreqHz = targetFreqHz
            target.phase = 0.0
            target.detunePhase = 0.0
            target.subPhase = 0.0
            target.envTime = 0f
            target.duration = scaledDuration
            target.amplitude = amplitude
            target.harmonicMix = harmonicMix
            target.fmDepth = fmDepth
        }
    }

    private var lastChimeMs = 0L

    fun triggerHarmonicChime(scale: FloatArray, normalizedY: Float, velocityBoost: Float = 0f) {
        if (!isEnabled || scale.isEmpty()) return
        val now = System.currentTimeMillis()
        if (now - lastChimeMs < 48L) return
        lastChimeMs = now

        val index = ((1f - normalizedY.coerceIn(0f, 1f)) * (scale.size - 1)).toInt()
            .coerceIn(0, scale.lastIndex)
        val baseFreq = scale[index]
        // Play fundamental + gentle harmonic third/fifth chord pluck
        allocateVoice(
            freqHz = baseFreq,
            targetFreqHz = baseFreq * 1.003f,
            duration = 0.48f,
            amplitude = 0.16f
        )
        if (velocityBoost > 0.12f && index + 2 < scale.size) {
            allocateVoice(
                freqHz = scale[index + 2],
                targetFreqHz = scale[index + 2],
                duration = 0.55f,
                amplitude = 0.11f
            )
        }
    }

    private var lastBassMs = 0L

    fun triggerBassPulse(intensity: Float = 1f) {
        if (!isEnabled) return
        val now = System.currentTimeMillis()
        if (now - lastBassMs < 105L) return
        lastBassMs = now

        val startFreq = 98f + 32f * intensity.coerceIn(0f, 1.5f)
        allocateVoice(
            freqHz = startFreq,
            targetFreqHz = 46f,
            duration = 0.42f,
            amplitude = (0.25f * intensity).coerceIn(0.10f, 0.34f),
            harmonicMix = 0.22f,
            fmDepth = 1.2f
        )
    }

    fun triggerCrystalShatterSound(comboCount: Int) {
        if (!isEnabled) return
        val pitchShift = (1f + (comboCount.coerceAtMost(12) - 1) * 0.06f)
        val chord = floatArrayOf(587.33f, 880.0f, 1174.66f, 1760.0f)
        chord.forEachIndexed { idx, f ->
            allocateVoice(
                freqHz = f * pitchShift,
                targetFreqHz = f * pitchShift * 1.015f,
                duration = 0.32f + idx * 0.08f,
                amplitude = 0.16f,
                harmonicMix = 0.65f,
                fmDepth = 0.85f
            )
        }
        allocateVoice(
            freqHz = 130f,
            targetFreqHz = 52f,
            duration = 0.30f,
            amplitude = 0.24f,
            harmonicMix = 0.2f,
            fmDepth = 1.4f
        )
    }

    fun triggerBumperDingSound(bumperIndex: Int) {
        if (!isEnabled) return
        val notes = floatArrayOf(523.25f, 659.25f, 783.99f, 987.77f, 1046.5f)
        val note = notes[bumperIndex % notes.size]
        allocateVoice(
            freqHz = note,
            targetFreqHz = note * 1.5f,
            duration = 0.26f,
            amplitude = 0.18f,
            harmonicMix = 0.7f,
            fmDepth = 0.9f
        )
    }

    fun triggerFireworkBurstSound() {
        if (!isEnabled) return
        allocateVoice(freqHz = 180f, targetFreqHz = 48f, duration = 0.45f, amplitude = 0.26f, harmonicMix = 0.3f, fmDepth = 1.8f)
        allocateVoice(freqHz = 659.25f, targetFreqHz = 1318.5f, duration = 0.38f, amplitude = 0.15f, harmonicMix = 0.6f)
        allocateVoice(freqHz = 987.77f, targetFreqHz = 1975.5f, duration = 0.44f, amplitude = 0.13f, harmonicMix = 0.6f)
    }

    fun triggerFeverOverdriveFanfare() {
        if (!isEnabled) return
        val fanfare = floatArrayOf(440f, 554.37f, 659.25f, 880f, 1108.73f, 1318.51f)
        fanfare.forEachIndexed { idx, freq ->
            allocateVoice(
                freqHz = freq * 0.99f,
                targetFreqHz = freq * 1.01f,
                duration = 0.55f + idx * 0.1f,
                amplitude = 0.18f,
                harmonicMix = 0.6f,
                fmDepth = 0.45f
            )
        }
    }

    fun triggerCrispUiClick(pitchMultiplier: Float = 1f) {
        if (!isEnabled) return
        allocateVoice(
            freqHz = 880f * pitchMultiplier,
            targetFreqHz = 1320f * pitchMultiplier,
            duration = 0.08f,
            amplitude = 0.20f,
            harmonicMix = 0.45f,
            fmDepth = 0.5f
        )
    }

    fun triggerEpicModesButtonSound() {
        if (!isEnabled) return
        allocateVoice(freqHz = 110f, targetFreqHz = 55f, duration = 0.38f, amplitude = 0.26f, harmonicMix = 0.2f, fmDepth = 1.1f)
        allocateVoice(freqHz = 440f, targetFreqHz = 442f, duration = 0.48f, amplitude = 0.17f)
        allocateVoice(freqHz = 554.37f, targetFreqHz = 556f, duration = 0.55f, amplitude = 0.16f)
        allocateVoice(freqHz = 659.25f, targetFreqHz = 662f, duration = 0.64f, amplitude = 0.16f)
        allocateVoice(freqHz = 880f, targetFreqHz = 1320f, duration = 0.34f, amplitude = 0.14f)
    }

    fun triggerCoinCollectSound() {
        if (!isEnabled) return
        allocateVoice(
            freqHz = 987.77f,
            targetFreqHz = 1479.98f,
            duration = 0.22f,
            amplitude = 0.14f,
            harmonicMix = 0.5f
        )
    }

    fun triggerUnlockFanfare() {
        if (!isEnabled) return
        val notes = floatArrayOf(523.25f, 659.25f, 783.99f, 1046.50f, 1318.51f)
        notes.forEachIndexed { idx, freq ->
            allocateVoice(
                freqHz = freq * (0.98f + idx * 0.005f),
                targetFreqHz = freq,
                duration = 0.42f + idx * 0.12f,
                amplitude = 0.18f,
                harmonicMix = 0.55f,
                fmDepth = 0.35f
            )
        }
        allocateVoice(freqHz = 130.81f, targetFreqHz = 65.41f, duration = 0.55f, amplitude = 0.26f, harmonicMix = 0.25f, fmDepth = 1.4f)
    }

    fun release() {
        running = false
    }
}
