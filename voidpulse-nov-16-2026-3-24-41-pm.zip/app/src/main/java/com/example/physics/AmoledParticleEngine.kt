package com.example.physics

import androidx.compose.ui.geometry.Offset
import com.example.model.ParticleMode
import com.example.model.TouchToolMode
import kotlin.math.PI
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.random.Random

class TouchPointState(
    var id: Long = -1L,
    var x: Float = 0f,
    var y: Float = 0f,
    var prevX: Float = 0f,
    var prevY: Float = 0f,
    var active: Boolean = false,
    var holdTimeSec: Float = 0f
)

class AmoledShockwave(
    var x: Float = 0f,
    var y: Float = 0f,
    var radius: Float = 0f,
    var maxRadius: Float = 600f,
    var alpha: Float = 0f,
    var colorIndex: Int = 0,
    var active: Boolean = false
)

class FluxCoinOrb(
    var x: Float = 0f,
    var y: Float = 0f,
    var vx: Float = 0f,
    var vy: Float = 0f,
    var pulsePhase: Float = 0f,
    var ageSec: Float = 0f,
    var coinValue: Long = 5L,
    var active: Boolean = false
)

class ShatterShard(
    var x: Float = 0f,
    var y: Float = 0f,
    var vx: Float = 0f,
    var vy: Float = 0f,
    var life: Float = 0f,
    var colorIndex: Int = 0,
    var active: Boolean = false
)

class CrystalTarget(
    var x: Float = 0f,
    var y: Float = 0f,
    var vx: Float = 0f,
    var vy: Float = 0f,
    var radius: Float = 54f,
    var hp: Float = 100f,
    var maxHp: Float = 100f,
    var rotationDeg: Float = 0f,
    var hitFlash: Float = 0f,
    var colorIndex: Int = 0,
    var rewardCoins: Long = 22L,
    var active: Boolean = false
)

class PinballBumper(
    var x: Float = 0f,
    var y: Float = 0f,
    var radius: Float = 62f,
    var bounceFlash: Float = 0f,
    var colorIndex: Int = 0
)

class LightningArcSegment(
    var x1: Float = 0f,
    var y1: Float = 0f,
    var x2: Float = 0f,
    var y2: Float = 0f,
    var alpha: Float = 0f,
    var colorIndex: Int = 0,
    var active: Boolean = false
)

class AmoledParticleEngine(private val maxCapacity: Int = 860) {

    val px = FloatArray(maxCapacity)
    val py = FloatArray(maxCapacity)
    val prevX = FloatArray(maxCapacity)
    val prevY = FloatArray(maxCapacity)
    val vx = FloatArray(maxCapacity)
    val vy = FloatArray(maxCapacity)
    val baseSize = FloatArray(maxCapacity)
    val colorIdx = IntArray(maxCapacity)
    val phase = FloatArray(maxCapacity)
    val energy = FloatArray(maxCapacity)

    val touchPoints = Array(5) { TouchPointState() }
    val shockwaves = Array(10) { AmoledShockwave() }
    val fluxOrbs = Array(14) { FluxCoinOrb() }
    val shards = Array(120) { ShatterShard() }
    val crystals = Array(3) { CrystalTarget() }
    val bumpers = Array(4) { PinballBumper() }
    val lightningArcs = Array(28) { LightningArcSegment() }

    var activeCount: Int = 340
        private set

    var canvasWidth: Float = 1080f
        private set
    var canvasHeight: Float = 2200f
        private set

    private var initialized = false
    var globalTimeSec = 0f
        private set

    private var passiveAccumulator = 0f
    private var orbSpawnAccumulator = 0f
    private var fireworkAutoTimer = 0f

    var kineticExcitement: Float = 0f
        private set
    var kineticMultiplier: Float = 1.0f
        private set

    // Combo & Fever Overdrive state
    var comboCount: Int = 1
        private set
    var comboTimerSec: Float = 0f
        private set
    var feverCharge: Float = 0f
        private set
    var isFeverOverdrive: Boolean = false
        private set
    var feverRemainingSec: Float = 0f
        private set

    fun ensureInitialized(width: Float, height: Float, targetCount: Int) {
        if (width <= 10f || height <= 10f) return
        canvasWidth = width
        canvasHeight = height
        activeCount = targetCount.coerceIn(200, maxCapacity)

        if (!initialized) {
            initialized = true
            val rng = Random(42)
            for (i in 0 until maxCapacity) {
                val x = rng.nextFloat() * width
                val y = rng.nextFloat() * height
                px[i] = x
                py[i] = y
                prevX[i] = x
                prevY[i] = y
                val angle = rng.nextFloat() * (2f * PI.toFloat())
                val speed = 65f + rng.nextFloat() * 165f
                vx[i] = cos(angle) * speed
                vy[i] = sin(angle) * speed
                baseSize[i] = 3.6f + rng.nextFloat() * 5.8f
                colorIdx[i] = i % 4
                phase[i] = rng.nextFloat() * (2f * PI.toFloat())
                energy[i] = 0.25f + rng.nextFloat() * 0.5f
            }

            // Initialize 3 floating destructible Crystal Targets
            for (cIdx in crystals.indices) {
                respawnCrystal(cIdx)
            }

            // Initialize 4 Cyber Pinball Bumpers in a diamond layout
            layoutBumpers(width, height)
        } else {
            layoutBumpers(width, height)
        }
    }

    private fun layoutBumpers(w: Float, h: Float) {
        bumpers[0].apply { x = w * 0.28f; y = h * 0.34f; radius = 58f; colorIndex = 0 }
        bumpers[1].apply { x = w * 0.72f; y = h * 0.34f; radius = 58f; colorIndex = 1 }
        bumpers[2].apply { x = w * 0.50f; y = h * 0.50f; radius = 66f; colorIndex = 2 }
        bumpers[3].apply { x = w * 0.50f; y = h * 0.68f; radius = 58f; colorIndex = 3 }
    }

    private fun respawnCrystal(index: Int) {
        val c = crystals[index]
        val padX = 110f
        val minY = 230f
        val maxY = (canvasHeight - 310f).coerceAtLeast(minY + 200f)
        c.x = padX + Random.nextFloat() * (canvasWidth - padX * 2f).coerceAtLeast(100f)
        c.y = minY + Random.nextFloat() * (maxY - minY)
        val angle = Random.nextFloat() * (2f * PI.toFloat())
        c.vx = cos(angle) * 58f
        c.vy = sin(angle) * 58f
        c.radius = 50f + (index % 2) * 8f
        c.maxHp = 100f
        c.hp = 100f
        c.rotationDeg = Random.nextFloat() * 360f
        c.hitFlash = 0f
        c.colorIndex = index % 4
        c.rewardCoins = 18L + index * 6L
        c.active = true
        spawnShockwave(c.x, c.y, maxRadius = 180f, colorIndex = c.colorIndex)
    }

    fun updateTargetCount(count: Int) {
        activeCount = count.coerceIn(200, maxCapacity)
    }

    fun stepPhysics(
        dtSec: Float,
        mode: ParticleMode,
        touchTool: TouchToolMode,
        forceLevel: Int,
        harvesterLevel: Int,
        onCoinCollected: (Long, Offset) -> Unit,
        onCrystalShattered: (Long, Int, Offset) -> Unit,
        onBumperHit: (Int) -> Unit,
        onFireworkBurst: () -> Unit,
        onFeverStarted: () -> Unit,
        onCollisionPulse: (Float) -> Unit
    ) {
        val dt = dtSec.coerceIn(0.001f, 0.035f)
        globalTimeSec += dt

        val w = canvasWidth
        val h = canvasHeight
        val centerX = w * 0.5f
        val centerY = h * 0.5f
        val forceAmp = 1f + (forceLevel - 1) * 0.25f
        val harvestBonus = 1f + (harvesterLevel - 1) * 0.35f

        // Combo & Fever Timers
        if (comboTimerSec > 0f) {
            comboTimerSec -= dt
            if (comboTimerSec <= 0f) {
                comboCount = 1
            }
        }
        if (isFeverOverdrive) {
            feverRemainingSec -= dt
            feverCharge = (feverRemainingSec / 8.0f).coerceIn(0f, 1f)
            if (feverRemainingSec <= 0f) {
                isFeverOverdrive = false
                feverCharge = 0f
            }
        }

        var activeTouches = 0
        var touchCentroidX = 0f
        var touchCentroidY = 0f
        var touchMotionSpeed = 0f

        for (t in touchPoints) {
            if (t.active) {
                activeTouches++
                t.holdTimeSec += dt
                touchCentroidX += t.x
                touchCentroidY += t.y
                val moveDist = hypot(t.x - t.prevX, t.y - t.prevY)
                touchMotionSpeed += moveDist / dt
                t.prevX = t.x
                t.prevY = t.y
            }
        }

        if (activeTouches > 0) {
            touchCentroidX /= activeTouches
            touchCentroidY /= activeTouches
            val boost = (0.4f + (touchMotionSpeed / 2000f).coerceAtMost(0.9f)) * dt * 2.5f
            kineticExcitement = (kineticExcitement + boost).coerceAtMost(1.0f)
            if (!isFeverOverdrive) {
                feverCharge = (feverCharge + dt * 0.055f * forceAmp).coerceAtMost(1f)
                if (feverCharge >= 1f) {
                    activateFeverOverdrive(onFeverStarted)
                }
            }
        } else {
            kineticExcitement = (kineticExcitement - dt * 0.35f).coerceAtLeast(0f)
        }

        val feverMult = if (isFeverOverdrive) 2.5f else 1.0f
        kineticMultiplier = (1.0f + kineticExcitement * 2.5f + (comboCount - 1) * 0.35f) * harvestBonus * feverMult

        // Firework mode or Blast tool or Fever mode periodic bursts
        if (mode == ParticleMode.FIREWORK_SYMPHONY || touchTool == TouchToolMode.BLAST || isFeverOverdrive) {
            fireworkAutoTimer += dt * (if (activeTouches > 0) 2.6f else 0.95f)
            if (fireworkAutoTimer >= 0.68f) {
                fireworkAutoTimer = 0f
                val fx = if (activeTouches > 0) {
                    touchCentroidX + (Random.nextFloat() - 0.5f) * 160f
                } else {
                    w * (0.2f + Random.nextFloat() * 0.6f)
                }
                val fy = if (activeTouches > 0) {
                    touchCentroidY + (Random.nextFloat() - 0.5f) * 160f
                } else {
                    h * (0.22f + Random.nextFloat() * 0.45f)
                }
                eruptFireworkShell(fx, fy, Random.nextInt(4))
                if (activeTouches > 0) onFireworkBurst()
            }
        }

        // Step destructible Crystal Targets
        for (cIdx in crystals.indices) {
            val c = crystals[cIdx]
            if (!c.active) {
                respawnCrystal(cIdx)
                continue
            }
            c.rotationDeg = (c.rotationDeg + dt * 65f) % 360f
            c.hitFlash = (c.hitFlash - dt * 3.5f).coerceAtLeast(0f)
            c.x += c.vx * dt
            c.y += c.vy * dt

            if (c.x < 85f || c.x > w - 85f) c.vx = -c.vx
            if (c.y < 190f || c.y > h - 260f) c.vy = -c.vy
            c.x = c.x.coerceIn(80f, (w - 80f).coerceAtLeast(90f))
            c.y = c.y.coerceIn(185f, (h - 255f).coerceAtLeast(220f))

            // Direct finger slice or Tesla zap on Crystal Target
            for (t in touchPoints) {
                if (!t.active) continue
                val distToFinger = hypot(t.x - c.x, t.y - c.y)
                val zapReach = if (mode == ParticleMode.PLASMA_LIGHTNING) 240f * forceAmp else 105f * forceAmp
                if (distToFinger < zapReach) {
                    damageCrystal(
                        cIdx = cIdx,
                        dmg = 165f * dt * forceAmp,
                        harvestBonus = harvestBonus * feverMult,
                        onCrystalShattered = onCrystalShattered,
                        onFeverStarted = onFeverStarted
                    )
                    if (mode == ParticleMode.PLASMA_LIGHTNING) {
                        spawnJaggedLightning(t.x, t.y, c.x, c.y, c.colorIndex)
                    }
                }
            }
        }

        // Decay Pinball Bumper flash
        val bumpersActive = (mode == ParticleMode.CYBER_PINBALL || isFeverOverdrive)
        if (bumpersActive) {
            for (b in bumpers) {
                b.bounceFlash = (b.bounceFlash - dt * 4.0f).coerceAtLeast(0f)
            }
        }

        // Decay Lightning Arcs
        for (arc in lightningArcs) {
            if (!arc.active) continue
            arc.alpha -= dt * 5.5f
            if (arc.alpha <= 0f) arc.active = false
        }

        // Spawn ambient Tesla arcs when touching in Plasma Lightning mode
        if (mode == ParticleMode.PLASMA_LIGHTNING && activeTouches > 0) {
            for (t in touchPoints) {
                if (!t.active) continue
                val randomParticle = Random.nextInt(activeCount)
                val pxTarget = px[randomParticle]
                val pyTarget = py[randomParticle]
                if (hypot(pxTarget - t.x, pyTarget - t.y) < 340f * forceAmp) {
                    spawnJaggedLightning(t.x, t.y, pxTarget, pyTarget, colorIdx[randomParticle])
                }
            }
        }

        // Passive coin generation & magnetic orb spawning while interacting
        if (activeTouches > 0 || kineticExcitement > 0.15f || isFeverOverdrive) {
            val rate = (if (activeTouches > 0) 1.55f else 0.55f) * (1f + kineticExcitement * 1.6f) * harvestBonus * feverMult
            passiveAccumulator += dt * rate
            orbSpawnAccumulator += dt * rate

            if (passiveAccumulator >= 1.05f) {
                passiveAccumulator -= 1.05f
                val earned = ((1L + harvesterLevel / 2L) * (if (isFeverOverdrive) 3L else 1L)).coerceAtLeast(1L)
                val pos = if (activeTouches > 0) Offset(touchCentroidX, touchCentroidY) else Offset(centerX, centerY)
                onCoinCollected(earned, pos)
            }

            if (orbSpawnAccumulator >= 1.85f) {
                orbSpawnAccumulator = 0f
                spawnFluxOrb(
                    nearX = if (activeTouches > 0) touchCentroidX else centerX,
                    nearY = if (activeTouches > 0) touchCentroidY else centerY,
                    value = (4L + harvesterLevel * 2L) * (if (isFeverOverdrive) 2L else 1L)
                )
            }
        }

        var boundaryHits = 0
        val count = activeCount

        for (i in 0 until count) {
            var x = px[i]
            var y = py[i]
            var velX = vx[i]
            var velY = vy[i]

            prevX[i] = x
            prevY[i] = y

            // Apply Universal Finger Touch Tool modifier when user touches screen
            if (activeTouches > 0) {
                for (t in touchPoints) {
                    if (!t.active) continue
                    val dx = t.x - x
                    val dy = t.y - y
                    val distSq = dx * dx + dy * dy + 650f
                    val dist = sqrt(distSq)
                    val nx = dx / dist
                    val ny = dy / dist

                    when (touchTool) {
                        TouchToolMode.PULL -> {
                            // Handled with mode-specific flavor below, plus extra pull boost
                            val pull = (320000f * forceAmp) / (distSq + 3800f)
                            velX += nx * pull * dt
                            velY += ny * pull * dt
                        }
                        TouchToolMode.PUSH -> {
                            if (dist < 320f * forceAmp) {
                                val push = (720f * forceAmp) * (1f - dist / (320f * forceAmp))
                                velX -= nx * push * dt * 5.5f
                                velY -= ny * push * dt * 5.5f
                                energy[i] = 1f
                            }
                        }
                        TouchToolMode.SPIN -> {
                            if (dist < 380f * forceAmp) {
                                val spin = (820f * forceAmp) * (1f - dist / (420f * forceAmp))
                                velX += (-ny * spin + nx * 160f) * dt
                                velY += (nx * spin + ny * 160f) * dt
                                energy[i] = 1f
                            }
                        }
                        TouchToolMode.BLAST -> {
                            if (dist < 95f) {
                                val angle = Random.nextFloat() * (2f * PI.toFloat())
                                val burstSpeed = 480f + Random.nextFloat() * 480f
                                velX = cos(angle) * burstSpeed
                                velY = sin(angle) * burstSpeed
                                energy[i] = 1f
                            }
                        }
                    }
                }
            }

            // Apply Mode-Specific Physics
            when (mode) {
                ParticleMode.BLACK_HOLE -> {
                    val cx = if (activeTouches > 0) touchCentroidX else centerX
                    val cy = if (activeTouches > 0) touchCentroidY else centerY
                    val dx = cx - x
                    val dy = cy - y
                    val distSq = dx * dx + dy * dy + 900f
                    val dist = sqrt(distSq)
                    val nx = dx / dist
                    val ny = dy / dist

                    if (activeTouches > 0) {
                        val pull = (820000f * forceAmp) / (distSq + 4200f)
                        val swirl = (540f * forceAmp) / (dist * 0.045f + 1f)
                        velX += (nx * pull - ny * swirl) * dt
                        velY += (ny * pull + nx * swirl) * dt
                        if (dist < 48f) {
                            velX += (-ny * 640f + nx * 180f) * dt
                            velY += (nx * 640f + ny * 180f) * dt
                            energy[i] = 1.0f
                        }
                    } else {
                        velX += (nx * 65f - ny * 98f) * dt
                        velY += (ny * 65f + nx * 98f) * dt
                    }
                    velX *= 0.986f
                    velY *= 0.986f
                }

                ParticleMode.FIREWORK_SYMPHONY -> {
                    // Gentle downward gravity + air drag so firework shells bloom and cascade like willow embers
                    velY += 165f * dt
                    velX += sin(globalTimeSec * 3.0f + phase[i]) * 25f * dt
                    velX *= 0.982f
                    velY *= 0.982f
                }

                ParticleMode.SLIME_BOUNCE -> {
                    velY += 170f * dt
                    val phaseWave = sin(globalTimeSec * 4.5f + phase[i]) * 52f
                    velX += phaseWave * dt

                    for (t in touchPoints) {
                        if (!t.active) continue
                        val dx = t.x - x
                        val dy = t.y - y
                        val dist = hypot(dx, dy).coerceAtLeast(1f)
                        if (dist < 380f * forceAmp) {
                            val displacement = dist - 84f
                            val springForce = displacement * 7.8f * forceAmp
                            velX += (dx / dist) * springForce * dt
                            velY += (dy / dist) * springForce * dt
                            energy[i] = (energy[i] + dt * 1.8f).coerceAtMost(1f)
                        }
                    }
                    velX *= 0.974f
                    velY *= 0.974f
                }

                ParticleMode.PLASMA_LIGHTNING -> {
                    // High-frequency jitter + magnetic alignment between touch points
                    val jitterAngle = sin(globalTimeSec * 22f + phase[i] * 5f) * 320f
                    velX += cos(jitterAngle) * 140f * dt
                    velY += sin(jitterAngle) * 140f * dt
                    velX *= 0.978f
                    velY *= 0.978f
                }

                ParticleMode.CYBER_PINBALL -> {
                    velY += 210f * dt // Pinball table slope gravity
                    velX *= 0.992f
                    velY *= 0.992f
                }

                ParticleMode.LASER_SHATTER -> {
                    val speed = hypot(velX, velY).coerceAtLeast(1f)
                    val targetSpeed = (470f + (i % 5) * 95f) * (1f + kineticExcitement * 0.45f)
                    velX = (velX / speed) * (speed + (targetSpeed - speed) * 0.12f)
                    velY = (velY / speed) * (speed + (targetSpeed - speed) * 0.12f)

                    for (t in touchPoints) {
                        if (!t.active) continue
                        val dx = x - t.x
                        val dy = y - t.y
                        val dist = hypot(dx, dy).coerceAtLeast(1f)
                        if (dist < 145f * forceAmp) {
                            val nx = dx / dist
                            val ny = dy / dist
                            val dot = velX * nx + velY * ny
                            if (dot < 0f) {
                                velX -= 2.1f * dot * nx
                                velY -= 2.1f * dot * ny
                            } else {
                                velX += nx * 520f * dt
                                velY += ny * 520f * dt
                            }
                            energy[i] = 1f
                            if (i % 4 == 0) spawnShatterShards(x, y, colorIdx[i])
                            boundaryHits++
                        }
                    }
                }

                ParticleMode.FLUID_VORTEX -> {
                    // Smooth hydrodynamic curl field
                    val nx = x / w.coerceAtLeast(1f)
                    val ny = y / h.coerceAtLeast(1f)
                    val curlAngle = sin(nx * 6.2f + globalTimeSec * 1.4f) * cos(ny * 6.2f - globalTimeSec * 1.1f) * PI.toFloat() * 2f
                    velX += cos(curlAngle) * 280f * dt
                    velY += sin(curlAngle) * 280f * dt
                    velX *= 0.968f
                    velY *= 0.968f
                }

                ParticleMode.GALAXY_SWIRL -> {
                    val cx = if (activeTouches > 0) touchCentroidX else centerX
                    val cy = if (activeTouches > 0) touchCentroidY else centerY
                    val dx = x - cx
                    val dy = y - cy
                    val r = hypot(dx, dy).coerceAtLeast(8f)
                    val theta = atan2(dy, dx)

                    val armIndex = i % 3
                    val armOffset = armIndex * (2f * PI.toFloat() / 3f)
                    val spiralAngle = theta + 0.32f * kotlin.math.ln(r / 35f + 1f) - globalTimeSec * 1.4f + armOffset
                    val spiralPush = sin(spiralAngle * 3f) * 145f * forceAmp

                    val tangentX = -dy / r
                    val tangentY = dx / r
                    val radialX = -dx / r
                    val radialY = -dy / r

                    val orbitalSpeed = (340f + 4200f / (r + 55f)) * (if (activeTouches > 0) 1.45f * forceAmp else 0.85f)
                    val radialSpring = (r - (120f + (i % 7) * 42f)) * 1.85f - spiralPush * 0.35f

                    val desiredVx = tangentX * orbitalSpeed + radialX * radialSpring
                    val desiredVy = tangentY * orbitalSpeed + radialY * radialSpring

                    velX += (desiredVx - velX) * 4.2f * dt
                    velY += (desiredVy - velY) * 4.2f * dt
                }
            }

            x += velX * dt
            y += velY * dt

            // Check collisions with Destructible Crystal Targets!
            val speed = hypot(velX, velY)
            if (speed > 210f) {
                for (cIdx in crystals.indices) {
                    val c = crystals[cIdx]
                    if (!c.active) continue
                    val dx = x - c.x
                    val dy = y - c.y
                    val hitRadius = c.radius + baseSize[i]
                    if (kotlin.math.abs(dx) < hitRadius && kotlin.math.abs(dy) < hitRadius) {
                        val d = hypot(dx, dy).coerceAtLeast(1f)
                        if (d < hitRadius) {
                            val nx = dx / d
                            val ny = dy / d
                            velX = nx * speed * 1.08f
                            velY = ny * speed * 1.08f
                            x = c.x + nx * (hitRadius + 2f)
                            y = c.y + ny * (hitRadius + 2f)
                            energy[i] = 1f
                            damageCrystal(
                                cIdx = cIdx,
                                dmg = (speed * 0.028f) * forceAmp,
                                harvestBonus = harvestBonus * feverMult,
                                onCrystalShattered = onCrystalShattered,
                                onFeverStarted = onFeverStarted
                            )
                        }
                    }
                }
            }

            // Check collisions with Pinball Bumpers when active
            if (bumpersActive) {
                for (bIdx in bumpers.indices) {
                    val b = bumpers[bIdx]
                    val dx = x - b.x
                    val dy = y - b.y
                    val hitR = b.radius + baseSize[i]
                    if (kotlin.math.abs(dx) < hitR && kotlin.math.abs(dy) < hitR) {
                        val d = hypot(dx, dy).coerceAtLeast(1f)
                        if (d < hitR) {
                            val nx = dx / d
                            val ny = dy / d
                            val reboundSpeed = (speed * 1.35f).coerceIn(480f, 1150f)
                            velX = nx * reboundSpeed
                            velY = ny * reboundSpeed
                            x = b.x + nx * (hitR + 3f)
                            y = b.y + ny * (hitR + 3f)
                            energy[i] = 1f
                            if (b.bounceFlash < 0.25f) {
                                b.bounceFlash = 1.0f
                                onBumperHit(bIdx)
                            }
                        }
                    }
                }
            }

            // Screen boundary handling
            val bounceRestitution = when (mode) {
                ParticleMode.SLIME_BOUNCE, ParticleMode.CYBER_PINBALL -> 0.94f
                ParticleMode.LASER_SHATTER -> 1.0f
                else -> 0.82f
            }

            if (x < 8f) {
                x = 8f
                velX = kotlin.math.abs(velX) * bounceRestitution
                boundaryHits++
            } else if (x > w - 8f) {
                x = w - 8f
                velX = -kotlin.math.abs(velX) * bounceRestitution
                boundaryHits++
            }

            if (y < 8f) {
                y = 8f
                velY = kotlin.math.abs(velY) * bounceRestitution
                boundaryHits++
            } else if (y > h - 8f) {
                y = h - 8f
                velY = -kotlin.math.abs(velY) * bounceRestitution
                boundaryHits++
            }

            val currentSpeed = hypot(velX, velY)
            energy[i] = ((currentSpeed / 680f) + energy[i] * 0.85f).coerceIn(0.18f, 1.0f)

            px[i] = x
            py[i] = y
            vx[i] = velX
            vy[i] = velY
        }

        if (boundaryHits > 6 && activeTouches > 0) {
            onCollisionPulse((boundaryHits / 28f).coerceIn(0.25f, 1f))
        }

        // Step shatter shards
        for (s in shards) {
            if (!s.active) continue
            s.x += s.vx * dt
            s.y += s.vy * dt
            s.life -= dt * 2.1f
            if (s.life <= 0f) s.active = false
        }

        // Step shockwaves
        for (sw in shockwaves) {
            if (!sw.active) continue
            sw.radius += dt * 940f
            sw.alpha = (1f - sw.radius / sw.maxRadius).coerceIn(0f, 1f)
            if (sw.radius >= sw.maxRadius) sw.active = false
        }

        // Step magnetic Flux Coin Orbs
        for (orb in fluxOrbs) {
            if (!orb.active) continue
            orb.ageSec += dt
            orb.pulsePhase += dt * 7.5f

            val targetX = if (activeTouches > 0) touchCentroidX else centerX
            val targetY = if (activeTouches > 0) touchCentroidY else 140f
            val dx = targetX - orb.x
            val dy = targetY - orb.y
            val dist = hypot(dx, dy).coerceAtLeast(1f)

            val magnetStrength = if (activeTouches > 0 || orb.ageSec > 1.6f) 1550f else 240f
            orb.vx = (orb.vx + (dx / dist) * magnetStrength * dt) * 0.94f
            orb.vy = (orb.vy + (dy / dist) * magnetStrength * dt) * 0.94f
            orb.x += orb.vx * dt
            orb.y += orb.vy * dt

            if (dist < 68f || orb.ageSec > 3.4f) {
                orb.active = false
                spawnShockwave(orb.x, orb.y, maxRadius = 210f, colorIndex = 2)
                onCoinCollected(orb.coinValue, Offset(orb.x, orb.y))
            }
        }
    }

    private fun damageCrystal(
        cIdx: Int,
        dmg: Float,
        harvestBonus: Float,
        onCrystalShattered: (Long, Int, Offset) -> Unit,
        onFeverStarted: () -> Unit
    ) {
        val c = crystals[cIdx]
        if (!c.active) return
        c.hp -= dmg
        c.hitFlash = 1.0f
        if (c.hp <= 0f) {
            val shatterX = c.x
            val shatterY = c.y
            val color = c.colorIndex
            comboCount = (comboCount + 1).coerceAtMost(25)
            comboTimerSec = 4.5f

            if (!isFeverOverdrive) {
                feverCharge = (feverCharge + 0.24f).coerceAtMost(1f)
                if (feverCharge >= 1f) {
                    activateFeverOverdrive(onFeverStarted)
                }
            }

            val coinReward = ((c.rewardCoins + comboCount * 4L) * harvestBonus).toLong().coerceAtLeast(15L)
            spawnShockwave(shatterX, shatterY, maxRadius = 520f, colorIndex = color)
            spawnShatterShards(shatterX, shatterY, color, count = 22)
            respawnCrystal(cIdx)
            onCrystalShattered(coinReward, comboCount, Offset(shatterX, shatterY))
        }
    }

    private fun activateFeverOverdrive(onFeverStarted: () -> Unit) {
        isFeverOverdrive = true
        feverRemainingSec = 8.0f
        feverCharge = 1.0f
        triggerSupernovaBurst(canvasWidth * 0.5f, canvasHeight * 0.5f, 1.35f)
        onFeverStarted()
    }

    fun eruptFireworkShell(centerX: Float, centerY: Float, colorIndex: Int) {
        spawnShockwave(centerX, centerY, maxRadius = 420f, colorIndex = colorIndex)
        spawnShatterShards(centerX, centerY, colorIndex, count = 16)
        // Re-center a batch of 28 particles into a radial chrysanthemum shell burst!
        val startIdx = Random.nextInt((activeCount - 30).coerceAtLeast(1))
        for (k in 0 until 28) {
            val idx = (startIdx + k) % activeCount
            val angle = (k / 28f) * (2f * PI.toFloat()) + Random.nextFloat() * 0.15f
            val speed = 280f + (k % 3) * 165f
            px[idx] = centerX
            py[idx] = centerY
            prevX[idx] = centerX
            prevY[idx] = centerY
            vx[idx] = cos(angle) * speed
            vy[idx] = sin(angle) * speed
            colorIdx[idx] = (colorIndex + (k % 2)) % 4
            energy[idx] = 1.0f
        }
    }

    private fun spawnJaggedLightning(x1: Float, y1: Float, x2: Float, y2: Float, colorIndex: Int) {
        val midX = (x1 + x2) * 0.5f + (Random.nextFloat() - 0.5f) * 68f
        val midY = (y1 + y2) * 0.5f + (Random.nextFloat() - 0.5f) * 68f
        addLightningSegment(x1, y1, midX, midY, colorIndex)
        addLightningSegment(midX, midY, x2, y2, colorIndex)
    }

    private fun addLightningSegment(x1: Float, y1: Float, x2: Float, y2: Float, colorIndex: Int) {
        val slot = lightningArcs.firstOrNull { !it.active } ?: lightningArcs[Random.nextInt(lightningArcs.size)]
        slot.x1 = x1
        slot.y1 = y1
        slot.x2 = x2
        slot.y2 = y2
        slot.alpha = 1.0f
        slot.colorIndex = colorIndex
        slot.active = true
    }

    fun triggerSupernovaBurst(centerX: Float, centerY: Float, powerMultiplier: Float = 1f) {
        spawnShockwave(centerX, centerY, maxRadius = 880f, colorIndex = 0)
        spawnShockwave(centerX, centerY, maxRadius = 560f, colorIndex = 1)
        for (i in 0 until activeCount) {
            val dx = px[i] - centerX
            val dy = py[i] - centerY
            val dist = hypot(dx, dy).coerceAtLeast(12f)
            val impulse = (780f * powerMultiplier) * (1f - (dist / 1200f).coerceAtMost(0.75f))
            vx[i] += (dx / dist) * impulse
            vy[i] += (dy / dist) * impulse
            energy[i] = 1.0f
        }
        spawnShatterShards(centerX, centerY, 0, count = 20)
    }

    fun spawnShockwave(x: Float, y: Float, maxRadius: Float = 620f, colorIndex: Int = 0) {
        val slot = shockwaves.firstOrNull { !it.active } ?: shockwaves[0]
        slot.x = x
        slot.y = y
        slot.radius = 16f
        slot.maxRadius = maxRadius
        slot.alpha = 1f
        slot.colorIndex = colorIndex
        slot.active = true
    }

    private fun spawnFluxOrb(nearX: Float, nearY: Float, value: Long) {
        val slot = fluxOrbs.firstOrNull { !it.active } ?: return
        val angle = Random.nextFloat() * (2f * PI.toFloat())
        val radius = 110f + Random.nextFloat() * 140f
        slot.x = (nearX + cos(angle) * radius).coerceIn(60f, canvasWidth - 60f)
        slot.y = (nearY + sin(angle) * radius).coerceIn(140f, canvasHeight - 180f)
        slot.vx = -sin(angle) * 160f
        slot.vy = cos(angle) * 160f
        slot.pulsePhase = 0f
        slot.ageSec = 0f
        slot.coinValue = value
        slot.active = true
    }

    private fun spawnShatterShards(x: Float, y: Float, colorIndex: Int, count: Int = 4) {
        var spawned = 0
        for (s in shards) {
            if (!s.active) {
                val angle = Random.nextFloat() * (2f * PI.toFloat())
                val speed = 220f + Random.nextFloat() * 480f
                s.x = x
                s.y = y
                s.vx = cos(angle) * speed
                s.vy = sin(angle) * speed
                s.life = 0.65f + Random.nextFloat() * 0.35f
                s.colorIndex = colorIndex
                s.active = true
                spawned++
                if (spawned >= count) break
            }
        }
    }
}
