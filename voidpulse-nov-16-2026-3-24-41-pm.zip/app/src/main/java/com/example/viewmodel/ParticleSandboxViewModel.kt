package com.example.viewmodel

import android.content.Context
import androidx.compose.ui.geometry.Offset
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.PlayerProfileEntity
import com.example.data.PlayerRepository
import com.example.data.VoidPulseDatabase
import com.example.model.AmoledPalette
import com.example.model.KineticUpgradeType
import com.example.model.ParticleMode
import com.example.model.ParticleShapeType
import com.example.model.SoundSynthStyle
import com.example.model.TouchToolMode
import com.example.physics.AmoledParticleEngine
import com.example.sensory.ProceduralSynthEngine
import com.example.sensory.TactileHapticEngine
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class FloatingCoinGain(
    val id: Long,
    val label: String,
    val isCrystalJackpot: Boolean,
    val x: Float,
    val y: Float
)

data class SandboxUiState(
    val profile: PlayerProfileEntity = PlayerProfileEntity(),
    val activeMode: ParticleMode = ParticleMode.BLACK_HOLE,
    val activeShape: ParticleShapeType = ParticleShapeType.NEON_ORB,
    val activePalette: AmoledPalette = AmoledPalette.CYBER_NEON,
    val activeTouchTool: TouchToolMode = TouchToolMode.PULL,
    val activeSoundStyle: SoundSynthStyle = SoundSynthStyle.CELESTIAL_HARP,
    val isVaultOpen: Boolean = false,
    val selectedVaultTab: Int = 0,
    val modesButtonPulseCount: Int = 0,
    val coinPulseSeq: Int = 0,
    val floatingGains: List<FloatingCoinGain> = emptyList(),
    val bannerMessage: String? = null
) {
    val activeParticleTargetCount: Int
        get() = 310 + (profile.particleDensityLevel - 1) * 95

    val affordableUnlocksCount: Int
        get() {
            val modeCount = ParticleMode.entries.count { !profile.isModeUnlocked(it) && profile.coins >= it.costCoins }
            val shapeCount = ParticleShapeType.entries.count { !profile.isShapeUnlocked(it) && profile.coins >= it.costCoins }
            val paletteCount = AmoledPalette.entries.count { !profile.isPaletteUnlocked(it) && profile.coins >= it.costCoins }
            val upgradeCount = KineticUpgradeType.entries.count {
                val lvl = profile.levelForUpgrade(it)
                lvl < it.maxLevel && profile.coins >= it.costForNextLevel(lvl)
            }
            return modeCount + shapeCount + paletteCount + upgradeCount
        }
}

class ParticleSandboxViewModel(
    private val repository: PlayerRepository,
    val synthEngine: ProceduralSynthEngine,
    val hapticEngine: TactileHapticEngine
) : ViewModel() {

    val particleEngine = AmoledParticleEngine(maxCapacity = 860)

    private val isVaultOpenFlow = MutableStateFlow(false)
    private val selectedVaultTabFlow = MutableStateFlow(0)
    private val modesButtonPulseFlow = MutableStateFlow(0)
    private val coinPulseSeqFlow = MutableStateFlow(0)
    private val floatingGainsFlow = MutableStateFlow<List<FloatingCoinGain>>(emptyList())
    private val bannerMessageFlow = MutableStateFlow<String?>(null)

    private var gainIdCounter = 1L

    init {
        viewModelScope.launch {
            val initial = repository.ensureInitialized()
            synthEngine.isEnabled = initial.soundEnabled
            synthEngine.activeStyle = SoundSynthStyle.fromId(initial.selectedSoundStyleId)
            hapticEngine.isEnabled = initial.hapticsEnabled
        }
    }

    val uiState: StateFlow<SandboxUiState> = combine(
        repository.profileFlow,
        isVaultOpenFlow,
        selectedVaultTabFlow,
        modesButtonPulseFlow,
        combine(coinPulseSeqFlow, floatingGainsFlow, bannerMessageFlow) { seq, gains, banner ->
            Triple(seq, gains, banner)
        }
    ) { profileOrNull, vaultOpen, tabIndex, btnPulse, triple ->
        val profile = profileOrNull ?: PlayerProfileEntity()
        val mode = ParticleMode.fromId(profile.selectedModeId)
        val shape = ParticleShapeType.fromId(profile.selectedShapeId)
        val palette = AmoledPalette.fromId(profile.selectedPaletteId)
        val touchTool = TouchToolMode.fromId(profile.selectedTouchToolId)
        val soundStyle = SoundSynthStyle.fromId(profile.selectedSoundStyleId)

        synthEngine.isEnabled = profile.soundEnabled
        synthEngine.activeStyle = soundStyle
        hapticEngine.isEnabled = profile.hapticsEnabled
        particleEngine.updateTargetCount(310 + (profile.particleDensityLevel - 1) * 95)

        SandboxUiState(
            profile = profile,
            activeMode = mode,
            activeShape = shape,
            activePalette = palette,
            activeTouchTool = touchTool,
            activeSoundStyle = soundStyle,
            isVaultOpen = vaultOpen,
            selectedVaultTab = tabIndex,
            modesButtonPulseCount = btnPulse,
            coinPulseSeq = triple.first,
            floatingGains = triple.second,
            bannerMessage = triple.third
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = SandboxUiState()
    )

    fun onTouchDown(slotIndex: Int, x: Float, y: Float, normalizedY: Float) {
        val slot = particleEngine.touchPoints.getOrNull(slotIndex) ?: return
        slot.x = x
        slot.y = y
        slot.prevX = x
        slot.prevY = y
        slot.holdTimeSec = 0f
        slot.active = true

        val state = uiState.value
        val mode = state.activeMode
        if (mode == ParticleMode.FIREWORK_SYMPHONY || state.activeTouchTool == TouchToolMode.BLAST) {
            particleEngine.eruptFireworkShell(x, y, slotIndex % 4)
            synthEngine.triggerFireworkBurstSound()
        } else {
            particleEngine.spawnShockwave(x, y, maxRadius = 290f, colorIndex = slotIndex % 4)
            synthEngine.triggerBassPulse(intensity = 0.85f)
            synthEngine.triggerHarmonicChime(mode.scaleHz, normalizedY, velocityBoost = 0.18f)
        }
        hapticEngine.pulseVortexTouch(strength = 0.85f)
    }

    fun onTouchMove(slotIndex: Int, x: Float, y: Float, normalizedY: Float) {
        val slot = particleEngine.touchPoints.getOrNull(slotIndex) ?: return
        val dx = x - slot.x
        val dy = y - slot.y
        val dist = kotlin.math.hypot(dx, dy)
        slot.x = x
        slot.y = y
        slot.active = true

        if (dist > 14f) {
            val velocityBoost = (dist / 110f).coerceIn(0f, 0.4f)
            synthEngine.triggerHarmonicChime(uiState.value.activeMode.scaleHz, normalizedY, velocityBoost)
            hapticEngine.pulseVortexTouch(strength = (0.35f + velocityBoost).coerceAtMost(0.95f))
        }
    }

    fun onTouchUp(slotIndex: Int) {
        val slot = particleEngine.touchPoints.getOrNull(slotIndex) ?: return
        if (slot.active) {
            val heldLong = slot.holdTimeSec > 0.25f
            slot.active = false
            if (heldLong || uiState.value.activeMode == ParticleMode.BLACK_HOLE) {
                particleEngine.triggerSupernovaBurst(
                    centerX = slot.x,
                    centerY = slot.y,
                    powerMultiplier = 0.78f + (uiState.value.profile.gravityAmplifierLevel - 1) * 0.16f
                )
                synthEngine.triggerBassPulse(intensity = 1.0f)
                hapticEngine.snapUiButton()
            }
        }
    }

    fun onStepCoinEarned(amount: Long, position: Offset) {
        if (amount <= 0L) return
        synthEngine.triggerCoinCollectSound()
        hapticEngine.coinHarvestTick()
        coinPulseSeqFlow.value += 1
        enqueueFloatingGain("+$amount", isCrystalJackpot = false, position = position)

        viewModelScope.launch {
            repository.addCoinsAndStats(amount = amount)
        }
    }

    fun onCrystalShattered(coinReward: Long, combo: Int, position: Offset) {
        synthEngine.triggerCrystalShatterSound(combo)
        hapticEngine.crystalShatterCrunch()
        coinPulseSeqFlow.value += 1
        val label = if (combo > 1) "+$coinReward (${combo}x CRUSH!)" else "+$coinReward SHATTER!"
        enqueueFloatingGain(label, isCrystalJackpot = true, position = position)

        viewModelScope.launch {
            repository.addCoinsAndStats(
                amount = coinReward,
                crystalsHit = 1,
                comboAchieved = combo
            )
        }
    }

    fun onBumperHit(bumperIndex: Int) {
        synthEngine.triggerBumperDingSound(bumperIndex)
        hapticEngine.bumperBounceSnap()
    }

    fun onFireworkBurst() {
        synthEngine.triggerFireworkBurstSound()
        hapticEngine.tickParticleCollision(0.75f)
    }

    fun onFeverOverdriveStarted() {
        synthEngine.triggerFeverOverdriveFanfare()
        hapticEngine.celebrateUnlock()
        showBanner("⚡ HYPER FEVER OVERDRIVE! 2.5x COINS & PINBALL BUMPERS! ⚡")
    }

    private fun enqueueFloatingGain(label: String, isCrystalJackpot: Boolean, position: Offset) {
        val gainId = gainIdCounter++
        val newGain = FloatingCoinGain(
            id = gainId,
            label = label,
            isCrystalJackpot = isCrystalJackpot,
            x = position.x,
            y = position.y
        )
        floatingGainsFlow.value = (floatingGainsFlow.value + newGain).takeLast(7)
        viewModelScope.launch {
            delay(950L)
            floatingGainsFlow.value = floatingGainsFlow.value.filterNot { it.id == gainId }
        }
    }

    fun onCollisionHaptic(intensity: Float) {
        hapticEngine.tickParticleCollision(intensity)
    }

    fun onSelectTouchTool(tool: TouchToolMode) {
        viewModelScope.launch {
            repository.setTouchTool(tool)
            synthEngine.triggerCrispUiClick(1.1f)
            hapticEngine.snapUiButton()
            showBanner("Finger Tool: ${tool.label} — ${tool.subtitle}")
        }
    }

    fun onCycleSoundStyle() {
        viewModelScope.launch {
            val nextStyle = repository.cycleSoundStyle()
            synthEngine.activeStyle = nextStyle
            synthEngine.triggerEpicModesButtonSound()
            hapticEngine.snapUiButton()
            showBanner("Synth Pack: ${nextStyle.title}")
        }
    }

    fun onQuickCycleShape() {
        val currentState = uiState.value
        val allShapes = ParticleShapeType.entries
        val unlocked = allShapes.filter { currentState.profile.isShapeUnlocked(it) }
        val currentIdx = unlocked.indexOf(currentState.activeShape)
        val nextShape = unlocked[(currentIdx + 1) % unlocked.size]
        viewModelScope.launch {
            repository.selectOrUnlockShape(nextShape)
            synthEngine.triggerCrispUiClick(1.2f)
            hapticEngine.snapUiButton()
            showBanner("Particle Shape: ${nextShape.title}")
        }
    }

    fun onOpenModesVault() {
        modesButtonPulseFlow.value += 1
        synthEngine.triggerEpicModesButtonSound()
        hapticEngine.epicModesButtonCascade()
        particleEngine.spawnShockwave(
            x = particleEngine.canvasWidth * 0.5f,
            y = particleEngine.canvasHeight * 0.88f,
            maxRadius = 750f,
            colorIndex = 0
        )
        isVaultOpenFlow.value = true
    }

    fun onCloseModesVault() {
        synthEngine.triggerCrispUiClick(0.88f)
        hapticEngine.snapUiButton()
        isVaultOpenFlow.value = false
    }

    fun onSelectVaultTab(tabIndex: Int) {
        synthEngine.triggerCrispUiClick(1.0f + tabIndex * 0.1f)
        hapticEngine.snapUiButton()
        selectedVaultTabFlow.value = tabIndex
    }

    fun onQuickCycleNextMode() {
        modesButtonPulseFlow.value += 1
        val currentState = uiState.value
        val allModes = ParticleMode.entries
        val currentIdx = allModes.indexOf(currentState.activeMode)
        val unlockedModes = allModes.filter { currentState.profile.isModeUnlocked(it) }
        val nextUnlocked = allModes
            .drop(currentIdx + 1)
            .plus(allModes.take(currentIdx + 1))
            .first { currentState.profile.isModeUnlocked(it) }

        viewModelScope.launch {
            repository.selectOrUnlockMode(nextUnlocked)
            synthEngine.triggerEpicModesButtonSound()
            hapticEngine.epicModesButtonCascade()
            particleEngine.triggerSupernovaBurst(
                centerX = particleEngine.canvasWidth * 0.5f,
                centerY = particleEngine.canvasHeight * 0.5f,
                powerMultiplier = 1.0f
            )
            showBanner("${nextUnlocked.title} Mode (${unlockedModes.size}/${allModes.size} Unlocked)")
        }
    }

    fun onModeCardAction(mode: ParticleMode) {
        viewModelScope.launch {
            val profile = uiState.value.profile
            val wasUnlocked = profile.isModeUnlocked(mode)
            if (!wasUnlocked && profile.coins < mode.costCoins) {
                synthEngine.triggerCrispUiClick(0.65f)
                hapticEngine.snapUiButton()
                showBanner("Need ${mode.costCoins - profile.coins} more Flux Coins to unlock ${mode.title}!")
                return@launch
            }

            val newlyUnlocked = repository.selectOrUnlockMode(mode)
            if (newlyUnlocked) {
                synthEngine.triggerUnlockFanfare()
                hapticEngine.celebrateUnlock()
                showBanner("UNLOCKED ${mode.title.uppercase()} MODE!")
            } else {
                synthEngine.triggerEpicModesButtonSound()
                hapticEngine.snapUiButton()
                showBanner("${mode.title} Mode Equipped")
            }
            particleEngine.triggerSupernovaBurst(
                centerX = particleEngine.canvasWidth * 0.5f,
                centerY = particleEngine.canvasHeight * 0.5f,
                powerMultiplier = 1.15f
            )
        }
    }

    fun onShapeCardAction(shape: ParticleShapeType) {
        viewModelScope.launch {
            val profile = uiState.value.profile
            val wasUnlocked = profile.isShapeUnlocked(shape)
            if (!wasUnlocked && profile.coins < shape.costCoins) {
                synthEngine.triggerCrispUiClick(0.65f)
                hapticEngine.snapUiButton()
                showBanner("Need ${shape.costCoins - profile.coins} more Flux Coins for ${shape.title}!")
                return@launch
            }

            val newlyUnlocked = repository.selectOrUnlockShape(shape)
            if (newlyUnlocked) {
                synthEngine.triggerUnlockFanfare()
                hapticEngine.celebrateUnlock()
                showBanner("UNLOCKED ${shape.title.uppercase()} PARTICLES!")
            } else {
                synthEngine.triggerCrispUiClick(1.22f)
                hapticEngine.snapUiButton()
                showBanner("Equipped ${shape.title}")
            }
            particleEngine.spawnShockwave(
                x = particleEngine.canvasWidth * 0.5f,
                y = particleEngine.canvasHeight * 0.5f,
                maxRadius = 680f,
                colorIndex = 2
            )
        }
    }

    fun onPaletteCardAction(palette: AmoledPalette) {
        viewModelScope.launch {
            val profile = uiState.value.profile
            val wasUnlocked = profile.isPaletteUnlocked(palette)
            if (!wasUnlocked && profile.coins < palette.costCoins) {
                synthEngine.triggerCrispUiClick(0.65f)
                hapticEngine.snapUiButton()
                showBanner("Need ${palette.costCoins - profile.coins} more Flux Coins for ${palette.title}!")
                return@launch
            }

            val newlyUnlocked = repository.selectOrUnlockPalette(palette)
            if (newlyUnlocked) {
                synthEngine.triggerUnlockFanfare()
                hapticEngine.celebrateUnlock()
                showBanner("Unlocked ${palette.title} AMOLED Palette!")
            } else {
                synthEngine.triggerCrispUiClick(1.18f)
                hapticEngine.snapUiButton()
                showBanner("Equipped ${palette.title} Palette")
            }
            particleEngine.spawnShockwave(
                x = particleEngine.canvasWidth * 0.5f,
                y = particleEngine.canvasHeight * 0.5f,
                maxRadius = 720f,
                colorIndex = 1
            )
        }
    }

    fun onPurchaseUpgrade(type: KineticUpgradeType) {
        viewModelScope.launch {
            val profile = uiState.value.profile
            val currentLvl = profile.levelForUpgrade(type)
            if (currentLvl >= type.maxLevel) return@launch
            val cost = type.costForNextLevel(currentLvl)
            if (profile.coins < cost) {
                synthEngine.triggerCrispUiClick(0.65f)
                hapticEngine.snapUiButton()
                showBanner("Need ${cost - profile.coins} more Flux Coins for ${type.title}!")
                return@launch
            }

            val success = repository.purchaseUpgrade(type)
            if (success) {
                synthEngine.triggerUnlockFanfare()
                hapticEngine.celebrateUnlock()
                showBanner("${type.title} upgraded to Lv.${currentLvl + 1}!")
            }
        }
    }

    fun onTriggerNovaBurst() {
        synthEngine.triggerEpicModesButtonSound()
        hapticEngine.epicModesButtonCascade()
        val w = particleEngine.canvasWidth
        val h = particleEngine.canvasHeight
        particleEngine.triggerSupernovaBurst(
            centerX = w * 0.5f,
            centerY = h * 0.5f,
            powerMultiplier = 1.35f + (uiState.value.profile.gravityAmplifierLevel - 1) * 0.2f
        )
        particleEngine.eruptFireworkShell(w * 0.3f, h * 0.4f, 0)
        particleEngine.eruptFireworkShell(w * 0.7f, h * 0.4f, 1)
        onStepCoinEarned(
            amount = 8L + uiState.value.profile.coinHarvesterLevel * 3L,
            position = Offset(w * 0.5f, h * 0.45f)
        )
    }

    fun onToggleSound() {
        viewModelScope.launch {
            val enabled = repository.toggleSound()
            synthEngine.isEnabled = enabled
            if (enabled) synthEngine.triggerCrispUiClick(1.1f)
            hapticEngine.snapUiButton()
        }
    }

    fun onToggleHaptics() {
        viewModelScope.launch {
            val enabled = repository.toggleHaptics()
            hapticEngine.isEnabled = enabled
            synthEngine.triggerCrispUiClick(1.05f)
            if (enabled) hapticEngine.snapUiButton()
        }
    }

    fun onToggleTrails() {
        viewModelScope.launch {
            repository.toggleTrails()
            synthEngine.triggerCrispUiClick(1.15f)
            hapticEngine.snapUiButton()
        }
    }

    private fun showBanner(message: String) {
        bannerMessageFlow.value = message
        viewModelScope.launch {
            delay(2400L)
            if (bannerMessageFlow.value == message) {
                bannerMessageFlow.value = null
            }
        }
    }

    override fun onCleared() {
        super.onCleared()
        synthEngine.release()
    }

    class Factory(private val context: Context) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            val db = VoidPulseDatabase.getInstance(context)
            val repo = PlayerRepository(db.playerProfileDao())
            val synth = ProceduralSynthEngine()
            val haptics = TactileHapticEngine(context.applicationContext)
            return ParticleSandboxViewModel(repo, synth, haptics) as T
        }
    }
}
