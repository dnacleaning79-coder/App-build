package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val VoidPulseAmoledColorScheme = darkColorScheme(
    primary = BiolumCyan,
    onPrimary = AmoledBlack,
    primaryContainer = VoidSurfaceVariant,
    onPrimaryContainer = BiolumCyan,
    secondary = HyperMagenta,
    onSecondary = Color.White,
    secondaryContainer = VoidSurfaceVariant,
    onSecondaryContainer = HyperMagenta,
    tertiary = FluxGold,
    onTertiary = AmoledBlack,
    tertiaryContainer = VoidSurfaceVariant,
    onTertiaryContainer = FluxGold,
    background = AmoledBlack,
    onBackground = TextPrimary,
    surface = VoidSurface,
    onSurface = TextPrimary,
    surfaceVariant = VoidSurfaceVariant,
    onSurfaceVariant = TextSecondary,
    outline = VoidBorderGlow
)

@Composable
fun MyApplicationTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = VoidPulseAmoledColorScheme,
        typography = Typography,
        content = content
    )
}
