package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.BlurOn
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Category
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Vibration
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.outlined.SwapHoriz
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.AmoledPalette
import com.example.model.ParticleMode
import com.example.model.ParticleShapeType
import com.example.model.SoundSynthStyle
import com.example.model.TouchToolMode
import com.example.ui.theme.AmoledBlack
import com.example.ui.theme.BiolumCyan
import com.example.ui.theme.FluxGold
import com.example.ui.theme.HyperMagenta
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.VoidSurface
import com.example.ui.theme.VoidSurfaceVariant
import kotlinx.coroutines.delay

@Composable
fun FloatingKineticTopHud(
    coins: Long,
    coinPulseSeq: Int,
    kineticMultiplier: Float,
    comboCount: Int,
    feverCharge: Float,
    isFeverOverdrive: Boolean,
    activeMode: ParticleMode,
    activeShape: ParticleShapeType,
    activePalette: AmoledPalette,
    activeSoundStyle: SoundSynthStyle,
    soundEnabled: Boolean,
    hapticsEnabled: Boolean,
    trailsEnabled: Boolean,
    bannerMessage: String?,
    onToggleSound: () -> Unit,
    onToggleHaptics: () -> Unit,
    onToggleTrails: () -> Unit,
    onCycleSoundStyle: () -> Unit,
    onQuickCycleShape: () -> Unit,
    onCoinPillClicked: () -> Unit,
    modifier: Modifier = Modifier
) {
    var coinBounce by remember { mutableStateOf(false) }
    LaunchedEffect(coinPulseSeq) {
        if (coinPulseSeq > 0) {
            coinBounce = true
            delay(140L)
            coinBounce = false
        }
    }

    val coinScale by animateFloatAsState(
        targetValue = if (coinBounce) 1.18f else 1.0f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioLowBouncy,
            stiffness = Spring.StiffnessMedium
        ),
        label = "coinScale"
    )

    Column(
        modifier = modifier
            .fillMaxWidth()
            .windowInsetsPadding(WindowInsets.statusBars)
            .padding(horizontal = 14.dp, vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Flux Coin Counter & Combo Pill
            Surface(
                color = VoidSurface.copy(alpha = 0.84f),
                shape = RoundedCornerShape(24.dp),
                modifier = Modifier
                    .scale(coinScale)
                    .border(
                        width = 1.4.dp,
                        brush = Brush.horizontalGradient(
                            listOf(FluxGold, activeMode.accentColor)
                        ),
                        shape = RoundedCornerShape(24.dp)
                    )
                    .clip(RoundedCornerShape(24.dp))
                    .clickable(onClick = onCoinPillClicked)
                    .testTag("flux_coins_hud_pill")
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Filled.MonetizationOn,
                        contentDescription = stringResource(R.string.flux_coins_label),
                        tint = FluxGold,
                        modifier = Modifier.size(21.dp)
                    )
                    Spacer(modifier = Modifier.width(5.dp))
                    Text(
                        text = "$coins",
                        style = MaterialTheme.typography.titleLarge.copy(
                            color = TextPrimary,
                            fontWeight = FontWeight.Bold
                        ),
                        modifier = Modifier.testTag("flux_coins_value_text")
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Box(
                        modifier = Modifier
                            .background(
                                color = if (comboCount > 1) HyperMagenta.copy(alpha = 0.25f) else activeMode.accentColor.copy(alpha = 0.18f),
                                shape = RoundedCornerShape(12.dp)
                            )
                            .padding(horizontal = 8.dp, vertical = 3.dp)
                    ) {
                        Text(
                            text = if (comboCount > 1) {
                                "${comboCount}x COMBO!"
                            } else {
                                stringResource(R.string.kinetic_multiplier_format, kineticMultiplier)
                            },
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = if (comboCount > 1) FluxGold else activeMode.accentColor,
                                fontWeight = FontWeight.Bold
                            )
                        )
                    }
                }
            }

            // Sensory Quick Toggles (Sound, Haptics, Glow Trails)
            Row(
                modifier = Modifier
                    .background(
                        color = VoidSurface.copy(alpha = 0.80f),
                        shape = RoundedCornerShape(24.dp)
                    )
                    .border(
                        width = 1.dp,
                        color = Color.White.copy(alpha = 0.12f),
                        shape = RoundedCornerShape(24.dp)
                    )
                    .padding(horizontal = 2.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onToggleSound,
                    modifier = Modifier
                        .minimumInteractiveComponentSize()
                        .testTag("toggle_sound_button")
                ) {
                    Icon(
                        imageVector = if (soundEnabled) Icons.Filled.VolumeUp else Icons.Filled.VolumeOff,
                        contentDescription = stringResource(R.string.sound_toggle_desc),
                        tint = if (soundEnabled) BiolumCyan else TextSecondary
                    )
                }

                IconButton(
                    onClick = onToggleHaptics,
                    modifier = Modifier
                        .minimumInteractiveComponentSize()
                        .testTag("toggle_haptics_button")
                ) {
                    Icon(
                        imageVector = Icons.Filled.Vibration,
                        contentDescription = stringResource(R.string.haptics_toggle_desc),
                        tint = if (hapticsEnabled) HyperMagenta else TextSecondary
                    )
                }

                IconButton(
                    onClick = onToggleTrails,
                    modifier = Modifier
                        .minimumInteractiveComponentSize()
                        .testTag("toggle_trails_button")
                ) {
                    Icon(
                        imageVector = Icons.Filled.BlurOn,
                        contentDescription = stringResource(R.string.trails_toggle_desc),
                        tint = if (trailsEnabled) FluxGold else TextSecondary
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        // Fever Overdrive Progress Bar + Quick Shape & Sound Pack Switchers
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Fever Meter Chip
            Surface(
                color = VoidSurface.copy(alpha = 0.78f),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .weight(1f)
                    .border(
                        width = 1.dp,
                        color = if (isFeverOverdrive) FluxGold else activeMode.accentColor.copy(alpha = 0.35f),
                        shape = RoundedCornerShape(14.dp)
                    )
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Filled.LocalFireDepartment,
                        contentDescription = null,
                        tint = if (isFeverOverdrive) FluxGold else HyperMagenta,
                        modifier = Modifier.size(15.dp)
                    )
                    Spacer(modifier = Modifier.width(5.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (isFeverOverdrive) "HYPER FEVER 2.5x!" else "${activeMode.title.uppercase()} • ${activePalette.title}",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = if (isFeverOverdrive) FluxGold else TextPrimary,
                                fontSize = 10.sp
                            ),
                            maxLines = 1,
                            modifier = Modifier.testTag("active_mode_indicator_text")
                        )
                        Spacer(modifier = Modifier.height(3.dp))
                        LinearProgressIndicator(
                            progress = { feverCharge.coerceIn(0f, 1f) },
                            color = if (isFeverOverdrive) FluxGold else HyperMagenta,
                            trackColor = VoidSurfaceVariant,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(4.dp)
                                .clip(RoundedCornerShape(2.dp))
                        )
                    }
                }
            }

            // Quick Particle Shape Cycler Chip
            Surface(
                color = VoidSurface.copy(alpha = 0.80f),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .border(1.dp, BiolumCyan.copy(alpha = 0.45f), RoundedCornerShape(14.dp))
                    .clip(RoundedCornerShape(14.dp))
                    .clickable(onClick = onQuickCycleShape)
                    .testTag("quick_shape_cycle_chip")
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 9.dp, vertical = 7.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Filled.Category,
                        contentDescription = "Cycle particle shape",
                        tint = BiolumCyan,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = activeShape.title.substringBefore(" "),
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = TextPrimary,
                            fontSize = 10.sp
                        )
                    )
                }
            }

            // Quick Synth Sound Pack Cycler Chip
            Surface(
                color = VoidSurface.copy(alpha = 0.80f),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .border(1.dp, FluxGold.copy(alpha = 0.45f), RoundedCornerShape(14.dp))
                    .clip(RoundedCornerShape(14.dp))
                    .clickable(onClick = onCycleSoundStyle)
                    .testTag("quick_synth_style_chip")
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 9.dp, vertical = 7.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Filled.MusicNote,
                        contentDescription = "Cycle synth pack",
                        tint = FluxGold,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = activeSoundStyle.title.substringBefore(" "),
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = TextPrimary,
                            fontSize = 10.sp
                        )
                    )
                }
            }
        }

        // Animated Status / Unlock Banner Toast
        AnimatedVisibility(
            visible = bannerMessage != null,
            enter = fadeIn() + slideInVertically { -it / 2 },
            exit = fadeOut() + slideOutVertically { -it / 2 }
        ) {
            if (bannerMessage != null) {
                Surface(
                    color = VoidSurface.copy(alpha = 0.94f),
                    shape = RoundedCornerShape(20.dp),
                    modifier = Modifier
                        .padding(top = 8.dp)
                        .border(
                            width = 1.5.dp,
                            brush = Brush.horizontalGradient(listOf(BiolumCyan, HyperMagenta, FluxGold)),
                            shape = RoundedCornerShape(20.dp)
                        )
                        .testTag("status_banner_toast")
                ) {
                    Text(
                        text = bannerMessage,
                        style = MaterialTheme.typography.labelLarge.copy(color = FluxGold),
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun EpicBottomControlDeck(
    activeMode: ParticleMode,
    activeTouchTool: TouchToolMode,
    affordableUnlocksCount: Int,
    modesButtonPulseCount: Int,
    onSelectTouchTool: (TouchToolMode) -> Unit,
    onQuickSwapMode: () -> Unit,
    onOpenModesVault: () -> Unit,
    onTriggerNovaBurst: () -> Unit,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "epicModesGlow")
    val orbitAngle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 3600, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "orbitAngle"
    )
    val glowPulse by infiniteTransition.animateFloat(
        initialValue = 0.88f,
        targetValue = 1.12f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "glowPulse"
    )

    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()

    var tapPopActive by remember { mutableStateOf(false) }
    LaunchedEffect(modesButtonPulseCount) {
        if (modesButtonPulseCount > 0) {
            tapPopActive = true
            delay(180L)
            tapPopActive = false
        }
    }

    val buttonScale by animateFloatAsState(
        targetValue = when {
            isPressed -> 0.90f
            tapPopActive -> 1.12f
            else -> 1.0f
        },
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioLowBouncy,
            stiffness = Spring.StiffnessMediumLow
        ),
        label = "epicButtonScale"
    )

    Column(
        modifier = modifier
            .fillMaxWidth()
            .windowInsetsPadding(WindowInsets.navigationBars)
            .padding(horizontal = 14.dp, vertical = 10.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Finger Touch Tool Selector Pill Row (Attract | Repulse | Whirlpool | Fireburst)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 8.dp)
                .background(VoidSurface.copy(alpha = 0.78f), RoundedCornerShape(18.dp))
                .border(1.dp, Color.White.copy(alpha = 0.10f), RoundedCornerShape(18.dp))
                .padding(4.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            TouchToolMode.entries.forEach { tool ->
                val selected = tool == activeTouchTool
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .weight(1f)
                        .height(34.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(
                            if (selected) activeMode.accentColor.copy(alpha = 0.25f) else Color.Transparent
                        )
                        .border(
                            width = if (selected) 1.2.dp else 0.dp,
                            color = if (selected) activeMode.accentColor else Color.Transparent,
                            shape = RoundedCornerShape(14.dp)
                        )
                        .clickable { onSelectTouchTool(tool) }
                        .testTag("touch_tool_${tool.id.lowercase()}")
                ) {
                    Text(
                        text = tool.label,
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = if (selected) activeMode.accentColor else TextSecondary,
                            fontWeight = FontWeight.Bold
                        )
                    )
                }
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp, Alignment.CenterHorizontally),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Quick-Cycle Mode Pill Button
            Surface(
                color = VoidSurface.copy(alpha = 0.85f),
                shape = RoundedCornerShape(22.dp),
                modifier = Modifier
                    .height(54.dp)
                    .border(
                        width = 1.2.dp,
                        color = activeMode.accentColor.copy(alpha = 0.6f),
                        shape = RoundedCornerShape(22.dp)
                    )
                    .clip(RoundedCornerShape(22.dp))
                    .clickable(onClick = onQuickSwapMode)
                    .testTag("quick_swap_mode_button")
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Outlined.SwapHoriz,
                        contentDescription = "Quick cycle mode",
                        tint = activeMode.accentColor,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "MODE",
                        style = MaterialTheme.typography.labelLarge.copy(
                            color = TextPrimary
                        )
                    )
                }
            }

            // THE EPIC MODES & VAULT BUTTON
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .weight(1f)
                    .height(60.dp)
                    .scale(buttonScale)
                    .drawBehind {
                        val sweepBrush = Brush.sweepGradient(
                            colors = listOf(
                                activeMode.accentColor,
                                HyperMagenta,
                                FluxGold,
                                BiolumCyan,
                                activeMode.accentColor
                            )
                        )
                        rotate(orbitAngle) {
                            drawCircle(
                                brush = sweepBrush,
                                radius = (size.maxDimension * 0.52f) * glowPulse,
                                center = Offset(size.width * 0.5f, size.height * 0.5f),
                                alpha = 0.25f
                            )
                        }
                        drawRoundRect(
                            brush = Brush.horizontalGradient(
                                listOf(activeMode.accentColor, HyperMagenta, FluxGold)
                            ),
                            style = Stroke(width = 3.dp.toPx() * glowPulse),
                            cornerRadius = androidx.compose.ui.geometry.CornerRadius(28.dp.toPx())
                        )
                    }
                    .clip(RoundedCornerShape(28.dp))
                    .background(
                        brush = Brush.horizontalGradient(
                            colors = listOf(
                                VoidSurface,
                                activeMode.accentColor.copy(alpha = 0.24f),
                                HyperMagenta.copy(alpha = 0.24f),
                                VoidSurface
                            )
                        )
                    )
                    .clickable(
                        interactionSource = interactionSource,
                        indication = null,
                        onClick = onOpenModesVault
                    )
                    .testTag("epic_modes_vault_button")
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center,
                    modifier = Modifier.padding(horizontal = 12.dp)
                ) {
                    Icon(
                        imageVector = Icons.Filled.AutoAwesome,
                        contentDescription = null,
                        tint = FluxGold,
                        modifier = Modifier.size(21.dp)
                    )
                    Spacer(modifier = Modifier.width(7.dp))
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = stringResource(R.string.modes_vault_button),
                            style = MaterialTheme.typography.labelLarge.copy(
                                color = TextPrimary,
                                fontSize = 13.sp,
                                letterSpacing = 1.0.sp
                            )
                        )
                        Text(
                            text = activeMode.physicsBadge,
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = activeMode.accentColor,
                                fontSize = 10.sp
                            )
                        )
                    }

                    if (affordableUnlocksCount > 0) {
                        Spacer(modifier = Modifier.width(6.dp))
                        Box(
                            contentAlignment = Alignment.Center,
                            modifier = Modifier
                                .size(22.dp)
                                .background(FluxGold, CircleShape)
                                .testTag("affordable_unlocks_badge")
                        ) {
                            Text(
                                text = "$affordableUnlocksCount",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = AmoledBlack,
                                    fontWeight = FontWeight.Bold
                                )
                            )
                        }
                    }
                }
            }

            // NOVA BURST Action Pill
            Surface(
                color = VoidSurface.copy(alpha = 0.85f),
                shape = RoundedCornerShape(22.dp),
                modifier = Modifier
                    .height(54.dp)
                    .border(
                        width = 1.2.dp,
                        color = FluxGold.copy(alpha = 0.65f),
                        shape = RoundedCornerShape(22.dp)
                    )
                    .clip(RoundedCornerShape(22.dp))
                    .clickable(onClick = onTriggerNovaBurst)
                    .testTag("nova_burst_button")
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Filled.Bolt,
                        contentDescription = stringResource(R.string.pulse_burst_button),
                        tint = FluxGold,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "NOVA",
                        style = MaterialTheme.typography.labelLarge.copy(
                            color = FluxGold
                        )
                    )
                }
            }
        }
    }
}
