package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val AmoledBlack = Color(0xFF000000)
val VoidSurface = Color(0xFF0A0D14)
val VoidSurfaceVariant = Color(0xFF131926)
val VoidBorderGlow = Color(0xFF23304A)

val BiolumCyan = Color(0xFF00F5D4)
val BiolumCyanDim = Color(0xFF008B78)
val HyperMagenta = Color(0xFFFF2A85)
val HyperMagentaDim = Color(0xFF9E1450)
val FluxGold = Color(0xFFFFD166)
val FluxGoldDim = Color(0xFFB3861B)
val ElectricViolet = Color(0xFF9B5DE5)
val LaserLime = Color(0xFF70E000)
val PlasmaOrange = Color(0xFFFF6B35)

val TextPrimary = Color(0xFFF4F7FF)
val TextSecondary = Color(0xFF9BA8C7)
val TextMuted = Color(0xFF5E6C8C)
