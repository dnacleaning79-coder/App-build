package com.example.ui.components

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Category
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.RocketLaunch
import androidx.compose.material.icons.filled.Workspaces
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.PlayerProfileEntity
import com.example.model.AmoledPalette
import com.example.model.KineticUpgradeType
import com.example.model.ParticleMode
import com.example.model.ParticleShapeType
import com.example.ui.theme.AmoledBlack
import com.example.ui.theme.BiolumCyan
import com.example.ui.theme.ElectricViolet
import com.example.ui.theme.FluxGold
import com.example.ui.theme.HyperMagenta
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.VoidSurface
import com.example.ui.theme.VoidSurfaceVariant

@Composable
fun KineticVaultOverlay(
    profile: PlayerProfileEntity,
    activeMode: ParticleMode,
    activeShape: ParticleShapeType,
    activePalette: AmoledPalette,
    selectedTab: Int,
    onSelectTab: (Int) -> Unit,
    onModeAction: (ParticleMode) -> Unit,
    onShapeAction: (ParticleShapeType) -> Unit,
    onPaletteAction: (AmoledPalette) -> Unit,
    onUpgradeAction: (KineticUpgradeType) -> Unit,
    onClose: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler(onBack = onClose)

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(AmoledBlack.copy(alpha = 0.78f))
            .clickable(onClick = onClose)
            .testTag("kinetic_vault_overlay"),
        contentAlignment = Alignment.BottomCenter
    ) {
        Surface(
            color = VoidSurface,
            shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp),
            modifier = Modifier
                .fillMaxWidth()
                .widthIn(max = 640.dp)
                .clickable(enabled = false, onClick = {})
                .border(
                    width = 1.5.dp,
                    brush = Brush.horizontalGradient(listOf(BiolumCyan, HyperMagenta, FluxGold)),
                    shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)
                )
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .windowInsetsPadding(WindowInsets.navigationBars)
                    .padding(bottom = 14.dp)
            ) {
                // Header Banner with Generated Nebula Artwork
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(132.dp)
                        .clip(RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp))
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.img_vault_banner_1794825708041),
                        contentDescription = stringResource(R.string.vault_title),
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.verticalGradient(
                                    listOf(
                                        AmoledBlack.copy(alpha = 0.35f),
                                        VoidSurface.copy(alpha = 0.96f)
                                    )
                                )
                            )
                    )

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 20.dp, vertical = 14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Top
                    ) {
                        Column {
                            Text(
                                text = stringResource(R.string.vault_title),
                                style = MaterialTheme.typography.headlineMedium.copy(
                                    color = TextPrimary,
                                    fontWeight = FontWeight.Bold
                                )
                            )
                            Text(
                                text = "Crystals Crushed: ${profile.crystalsShattered}  •  Best Combo: ${profile.bestCombo}x",
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    color = BiolumCyan
                                )
                            )
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Surface(
                                color = AmoledBlack.copy(alpha = 0.78f),
                                shape = RoundedCornerShape(18.dp),
                                modifier = Modifier.border(
                                    width = 1.dp,
                                    color = FluxGold.copy(alpha = 0.7f),
                                    shape = RoundedCornerShape(18.dp)
                                )
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.MonetizationOn,
                                        contentDescription = null,
                                        tint = FluxGold,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(5.dp))
                                    Text(
                                        text = "${profile.coins}",
                                        style = MaterialTheme.typography.titleMedium.copy(
                                            color = FluxGold,
                                            fontWeight = FontWeight.Bold
                                        )
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.width(8.dp))

                            IconButton(
                                onClick = onClose,
                                modifier = Modifier
                                    .minimumInteractiveComponentSize()
                                    .background(AmoledBlack.copy(alpha = 0.65f), CircleShape)
                                    .testTag("close_vault_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Close,
                                    contentDescription = stringResource(R.string.close_vault_desc),
                                    tint = TextPrimary
                                )
                            }
                        }
                    }
                }

                // 4-Tab Segmented Row (Modes | Shapes | Palettes | Upgrades)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    VaultTabButton(
                        title = "Modes (8)",
                        icon = Icons.Filled.Workspaces,
                        selected = selectedTab == 0,
                        accentColor = BiolumCyan,
                        onClick = { onSelectTab(0) },
                        testTag = "vault_tab_modes",
                        modifier = Modifier.weight(1f)
                    )
                    VaultTabButton(
                        title = "Shapes (6)",
                        icon = Icons.Filled.Category,
                        selected = selectedTab == 1,
                        accentColor = ElectricViolet,
                        onClick = { onSelectTab(1) },
                        testTag = "vault_tab_shapes",
                        modifier = Modifier.weight(1f)
                    )
                    VaultTabButton(
                        title = "Palettes",
                        icon = Icons.Filled.Palette,
                        selected = selectedTab == 2,
                        accentColor = HyperMagenta,
                        onClick = { onSelectTab(2) },
                        testTag = "vault_tab_palettes",
                        modifier = Modifier.weight(1f)
                    )
                    VaultTabButton(
                        title = "Boosts",
                        icon = Icons.Filled.RocketLaunch,
                        selected = selectedTab == 3,
                        accentColor = FluxGold,
                        onClick = { onSelectTab(3) },
                        testTag = "vault_tab_upgrades",
                        modifier = Modifier.weight(1f)
                    )
                }

                // Tab Content List
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(400.dp),
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    when (selectedTab) {
                        0 -> {
                            items(ParticleMode.entries, key = { it.id }) { mode ->
                                ModeVaultCard(
                                    mode = mode,
                                    isUnlocked = profile.isModeUnlocked(mode),
                                    isSelected = activeMode == mode,
                                    canAfford = profile.coins >= mode.costCoins,
                                    onAction = { onModeAction(mode) }
                                )
                            }
                        }

                        1 -> {
                            items(ParticleShapeType.entries, key = { it.id }) { shape ->
                                ShapeVaultCard(
                                    shape = shape,
                                    isUnlocked = profile.isShapeUnlocked(shape),
                                    isSelected = activeShape == shape,
                                    canAfford = profile.coins >= shape.costCoins,
                                    onAction = { onShapeAction(shape) }
                                )
                            }
                        }

                        2 -> {
                            items(AmoledPalette.entries, key = { it.id }) { palette ->
                                PaletteVaultCard(
                                    palette = palette,
                                    isUnlocked = profile.isPaletteUnlocked(palette),
                                    isSelected = activePalette == palette,
                                    canAfford = profile.coins >= palette.costCoins,
                                    onAction = { onPaletteAction(palette) }
                                )
                            }
                        }

                        else -> {
                            items(KineticUpgradeType.entries, key = { it.id }) { upgrade ->
                                val currentLevel = profile.levelForUpgrade(upgrade)
                                val nextCost = upgrade.costForNextLevel(currentLevel)
                                UpgradeVaultCard(
                                    upgrade = upgrade,
                                    currentLevel = currentLevel,
                                    nextCost = nextCost,
                                    canAfford = profile.coins >= nextCost,
                                    onPurchase = { onUpgradeAction(upgrade) }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun VaultTabButton(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    selected: Boolean,
    accentColor: Color,
    onClick: () -> Unit,
    testTag: String,
    modifier: Modifier = Modifier
) {
    Surface(
        color = if (selected) accentColor.copy(alpha = 0.22f) else VoidSurfaceVariant,
        shape = RoundedCornerShape(14.dp),
        modifier = modifier
            .height(44.dp)
            .border(
                width = if (selected) 1.5.dp else 1.dp,
                color = if (selected) accentColor else Color.White.copy(alpha = 0.08f),
                shape = RoundedCornerShape(14.dp)
            )
            .clip(RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
            .testTag(testTag)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center,
            modifier = Modifier.padding(horizontal = 6.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = if (selected) accentColor else TextSecondary,
                modifier = Modifier.size(14.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.labelSmall.copy(
                    color = if (selected) TextPrimary else TextSecondary,
                    fontWeight = FontWeight.Bold
                ),
                maxLines = 1
            )
        }
    }
}

@Composable
private fun ModeVaultCard(
    mode: ParticleMode,
    isUnlocked: Boolean,
    isSelected: Boolean,
    canAfford: Boolean,
    onAction: () -> Unit
) {
    Surface(
        color = if (isSelected) VoidSurfaceVariant else AmoledBlack.copy(alpha = 0.72f),
        shape = RoundedCornerShape(20.dp),
        modifier = Modifier
            .fillMaxWidth()
            .border(
                width = if (isSelected) 2.dp else 1.dp,
                color = if (isSelected) mode.accentColor else mode.accentColor.copy(alpha = 0.32f),
                shape = RoundedCornerShape(20.dp)
            )
            .clip(RoundedCornerShape(20.dp))
            .clickable(onClick = onAction)
            .testTag("mode_card_${mode.id.lowercase()}")
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(14.dp)
                            .background(mode.accentColor, CircleShape)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = mode.title,
                            style = MaterialTheme.typography.titleLarge.copy(color = TextPrimary)
                        )
                        Text(
                            text = mode.tagline,
                            style = MaterialTheme.typography.bodyMedium.copy(color = mode.accentColor)
                        )
                    }
                }

                Spacer(modifier = Modifier.width(8.dp))

                Button(
                    onClick = onAction,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = when {
                            isSelected -> mode.accentColor
                            isUnlocked -> VoidSurfaceVariant
                            canAfford -> FluxGold
                            else -> VoidSurfaceVariant.copy(alpha = 0.6f)
                        },
                        contentColor = when {
                            isSelected || (!isUnlocked && canAfford) -> AmoledBlack
                            else -> TextPrimary
                        }
                    ),
                    shape = RoundedCornerShape(14.dp),
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp),
                    modifier = Modifier.testTag("mode_action_button_${mode.id.lowercase()}")
                ) {
                    if (isSelected) {
                        Icon(
                            imageVector = Icons.Filled.CheckCircle,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = stringResource(R.string.status_active),
                            style = MaterialTheme.typography.labelLarge
                        )
                    } else if (isUnlocked) {
                        Text(
                            text = stringResource(R.string.status_equip),
                            style = MaterialTheme.typography.labelLarge
                        )
                    } else {
                        Icon(
                            imageVector = Icons.Filled.LockOpen,
                            contentDescription = null,
                            modifier = Modifier.size(15.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "${mode.costCoins} Coins",
                            style = MaterialTheme.typography.labelLarge
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = mode.description,
                style = MaterialTheme.typography.bodyMedium.copy(color = TextSecondary)
            )
        }
    }
}

@Composable
private fun ShapeVaultCard(
    shape: ParticleShapeType,
    isUnlocked: Boolean,
    isSelected: Boolean,
    canAfford: Boolean,
    onAction: () -> Unit
) {
    Surface(
        color = if (isSelected) VoidSurfaceVariant else AmoledBlack.copy(alpha = 0.72f),
        shape = RoundedCornerShape(20.dp),
        modifier = Modifier
            .fillMaxWidth()
            .border(
                width = if (isSelected) 2.dp else 1.dp,
                color = if (isSelected) BiolumCyan else Color.White.copy(alpha = 0.16f),
                shape = RoundedCornerShape(20.dp)
            )
            .clip(RoundedCornerShape(20.dp))
            .clickable(onClick = onAction)
            .testTag("shape_card_${shape.id.lowercase()}")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = shape.title,
                    style = MaterialTheme.typography.titleMedium.copy(
                        color = TextPrimary,
                        fontWeight = FontWeight.Bold
                    )
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = shape.subtitle,
                    style = MaterialTheme.typography.bodyMedium.copy(color = TextSecondary)
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Button(
                onClick = onAction,
                colors = ButtonDefaults.buttonColors(
                    containerColor = when {
                        isSelected -> BiolumCyan
                        isUnlocked -> VoidSurfaceVariant
                        canAfford -> FluxGold
                        else -> VoidSurfaceVariant.copy(alpha = 0.6f)
                    },
                    contentColor = when {
                        isSelected || (!isUnlocked && canAfford) -> AmoledBlack
                        else -> TextPrimary
                    }
                ),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.testTag("shape_action_button_${shape.id.lowercase()}")
            ) {
                Text(
                    text = when {
                        isSelected -> stringResource(R.string.status_active)
                        isUnlocked -> stringResource(R.string.status_equip)
                        else -> "${shape.costCoins} Coins"
                    },
                    style = MaterialTheme.typography.labelLarge
                )
            }
        }
    }
}

@Composable
private fun PaletteVaultCard(
    palette: AmoledPalette,
    isUnlocked: Boolean,
    isSelected: Boolean,
    canAfford: Boolean,
    onAction: () -> Unit
) {
    Surface(
        color = if (isSelected) VoidSurfaceVariant else AmoledBlack.copy(alpha = 0.72f),
        shape = RoundedCornerShape(20.dp),
        modifier = Modifier
            .fillMaxWidth()
            .border(
                width = if (isSelected) 2.dp else 1.dp,
                color = if (isSelected) palette.colors.first() else Color.White.copy(alpha = 0.16f),
                shape = RoundedCornerShape(20.dp)
            )
            .clip(RoundedCornerShape(20.dp))
            .clickable(onClick = onAction)
            .testTag("palette_card_${palette.id.lowercase()}")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = palette.title,
                    style = MaterialTheme.typography.titleMedium.copy(
                        color = TextPrimary,
                        fontWeight = FontWeight.Bold
                    )
                )
                Text(
                    text = palette.subtitle,
                    style = MaterialTheme.typography.bodyMedium.copy(color = TextSecondary)
                )
                Spacer(modifier = Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    palette.colors.forEach { swatch ->
                        Box(
                            modifier = Modifier
                                .size(24.dp)
                                .background(swatch, CircleShape)
                                .border(1.dp, Color.White.copy(alpha = 0.45f), CircleShape)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.width(12.dp))

            Button(
                onClick = onAction,
                colors = ButtonDefaults.buttonColors(
                    containerColor = when {
                        isSelected -> palette.colors.first()
                        isUnlocked -> VoidSurfaceVariant
                        canAfford -> FluxGold
                        else -> VoidSurfaceVariant.copy(alpha = 0.6f)
                    },
                    contentColor = when {
                        isSelected || (!isUnlocked && canAfford) -> AmoledBlack
                        else -> TextPrimary
                    }
                ),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.testTag("palette_action_button_${palette.id.lowercase()}")
            ) {
                Text(
                    text = when {
                        isSelected -> stringResource(R.string.status_active)
                        isUnlocked -> stringResource(R.string.status_equip)
                        else -> "${palette.costCoins} Coins"
                    },
                    style = MaterialTheme.typography.labelLarge
                )
            }
        }
    }
}

@Composable
private fun UpgradeVaultCard(
    upgrade: KineticUpgradeType,
    currentLevel: Int,
    nextCost: Long,
    canAfford: Boolean,
    onPurchase: () -> Unit
) {
    val isMaxed = currentLevel >= upgrade.maxLevel
    Surface(
        color = AmoledBlack.copy(alpha = 0.75f),
        shape = RoundedCornerShape(20.dp),
        modifier = Modifier
            .fillMaxWidth()
            .border(
                width = 1.dp,
                color = FluxGold.copy(alpha = 0.35f),
                shape = RoundedCornerShape(20.dp)
            )
            .testTag("upgrade_card_${upgrade.id.lowercase()}")
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "${upgrade.title}  •  Lv.$currentLevel/${upgrade.maxLevel}",
                        style = MaterialTheme.typography.titleMedium.copy(
                            color = TextPrimary,
                            fontWeight = FontWeight.Bold
                        )
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = upgrade.description,
                        style = MaterialTheme.typography.bodyMedium.copy(color = TextSecondary)
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Button(
                    onClick = onPurchase,
                    enabled = !isMaxed,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (!isMaxed && canAfford) FluxGold else VoidSurfaceVariant,
                        contentColor = if (!isMaxed && canAfford) AmoledBlack else TextPrimary
                    ),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.testTag("upgrade_action_button_${upgrade.id.lowercase()}")
                ) {
                    Text(
                        text = if (isMaxed) {
                            stringResource(R.string.status_maxed)
                        } else {
                            "$nextCost Coins"
                        },
                        style = MaterialTheme.typography.labelLarge
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            LinearProgressIndicator(
                progress = { currentLevel.toFloat() / upgrade.maxLevel.toFloat() },
                color = BiolumCyan,
                trackColor = VoidSurfaceVariant,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(6.dp)
                    .clip(RoundedCornerShape(4.dp))
            )
        }
    }
}
