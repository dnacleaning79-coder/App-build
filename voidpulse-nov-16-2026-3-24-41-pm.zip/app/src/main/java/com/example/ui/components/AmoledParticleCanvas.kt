package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import com.example.model.AmoledPalette
import com.example.model.ParticleMode
import com.example.model.ParticleShapeType
import com.example.model.TouchToolMode
import com.example.physics.AmoledParticleEngine
import com.example.ui.theme.AmoledBlack
import com.example.ui.theme.BiolumCyan
import com.example.ui.theme.FluxGold
import com.example.ui.theme.HyperMagenta
import kotlin.math.PI
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin
import kotlinx.coroutines.isActive

@Composable
fun AmoledParticleCanvas(
    engine: AmoledParticleEngine,
    mode: ParticleMode,
    shapeType: ParticleShapeType,
    palette: AmoledPalette,
    touchTool: TouchToolMode,
    forceLevel: Int,
    harvesterLevel: Int,
    targetParticleCount: Int,
    trailsEnabled: Boolean,
    onTouchDown: (Int, Float, Float, Float) -> Unit,
    onTouchMove: (Int, Float, Float, Float) -> Unit,
    onTouchUp: (Int) -> Unit,
    onCoinCollected: (Long, Offset) -> Unit,
    onCrystalShattered: (Long, Int, Offset) -> Unit,
    onBumperHit: (Int) -> Unit,
    onFireworkBurst: () -> Unit,
    onFeverStarted: () -> Unit,
    onCollisionPulse: (Float) -> Unit,
    modifier: Modifier = Modifier
) {
    var frameTick by remember { mutableLongStateOf(0L) }
    val currentMode by rememberUpdatedState(mode)
    val currentTouchTool by rememberUpdatedState(touchTool)
    val currentForceLevel by rememberUpdatedState(forceLevel)
    val currentHarvesterLevel by rememberUpdatedState(harvesterLevel)
    val currentOnCoin by rememberUpdatedState(onCoinCollected)
    val currentOnCrystal by rememberUpdatedState(onCrystalShattered)
    val currentOnBumper by rememberUpdatedState(onBumperHit)
    val currentOnFirework by rememberUpdatedState(onFireworkBurst)
    val currentOnFever by rememberUpdatedState(onFeverStarted)
    val currentOnCollision by rememberUpdatedState(onCollisionPulse)

    val reusablePath = remember { Path() }

    LaunchedEffect(Unit) {
        var lastNanos = 0L
        while (isActive) {
            withFrameNanos { nanos ->
                val dtSec = if (lastNanos == 0L) {
                    0.016f
                } else {
                    ((nanos - lastNanos) / 1_000_000_000f).coerceIn(0.001f, 0.04f)
                }
                lastNanos = nanos
                engine.stepPhysics(
                    dtSec = dtSec,
                    mode = currentMode,
                    touchTool = currentTouchTool,
                    forceLevel = currentForceLevel,
                    harvesterLevel = currentHarvesterLevel,
                    onCoinCollected = currentOnCoin,
                    onCrystalShattered = currentOnCrystal,
                    onBumperHit = currentOnBumper,
                    onFireworkBurst = currentOnFirework,
                    onFeverStarted = currentOnFever,
                    onCollisionPulse = currentOnCollision
                )
                frameTick = nanos
            }
        }
    }

    val paletteColors = palette.colors

    Canvas(
        modifier = modifier
            .fillMaxSize()
            .background(AmoledBlack)
            .testTag("amoled_particle_canvas")
            .pointerInput(Unit) {
                awaitEachGesture {
                    val activeSlots = mutableMapOf<Long, Int>()
                    var nextSlot = 0
                    do {
                        val event = awaitPointerEvent()
                        val heightPx = size.height.coerceAtLeast(1).toFloat()

                        for (change in event.changes) {
                            val pointerId = change.id.value
                            val pos = change.position
                            val normY = (pos.y / heightPx).coerceIn(0f, 1f)

                            if (change.pressed) {
                                val existingSlot = activeSlots[pointerId]
                                if (existingSlot == null) {
                                    val assigned = nextSlot % 5
                                    nextSlot++
                                    activeSlots[pointerId] = assigned
                                    onTouchDown(assigned, pos.x, pos.y, normY)
                                } else {
                                    onTouchMove(existingSlot, pos.x, pos.y, normY)
                                }
                                change.consume()
                            } else {
                                val releasedSlot = activeSlots.remove(pointerId)
                                if (releasedSlot != null) {
                                    onTouchUp(releasedSlot)
                                }
                            }
                        }
                    } while (event.changes.any { it.pressed })

                    activeSlots.values.forEach { slot ->
                        onTouchUp(slot)
                    }
                }
            }
    ) {
        val tick = frameTick
        if (tick < 0L) return@Canvas

        engine.ensureInitialized(size.width, size.height, targetParticleCount)
        val count = engine.activeCount

        // 0. Fever Overdrive Ambient Border Glow
        if (engine.isFeverOverdrive) {
            drawRect(
                brush = Brush.radialGradient(
                    colors = listOf(
                        Color.Transparent,
                        HyperMagenta.copy(alpha = 0.14f),
                        FluxGold.copy(alpha = 0.25f)
                    ),
                    center = Offset(size.width * 0.5f, size.height * 0.5f),
                    radius = size.maxDimension * 0.65f
                ),
                blendMode = BlendMode.Plus
            )
        }

        // 1. Render Destructible Neon Crystal Targets on Canvas
        for (c in engine.crystals) {
            if (!c.active) continue
            val cColor = paletteColors[c.colorIndex % paletteColors.size]
            val coreColor = if (c.hitFlash > 0.2f) Color.White else cColor
            val center = Offset(c.x, c.y)

            // Outer ambient glow
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        coreColor.copy(alpha = 0.42f + c.hitFlash * 0.35f),
                        cColor.copy(alpha = 0.12f),
                        Color.Transparent
                    ),
                    center = center,
                    radius = c.radius * 2.1f
                ),
                radius = c.radius * 2.1f,
                center = center,
                blendMode = BlendMode.Plus
            )

            // Rotating Crystal Diamond / Octagon
            rotate(degrees = c.rotationDeg, pivot = center) {
                reusablePath.reset()
                val sides = 6
                for (s in 0 until sides) {
                    val a = (s.toFloat() / sides) * (2f * PI.toFloat())
                    val r = if (s % 2 == 0) c.radius * 0.78f else c.radius * 0.62f
                    val vx = c.x + cos(a) * r
                    val vy = c.y + sin(a) * r
                    if (s == 0) reusablePath.moveTo(vx, vy) else reusablePath.lineTo(vx, vy)
                }
                reusablePath.close()

                drawPath(
                    path = reusablePath,
                    color = coreColor.copy(alpha = 0.32f),
                    blendMode = BlendMode.Plus
                )
                drawPath(
                    path = reusablePath,
                    color = coreColor,
                    style = Stroke(width = 4.5f),
                    blendMode = BlendMode.Plus
                )
            }

            // Inner glowing crystal core
            drawCircle(
                color = Color.White,
                radius = 9f + c.hitFlash * 6f,
                center = center,
                blendMode = BlendMode.Plus
            )

            // Health Arc Ring around Crystal
            val hpFraction = (c.hp / c.maxHp).coerceIn(0f, 1f)
            drawArc(
                color = FluxGold.copy(alpha = 0.88f),
                startAngle = -90f,
                sweepAngle = 360f * hpFraction,
                useCenter = false,
                topLeft = Offset(c.x - c.radius, c.y - c.radius),
                size = Size(c.radius * 2f, c.radius * 2f),
                style = Stroke(width = 5f, cap = StrokeCap.Round),
                blendMode = BlendMode.Plus
            )
        }

        // 2. Render Cyber Pinball Bumpers (when in Cyber Pinball mode or Fever Overdrive)
        if (mode == ParticleMode.CYBER_PINBALL || engine.isFeverOverdrive) {
            for (b in engine.bumpers) {
                val bColor = paletteColors[b.colorIndex % paletteColors.size]
                val flashBoost = b.bounceFlash * 16f
                val center = Offset(b.x, b.y)

                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            bColor.copy(alpha = 0.55f + b.bounceFlash * 0.4f),
                            Color.Transparent
                        ),
                        center = center,
                        radius = (b.radius + flashBoost) * 1.75f
                    ),
                    radius = (b.radius + flashBoost) * 1.75f,
                    center = center,
                    blendMode = BlendMode.Plus
                )
                drawCircle(
                    color = if (b.bounceFlash > 0.3f) Color.White else bColor,
                    radius = b.radius + flashBoost * 0.5f,
                    center = center,
                    style = Stroke(width = 6f + b.bounceFlash * 5f),
                    blendMode = BlendMode.Plus
                )
                drawCircle(
                    color = FluxGold,
                    radius = b.radius * 0.42f,
                    center = center,
                    style = Stroke(width = 3f),
                    blendMode = BlendMode.Plus
                )
            }
        }

        // 3. Render Touch Singularities & Multi-Touch Wormhole Bridges
        var prevActiveTouch: Offset? = null
        for (tIndex in engine.touchPoints.indices) {
            val tp = engine.touchPoints[tIndex]
            if (!tp.active) continue
            val center = Offset(tp.x, tp.y)
            val primaryColor = paletteColors[tIndex % paletteColors.size]
            val secondaryColor = paletteColors[(tIndex + 1) % paletteColors.size]

            // Draw multi-touch energy bridge between simultaneous fingers!
            prevActiveTouch?.let { prev ->
                drawLine(
                    brush = Brush.linearGradient(
                        colors = listOf(primaryColor, Color.White, secondaryColor),
                        start = prev,
                        end = center
                    ),
                    start = prev,
                    end = center,
                    strokeWidth = 5.5f,
                    cap = StrokeCap.Round,
                    blendMode = BlendMode.Plus
                )
            }
            prevActiveTouch = center

            when (mode) {
                ParticleMode.BLACK_HOLE -> {
                    drawCircle(
                        brush = Brush.radialGradient(
                            colors = listOf(
                                Color.Black,
                                primaryColor.copy(alpha = 0.68f),
                                secondaryColor.copy(alpha = 0.24f),
                                Color.Transparent
                            ),
                            center = center,
                            radius = 190f
                        ),
                        radius = 190f,
                        center = center,
                        blendMode = BlendMode.Plus
                    )
                    drawCircle(color = Color.Black, radius = 34f, center = center)
                    drawCircle(
                        color = primaryColor.copy(alpha = 0.92f),
                        radius = 38f,
                        center = center,
                        style = Stroke(width = 3.8f),
                        blendMode = BlendMode.Plus
                    )
                }

                else -> {
                    drawCircle(
                        brush = Brush.radialGradient(
                            colors = listOf(
                                Color.White.copy(alpha = 0.65f),
                                primaryColor.copy(alpha = 0.42f),
                                secondaryColor.copy(alpha = 0.14f),
                                Color.Transparent
                            ),
                            center = center,
                            radius = 175f
                        ),
                        radius = 175f,
                        center = center,
                        blendMode = BlendMode.Plus
                    )
                }
            }
        }

        // 4. Slime Mode Elastic Tendril Web
        if (mode == ParticleMode.SLIME_BOUNCE) {
            val step = 3
            val maxLinkDist = 122f
            for (i in 0 until count step step) {
                val x1 = engine.px[i]
                val y1 = engine.py[i]
                val c = paletteColors[engine.colorIdx[i] % paletteColors.size]
                for (j in (i + step) until (i + 24).coerceAtMost(count) step step) {
                    val dx = engine.px[j] - x1
                    val dy = engine.py[j] - y1
                    if (kotlin.math.abs(dx) < maxLinkDist && kotlin.math.abs(dy) < maxLinkDist) {
                        val d = hypot(dx, dy)
                        if (d < maxLinkDist) {
                            val linkAlpha = ((1f - d / maxLinkDist) * 0.52f).coerceIn(0f, 1f)
                            drawLine(
                                color = c.copy(alpha = linkAlpha),
                                start = Offset(x1, y1),
                                end = Offset(engine.px[j], engine.py[j]),
                                strokeWidth = 2.8f,
                                cap = StrokeCap.Round,
                                blendMode = BlendMode.Plus
                            )
                        }
                    }
                }
            }
        }

        // 5. Render Main Particles across all 6 ParticleShapeTypes
        val trailFactor = when {
            !trailsEnabled -> 0f
            shapeType == ParticleShapeType.VORTEX_STREAK -> 4.2f
            mode == ParticleMode.LASER_SHATTER -> 3.4f
            mode == ParticleMode.FIREWORK_SYMPHONY -> 2.6f
            mode == ParticleMode.GALAXY_SWIRL -> 2.1f
            else -> 1.55f
        }

        for (i in 0 until count) {
            val x = engine.px[i]
            val y = engine.py[i]
            val e = engine.energy[i]
            val baseColor = if (engine.isFeverOverdrive) {
                paletteColors[(i + (engine.globalTimeSec * 8f).toInt()) % paletteColors.size]
            } else {
                paletteColors[engine.colorIdx[i] % paletteColors.size]
            }
            val radius = engine.baseSize[i] * (0.85f + e * 0.7f)
            val center = Offset(x, y)

            if (trailFactor > 0f) {
                val tailX = x - engine.vx[i] * 0.022f * trailFactor
                val tailY = y - engine.vy[i] * 0.022f * trailFactor
                drawLine(
                    color = baseColor.copy(alpha = (0.30f + e * 0.45f).coerceAtMost(0.88f)),
                    start = Offset(tailX, tailY),
                    end = center,
                    strokeWidth = radius * (if (shapeType == ParticleShapeType.VORTEX_STREAK) 1.45f else 1.1f),
                    cap = StrokeCap.Round,
                    blendMode = BlendMode.Plus
                )
            }

            when (shapeType) {
                ParticleShapeType.NEON_ORB, ParticleShapeType.VORTEX_STREAK -> {
                    drawCircle(
                        color = baseColor.copy(alpha = (0.20f + e * 0.25f).coerceAtMost(0.55f)),
                        radius = radius * 2.3f,
                        center = center,
                        blendMode = BlendMode.Plus
                    )
                    drawCircle(
                        color = if (e > 0.76f) Color.White else baseColor,
                        radius = radius * 0.82f,
                        center = center,
                        blendMode = BlendMode.Plus
                    )
                }

                ParticleShapeType.STAR_SPARK -> {
                    val flareLen = radius * 2.5f
                    val coreColor = if (e > 0.72f) Color.White else baseColor
                    drawLine(
                        color = baseColor.copy(alpha = 0.78f),
                        start = Offset(x - flareLen, y),
                        end = Offset(x + flareLen, y),
                        strokeWidth = 2.4f,
                        cap = StrokeCap.Round,
                        blendMode = BlendMode.Plus
                    )
                    drawLine(
                        color = baseColor.copy(alpha = 0.78f),
                        start = Offset(x, y - flareLen),
                        end = Offset(x, y + flareLen),
                        strokeWidth = 2.4f,
                        cap = StrokeCap.Round,
                        blendMode = BlendMode.Plus
                    )
                    drawCircle(
                        color = coreColor,
                        radius = radius * 0.75f,
                        center = center,
                        blendMode = BlendMode.Plus
                    )
                }

                ParticleShapeType.CYBER_HEX -> {
                    val hexR = radius * 1.75f
                    reusablePath.reset()
                    for (k in 0 until 6) {
                        val a = k * (PI.toFloat() / 3f) + engine.phase[i]
                        val hx = x + cos(a) * hexR
                        val hy = y + sin(a) * hexR
                        if (k == 0) reusablePath.moveTo(hx, hy) else reusablePath.lineTo(hx, hy)
                    }
                    reusablePath.close()
                    drawPath(
                        path = reusablePath,
                        color = baseColor.copy(alpha = 0.85f),
                        style = Stroke(width = 2.4f),
                        blendMode = BlendMode.Plus
                    )
                    drawCircle(
                        color = Color.White,
                        radius = radius * 0.45f,
                        center = center,
                        blendMode = BlendMode.Plus
                    )
                }

                ParticleShapeType.PRISM_SHARD -> {
                    val angle = atan2(engine.vy[i], engine.vx[i])
                    val tipX = x + cos(angle) * radius * 2.3f
                    val tipY = y + sin(angle) * radius * 2.3f
                    val tailX = x - cos(angle) * radius * 1.5f
                    val tailY = y - sin(angle) * radius * 1.5f
                    val sideX = -sin(angle) * radius * 1.05f
                    val sideY = cos(angle) * radius * 1.05f

                    reusablePath.reset()
                    reusablePath.moveTo(tipX, tipY)
                    reusablePath.lineTo(x + sideX, y + sideY)
                    reusablePath.lineTo(tailX, tailY)
                    reusablePath.lineTo(x - sideX, y - sideY)
                    reusablePath.close()

                    drawPath(
                        path = reusablePath,
                        color = if (e > 0.78f) Color.White else baseColor,
                        blendMode = BlendMode.Plus
                    )
                }

                ParticleShapeType.PLASMA_RING -> {
                    drawCircle(
                        color = baseColor.copy(alpha = 0.88f),
                        radius = radius * 1.65f,
                        center = center,
                        style = Stroke(width = 2.6f),
                        blendMode = BlendMode.Plus
                    )
                    drawCircle(
                        color = Color.White.copy(alpha = 0.9f),
                        radius = radius * 0.4f,
                        center = center,
                        blendMode = BlendMode.Plus
                    )
                }
            }
        }

        // 6. Render Jagged Tesla Lightning Arcs
        for (arc in engine.lightningArcs) {
            if (!arc.active) continue
            val arcColor = paletteColors[arc.colorIndex % paletteColors.size]
            val start = Offset(arc.x1, arc.y1)
            val end = Offset(arc.x2, arc.y2)
            drawLine(
                color = arcColor.copy(alpha = arc.alpha * 0.65f),
                start = start,
                end = end,
                strokeWidth = 8f,
                cap = StrokeCap.Round,
                blendMode = BlendMode.Plus
            )
            drawLine(
                color = Color.White.copy(alpha = arc.alpha),
                start = start,
                end = end,
                strokeWidth = 3f,
                cap = StrokeCap.Round,
                blendMode = BlendMode.Plus
            )
        }

        // 7. Render Shatter Shards
        for (s in engine.shards) {
            if (!s.active) continue
            val shardColor = paletteColors[s.colorIndex % paletteColors.size]
            val alpha = s.life.coerceIn(0f, 1f)
            drawLine(
                color = shardColor.copy(alpha = alpha),
                start = Offset(s.x, s.y),
                end = Offset(s.x - s.vx * 0.03f, s.y - s.vy * 0.03f),
                strokeWidth = 4.5f,
                cap = StrokeCap.Round,
                blendMode = BlendMode.Plus
            )
        }

        // 8. Render Expanding Shockwaves
        for (sw in engine.shockwaves) {
            if (!sw.active) continue
            val swColor = paletteColors[sw.colorIndex % paletteColors.size]
            drawCircle(
                color = swColor.copy(alpha = sw.alpha * 0.78f),
                radius = sw.radius,
                center = Offset(sw.x, sw.y),
                style = Stroke(width = 4.5f + (1f - sw.alpha) * 6f),
                blendMode = BlendMode.Plus
            )
        }

        // 9. Render Magnetic Golden Flux Coin Orbs
        for (orb in engine.fluxOrbs) {
            if (!orb.active) continue
            val pulse = 1f + sin(orb.pulsePhase) * 0.22f
            val center = Offset(orb.x, orb.y)
            drawCircle(
                color = FluxGold.copy(alpha = 0.35f),
                radius = 32f * pulse,
                center = center,
                blendMode = BlendMode.Plus
            )
            drawCircle(
                color = FluxGold,
                radius = 14f * pulse,
                center = center,
                blendMode = BlendMode.Plus
            )
            drawCircle(
                color = Color.White,
                radius = 6f,
                center = center,
                blendMode = BlendMode.Plus
            )
        }
    }
}
