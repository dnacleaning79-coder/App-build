package com.example.model

import androidx.compose.ui.graphics.Color

enum class TouchToolMode(
    val id: String,
    val label: String,
    val subtitle: String
) {
    PULL("PULL", "Attract", "Gravity well pulls particles in"),
    PUSH("PUSH", "Repulse", "Force shield blasts particles away"),
    SPIN("SPIN", "Whirlpool", "Whips particles into high-speed orbits"),
    BLAST("BLAST", "Fireburst", "Spawns explosive particle fountains on touch");

    companion object {
        fun fromId(id: String): TouchToolMode =
            entries.firstOrNull { it.id == id } ?: PULL
    }
}

enum class SoundSynthStyle(
    val id: String,
    val title: String,
    val harmonicMix: Float,
    val fmDepth: Float,
    val echoFeedback: Float,
    val decayMultiplier: Float
) {
    CELESTIAL_HARP(
        id = "CELESTIAL_HARP",
        title = "Celestial Harp",
        harmonicMix = 0.45f,
        fmDepth = 0.25f,
        echoFeedback = 0.42f,
        decayMultiplier = 1.25f
    ),
    CRYSTAL_MARIMBA(
        id = "CRYSTAL_MARIMBA",
        title = "Crystal Bells",
        harmonicMix = 0.65f,
        fmDepth = 1.15f,
        echoFeedback = 0.36f,
        decayMultiplier = 0.85f
    ),
    CYBER_SYNTHWAVE(
        id = "CYBER_SYNTHWAVE",
        title = "Neon Synthwave",
        harmonicMix = 0.80f,
        fmDepth = 0.65f,
        echoFeedback = 0.45f,
        decayMultiplier = 1.10f
    ),
    ZEN_KALIMBA(
        id = "ZEN_KALIMBA",
        title = "Zen Droplets",
        harmonicMix = 0.22f,
        fmDepth = 0.40f,
        echoFeedback = 0.50f,
        decayMultiplier = 0.95f
    );

    companion object {
        fun fromId(id: String): SoundSynthStyle =
            entries.firstOrNull { it.id == id } ?: CELESTIAL_HARP
    }
}

enum class ParticleShapeType(
    val id: String,
    val title: String,
    val subtitle: String,
    val costCoins: Long
) {
    NEON_ORB(
        id = "NEON_ORB",
        title = "Luminescent Orbs",
        subtitle = "Classic glowing plasma spheres with soft bloom halos",
        costCoins = 0L
    ),
    STAR_SPARK(
        id = "STAR_SPARK",
        title = "Starlight Sparks",
        subtitle = "Twinkling 4-point supernova stars with cross-flares",
        costCoins = 0L
    ),
    CYBER_HEX(
        id = "CYBER_HEX",
        title = "Cyber Hexagons",
        subtitle = "Rotating geometric neon hexagons & energy cells",
        costCoins = 80L
    ),
    PRISM_SHARD(
        id = "PRISM_SHARD",
        title = "Velocity Diamonds",
        subtitle = "Directional crystalline darts that align with motion",
        costCoins = 140L
    ),
    PLASMA_RING(
        id = "PLASMA_RING",
        title = "Sonic Rings",
        subtitle = "Expanding hollow neon shock-rings & bubble cores",
        costCoins = 200L
    ),
    VORTEX_STREAK(
        id = "VORTEX_STREAK",
        title = "Hyper Lightbeams",
        subtitle = "Ultra-long warp-speed photon ribbons & comet blades",
        costCoins = 280L
    );

    companion object {
        fun fromId(id: String): ParticleShapeType =
            entries.firstOrNull { it.id == id } ?: NEON_ORB
    }
}

enum class ParticleMode(
    val id: String,
    val title: String,
    val tagline: String,
    val description: String,
    val physicsBadge: String,
    val costCoins: Long,
    val accentColor: Color,
    val secondaryColor: Color,
    val scaleHz: FloatArray
) {
    BLACK_HOLE(
        id = "BLACK_HOLE",
        title = "Black Hole",
        tagline = "Gravitational Singularity & Supernova Release",
        description = "Spawns intense gravitational wells with glowing accretion rings that whip particles into relativistic spirals to smash Crystal Targets, detonating Hawking shockwaves on release.",
        physicsBadge = "GRAVITY VORTEX",
        costCoins = 0L,
        accentColor = Color(0xFF00F5D4),
        secondaryColor = Color(0xFF9B5DE5),
        scaleHz = floatArrayOf(220.0f, 261.63f, 293.66f, 329.63f, 392.0f, 440.0f, 523.25f, 587.33f, 659.25f)
    ),
    FIREWORK_SYMPHONY(
        id = "FIREWORK_SYMPHONY",
        title = "Firework Symphony",
        tagline = "Cascading Neon Shells & Crackle Bursts",
        description = "Every tap or drag launches glowing chrysanthemum & willow firework bursts that bloom radially, shower sparkling embers downward, and shatter nearby targets!",
        physicsBadge = "PYRO BURSTS",
        costCoins = 0L,
        accentColor = Color(0xFFFF6B35),
        secondaryColor = Color(0xFFFFD166),
        scaleHz = floatArrayOf(261.63f, 329.63f, 392.0f, 523.25f, 659.25f, 783.99f, 1046.5f)
    ),
    SLIME_BOUNCE(
        id = "SLIME_BOUNCE",
        title = "Slime Bounce",
        tagline = "Elastic Tendril Web & Bouncy Bio-Gel",
        description = "High-viscosity elastic droplets linked by glowing spring-tension tendrils that squish, ricochet off walls, and form jiggly neon slime clusters around your fingers.",
        physicsBadge = "ELASTIC WEB",
        costCoins = 75L,
        accentColor = Color(0xFF70E000),
        secondaryColor = Color(0xFF00F5D4),
        scaleHz = floatArrayOf(261.63f, 293.66f, 329.63f, 392.0f, 440.0f, 523.25f, 587.33f)
    ),
    PLASMA_LIGHTNING(
        id = "PLASMA_LIGHTNING",
        title = "Plasma Tesla",
        tagline = "High-Voltage Branching Lightning Arcs",
        description = "Turns your fingers into high-voltage Tesla coils that shoot jagged, branching neon lightning bolts across particles and instantly zap Crystal Targets!",
        physicsBadge = "TESLA COIL",
        costCoins = 120L,
        accentColor = Color(0xFF00BBF9),
        secondaryColor = Color(0xFFE0AAFF),
        scaleHz = floatArrayOf(246.94f, 293.66f, 369.99f, 440.0f, 493.88f, 587.33f, 739.99f)
    ),
    CYBER_PINBALL(
        id = "CYBER_PINBALL",
        title = "Cyber Pinball",
        tagline = "Neon Bumpers, Ricochet Combos & Jackpots",
        description = "Spawns glowing arcade shock-bumpers across the AMOLED canvas! Slingshot particles into bumpers and crystals for rapid ricochet chimes and massive coin jackpots.",
        physicsBadge = "ARCADE BUMPERS",
        costCoins = 180L,
        accentColor = Color(0xFFFFD166),
        secondaryColor = Color(0xFFFF2A85),
        scaleHz = floatArrayOf(293.66f, 349.23f, 440.0f, 523.25f, 587.33f, 698.46f, 880.0f)
    ),
    LASER_SHATTER(
        id = "LASER_SHATTER",
        title = "Laser Shatter",
        tagline = "Ricochet Photon Beams & Prism Shards",
        description = "Hyper-velocity photon vectors that reflect off boundaries with razor-sharp trails and fracture into geometric crystal shards whenever your finger slices through.",
        physicsBadge = "PHOTON SHARDS",
        costCoins = 240L,
        accentColor = Color(0xFFFF2A85),
        secondaryColor = Color(0xFFFFD166),
        scaleHz = floatArrayOf(329.63f, 392.0f, 440.0f, 493.88f, 587.33f, 659.25f, 783.99f)
    ),
    FLUID_VORTEX(
        id = "FLUID_VORTEX",
        title = "Fluid Silk",
        tagline = "Hydrodynamic Currents & Bioluminescent Waves",
        description = "Swirling silk-like fluid currents and curl-noise eddies that flow smoothly around multi-touch gestures like glowing liquid aurora on pitch-black glass.",
        physicsBadge = "SILK FLOW",
        costCoins = 320L,
        accentColor = Color(0xFF9B5DE5),
        secondaryColor = Color(0xFF00F5D4),
        scaleHz = floatArrayOf(220.0f, 277.18f, 329.63f, 415.30f, 440.0f, 554.37f, 659.25f)
    ),
    GALAXY_SWIRL(
        id = "GALAXY_SWIRL",
        title = "Galaxy Swirl",
        tagline = "Multi-Arm Spiral Nebula & Harmonic Orbits",
        description = "Logarithmic spiral arms of cosmic stardust with differential angular momentum that weave hypnotic multi-touch constellations and resonant harmonic chords.",
        physicsBadge = "COSMIC SPIRAL",
        costCoins = 420L,
        accentColor = Color(0xFFFFD166),
        secondaryColor = Color(0xFF00BBF9),
        scaleHz = floatArrayOf(196.0f, 246.94f, 293.66f, 369.99f, 392.0f, 493.88f, 587.33f)
    );

    companion object {
        fun fromId(id: String): ParticleMode =
            entries.firstOrNull { it.id == id } ?: BLACK_HOLE
    }
}

enum class AmoledPalette(
    val id: String,
    val title: String,
    val subtitle: String,
    val costCoins: Long,
    val colors: List<Color>
) {
    CYBER_NEON(
        id = "CYBER_NEON",
        title = "Cyber Pulse",
        subtitle = "Bioluminescent Cyan, Hyper-Magenta & Electric Violet",
        costCoins = 0L,
        colors = listOf(
            Color(0xFF00F5D4),
            Color(0xFFFF2A85),
            Color(0xFF9B5DE5),
            Color(0xFF00BBF9)
        )
    ),
    SOLAR_FLARE(
        id = "SOLAR_FLARE",
        title = "Solar Corona",
        subtitle = "Supernova Gold, Plasma Orange & Crimson Core",
        costCoins = 70L,
        colors = listOf(
            Color(0xFFFFD166),
            Color(0xFFFF6B35),
            Color(0xFFFF0054),
            Color(0xFFFFF3B0)
        )
    ),
    ABYSSAL_BIOLUME(
        id = "ABYSSAL_BIOLUME",
        title = "Abyssal Trench",
        subtitle = "Deep Sea Aqua, Electric Lime & Sapphire Glow",
        costCoins = 130L,
        colors = listOf(
            Color(0xFF70E000),
            Color(0xFF00F5D4),
            Color(0xFF0096C7),
            Color(0xFFB5E48C)
        )
    ),
    PRISMATIC_HYPER(
        id = "PRISMATIC_HYPER",
        title = "Prismatic Overdrive",
        subtitle = "Full-Spectrum Neon Chromatic Refraction",
        costCoins = 210L,
        colors = listOf(
            Color(0xFFFF007F),
            Color(0xFF00F5D4),
            Color(0xFFFFBE0B),
            Color(0xFF8338EC)
        )
    ),
    ROYAL_SUPERNOVA(
        id = "ROYAL_SUPERNOVA",
        title = "Astral Crown",
        subtitle = "Celestial Gold, Ultraviolet & Rose Quartz",
        costCoins = 320L,
        colors = listOf(
            Color(0xFFFFD700),
            Color(0xFFC77DFF),
            Color(0xFFFF758F),
            Color(0xFFE0AAFF)
        )
    );

    companion object {
        fun fromId(id: String): AmoledPalette =
            entries.firstOrNull { it.id == id } ?: CYBER_NEON
    }
}

enum class KineticUpgradeType(
    val id: String,
    val title: String,
    val description: String,
    val baseCost: Long,
    val maxLevel: Int
) {
    PARTICLE_DENSITY(
        id = "PARTICLE_DENSITY",
        title = "Particle Swarm Density",
        description = "Increases active glowing particles on the AMOLED canvas (+95 particles per level).",
        baseCost = 60L,
        maxLevel = 6
    ),
    COIN_HARVESTER(
        id = "COIN_HARVESTER",
        title = "Flux Coin & Crystal Yield",
        description = "Boosts Flux Coins from shattering Crystal Targets, combos, and magnetic orbs.",
        baseCost = 70L,
        maxLevel = 6
    ),
    GRAVITY_AMPLIFIER(
        id = "GRAVITY_AMPLIFIER",
        title = "Kinetic Force & Fever Charge",
        description = "Amplifies finger force radius, lightning reach, and charges Fever Overdrive faster.",
        baseCost = 80L,
        maxLevel = 5
    );

    fun costForNextLevel(currentLevel: Int): Long {
        if (currentLevel >= maxLevel) return 0L
        return baseCost * currentLevel + (currentLevel - 1) * 35L
    }
}
