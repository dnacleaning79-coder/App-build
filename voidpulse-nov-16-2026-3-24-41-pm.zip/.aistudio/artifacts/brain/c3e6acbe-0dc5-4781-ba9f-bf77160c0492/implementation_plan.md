# VoidPulse: AMOLED Kinetic Particle Sandbox

VoidPulse is an ultra-responsive, 100% offline interactive particle physics sandbox designed specifically for AMOLED displays, pairing pitch-black `#000000` backgrounds with glowing high-contrast particle trails, procedural harmonic synth audio, multi-layered tactile haptics, and a rewarding kinetic coin progression loop.

## User Review & Critical Decisions

> [!IMPORTANT]
> The following core product decisions have been aligned based on your selections and the original brief:

- **Confirmed Decision 1 — Four Custom Particle Physics Modes**:
  1. **Black Hole** *(Starter Mode — Unlocked)*: Touch points spawn gravitational singularities with glowing accretion rings that bend trajectories, accelerate particles into orbital spirals, and release hawking-radiation bursts on release.
  2. **Slime Bounce**: High-viscosity elastic particles connected by spring-tension tendrils that squish, bounce off screen boundaries, and coalesce into jiggly neon blobs around your fingers.
  3. **Laser Shatter**: High-velocity crystalline beams that ricochet off screen edges and shatter into geometric prism shards with sparkling angular debris whenever touched or intersected.
  4. **Galaxy Swirl**: Multi-arm logarithmic spiral nebulas with stardust trails, differential angular momentum, and harmonic orbital resonance that swirls around single or multi-touch centroids.
- **Confirmed Decision 2 — Passive Kinetic Coin Progression & Unlocks**:
  - Actively touching, swirling, and energizing particles fills a kinetic charge meter and passively generates **Flux Coins** directly on the canvas (with optional floating coin orbs that magnetize toward your finger).
  - Coins are spent in the interactive **Modes & Palettes Vault** to unlock the 3 locked physics modes, purchase vibrant **AMOLED Color Palettes** (e.g., *Cyber Cyberpunk*, *Solar Flare*, *Bioluminescent Abyss*, *Prismatic Hyperdrive*, *Emerald Matrix*), and boost passive coin yield or particle count.
- **Confirmed Decision 3 — Procedural Harmonic Synth Audio & Haptic Engine**:
  - Real-time offline PCM audio synthesizer (`AudioTrack`) generating pentatonic harmonic synth chimes, warm sub-bass pulses proportional to particle velocity, and crisp dual-tone UI clicks/unlock fanfares.
  - Multi-layered tactile haptic controller (`Vibrator` / `VibrationEffect`) delivering crisp tick pulses on particle collisions, rhythmic throbs during Black Hole / Galaxy vortexes, and springy confirmation snaps on every UI button press.

---

## 1. Overview & Core Concept

- **What It Does**: Transforms the device screen into a living, zero-latency kinetic canvas where every touch, drag, pinch, or tap manipulates thousands of glowing particles across four distinct physics engines, accompanied by synchronized harmonic synth soundscapes and rich physical vibration patterns.
- **Target Audience / Persona**: Mobile users seeking a deeply satisfying, sensory-rich tactile fidget and visual relaxation experience that showcases AMOLED contrast and high-refresh-rate fluidity completely offline.
- **Key Value**: Combines immediate sensory gratification (visual glow, harmonic synth chimes, and nuanced haptics) with a meaningful progression loop (earning Flux Coins while playing to unlock new physics modes, AMOLED color palettes, and kinetic upgrades).

---

## 2. User Experience & Visual Design

- **Key User Flows**:
  1. **Immediate Canvas Immersion**: Launching the app drops the user directly into the pitch-black `#000000` AMOLED particle canvas running **Black Hole** mode at 60–120 FPS. Touching and dragging immediately spawns gravitational wells, triggers harmonic synth chimes, pulses tactile haptics, and begins generating Flux Coins.
  2. **Satisfying Modes & Vault Drawer**: Tapping the spring-animated, glowing **Modes & Vault** pill button triggers a crisp synth chord, a tactile snap, and a particle burst around the button before expanding a translucent glassmorphic bottom sheet over the live canvas.
  3. **Unlocking Modes & Color Palettes**: Inside the drawer, users can switch between unlocked modes, preview and purchase locked modes (**Slime Bounce**, **Laser Shatter**, **Galaxy Swirl**) or **AMOLED Color Palettes** using earned Flux Coins, and celebrate unlocks with a custom shockwave animation, harmonic arpeggio fanfare, and celebratory haptic cascade.
  4. **Quick HUD Controls**: A minimal, auto-dimming floating HUD at the top displays the animated Flux Coin counter, active kinetic multiplier badge, quick sound/haptic toggles, and a particle burst / clear button.

- **Visual Identity & Theme**:
  - *Aesthetic Direction*: **AMOLED Luminescent Cyber-Kinetic** — pure `#000000` pixels for infinite contrast and battery savings on OLED screens, juxtaposed against hyper-saturated neon additive-blended particle cores and translucent floating HUD pills.
  - *Color Palette & Mood*:
    - `--background`: `#000000` (True AMOLED Black)
    - `--surface`: `#0A0D14` with `75%` alpha and luminous border strokes for floating HUD & sheets
    - `--primary`: `#00F5D4` (Bioluminescent Cyan)
    - `--secondary`: `#FF2A85` (Hyper-Magenta)
    - `--accent`: `#FFD166` (Flux Gold for coin counters, multipliers, and unlock bursts)
  - *Typography & Hierarchy*:
    - **Display / Headers & Coin Counters**: `Space Grotesk` (bundled locally) for geometric, futuristic headlines and tabular numeric readouts.
    - **Body & Controls**: `Plus Jakarta Sans` (bundled locally) for crisp legibility on compact badges and mode cards.
  - *Component Styling & Layout*: Edge-to-edge full-bleed interactive canvas (`enableEdgeToEdge()`) with safe-area-padded floating top HUD pills and a spring-physics bottom control bar featuring an iconic, glowing **Modes** switcher button.

- **Interactive Feedback & Motion**:
  - **Epic Modes Button**: Features a continuous subtle orbital glow ring, spring-scale press physics (`spring(dampingRatio = Spring.DampingRatioLowBouncy)`), shockwave ripple ring on tap, and synchronized dual-tone synth + haptic click.
  - **Kinetic Coin Popups**: Passive coin ticks spawn subtle golden micro-sparks that arc into the top coin counter, scaling the counter badge with a spring bounce.

---

## 3. Key Product Decisions & Trade-Offs

- **Decision 1: Custom Zero-Allocation Particle Engine on Compose `Canvas`**
  - *Chosen Approach*: Pre-allocated primitive arrays (`FloatArray` / fixed pool of particle structs) updated via `withFrameNanos` inside a full-screen Jetpack Compose `Canvas` with additive blend modes (`BlendMode.Plus`).
  - *Why*: Eliminates garbage collection pauses during 60/120 FPS rendering, keeping touch latency near zero while rendering glowing trails and blooms on AMOLED screens.
  - *Alternatives Considered*: Object-per-particle lists or standard Compose `Animatable` per particle, which cause frame drops above a few hundred particles.
- **Decision 2: Real-Time Procedural PCM Synth (`AudioTrack`) Instead of Static Audio Files**
  - *Chosen Approach*: A dedicated low-latency polyphonic synthesizer thread generating harmonic pentatonic sine/triangle chimes, FM bass swells, and crisp UI percussive clicks in real time.
  - *Why*: Works 100% offline with zero asset bloat, never sounds repetitive, and dynamically shifts pitch and timbre based on touch velocity, active physics mode, and combo energy.
  - *Alternatives Considered*: Pre-recorded MP3/WAV samples, which sound repetitive when triggered rapidly and cannot dynamically harmonize with live particle physics.
- **Decision 3: Local Offline Persistence via Room Database**
  - *Chosen Approach*: Store player progression (Flux Coin balance, unlocked modes, unlocked AMOLED color palettes, selected mode/palette,upgrade levels, and lifetime kinetic stats) in a local Room SQLite database.
  - *Why*: Guarantees instant offline load/save reliability with reactive `Flow` state updates and zero network dependency.
  - *Alternatives Considered*: In-memory state (loses unlocked modes on app restart) or cloud persistence (violates the 100% offline requirement).

---

## 4. Technical Architecture & Data Strategy *(Technical Reference)*

- **Architecture & Component Diagram**:

```
┌───────────────────────────────────────────────────────────────────────────┐
│                         UI Layer (Jetpack Compose)                        │
│                                                                           │
│  ┌─────────────────────────────────────────────────────────────────────┐  │
│  │                 AMOLED Particle Canvas (BlendMode.Plus)             │  │
│  │   • Multi-Touch Gesture Tracker (PointerInput / Velocity / Pinch)   │  │
│  │   • 4 Physics Solvers: Black Hole | Slime | Laser | Galaxy Swirl    │  │
│  │   • Floating Flux Orbs & UI Burst Shockwave Renderer                │  │
│  └───────────────┬─────────────────────────────────────┬───────────────┘  │
│                  │                                     │                  │
│  ┌───────────────▼───────────────┐     ┌───────────────▼───────────────┐  │
│  │   Floating Top Kinetic HUD    │     │  Epic Modes & Vault Switcher  │  │
│  │ • Animated Flux Coin Counter  │     │ • Bouncy Spring Modes Button  │  │
│  │ • Kinetic Energy & Multiplier │     │ • 4 Mode Cards (Select/Buy)   │  │
│  │ • Audio / Haptic Quick Toggles│     │ • AMOLED Palette & Boost Shop │  │
│  └───────────────┬───────────────┘     └───────────────┬───────────────┘  │
└──────────────────┼─────────────────────────────────────┼──────────────────┘
                   │            StateFlow / Intents      │
┌──────────────────▼─────────────────────────────────────▼──────────────────┐
│                     ParticleSandboxViewModel (MVVM)                       │
│  • Coordinates active mode, palette, kinetic energy & passive coin ticks  │
│  • Dispatches tactile & audio triggers on touch, collision & UI actions   │
└───────┬──────────────────────────┬───────────────────────────┬────────────┘
        │                          │                           │
┌───────▼──────────┐    ┌──────────▼───────────┐    ┌──────────▼────────────┐
│  Room Repository │    │ Procedural Synth     │    │ Tactile Haptic Engine │
│  & PlayerDao     │    │ Audio Engine         │    │ (Vibrator / Effects)  │
│ • Coin Balance   │    │ • Harmonic Chimes    │    │ • Collision Micro-Tick│
│ • Unlocked Modes │    │ • Vortex Bass Pulse  │    │ • Vortex Pulse Throb  │
│ • Color Palettes │    │ • UI Click & Fanfare │    │ • UI Button Snap      │
└──────────────────┘    └──────────────────────┘    └───────────────────────┘
```

- **Data Model & State**:
  - `PlayerProfileEntity` (Room `@Entity`):
    - `id`: Singleton profile key (`1`)
    - `coins`: Current Flux Coin balance (`Long`)
    - `totalCoinsEarned`: Lifetime earned coins (`Long`)
    - `selectedModeId`: Active particle mode identifier (`BLACK_HOLE`, `SLIME_BOUNCE`, `LASER_SHATTER`, `GALAXY_SWIRL`)
    - `unlockedModesCsv`: Comma-separated list of unlocked mode IDs
    - `selectedPaletteId`: Active AMOLED color palette identifier
    - `unlockedPalettesCsv`: Comma-separated list of unlocked palette IDs
    - `particleCountLevel`: Upgrade level increasing active particle count (`Int`)
    - `coinYieldLevel`: Upgrade level increasing passive kinetic coin generation rate (`Int`)
    - `soundEnabled` / `hapticsEnabled`: User preference booleans
- **Interactive Component & State Mapping**:
  - **Multi-Touch Canvas Gestures**:
    - `onTouchDown`: Emits a crisp tactile impact pulse, triggers a root pentatonic synth note, and spawns a focal attractor/emitter at the pointer coordinate.
    - `onTouchMove`: Accumulates kinetic energy proportional to pointer movement and active particle excitement; every kinetic threshold tick awards passive Flux Coins with a subtle chime and coin badge bounce.
    - `onTouchUp`: Releases accumulated energy (e.g., Black Hole supernova burst or Slime rebound wave) with a resonant bass swell and haptic release wave.
  - **Epic Modes Button & Vault Modal**:
    - Tapping the **Modes** button triggers a spring compression/expansion animation, spawns UI celebration sparks, plays a harmonic synth chord, and opens the Vault pager/tabs (*Modes*, *AMOLED Palettes*, *Kinetic Upgrades*).
    - Tapping a locked Mode or Palette validates `coins >= cost`, deducts the price via `PlayerRepository`, persists the unlock in Room, automatically equips the new item, and plays a celebratory arpeggio + multi-step haptic burst.
