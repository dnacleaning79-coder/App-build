package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.model.AmoledPalette
import com.example.model.ParticleMode
import com.example.physics.AmoledParticleEngine
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read app_name and verify particle modes and engine`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("VoidPulse", appName)
        assertEquals(4, ParticleMode.entries.size)
        assertTrue(AmoledPalette.entries.size >= 5)

        val engine = AmoledParticleEngine(maxCapacity = 400)
        engine.ensureInitialized(1080f, 1920f, 280)
        engine.touchPoints[0].apply {
            x = 540f
            y = 960f
            active = true
        }
        ParticleMode.entries.forEach { mode ->
            engine.stepPhysics(
                dtSec = 0.016f,
                mode = mode,
                forceLevel = 2,
                harvesterLevel = 2,
                onCoinCollected = { _, _ -> },
                onCollisionPulse = {}
            )
        }
        assertTrue(engine.kineticMultiplier >= 1.0f)
    }
}
