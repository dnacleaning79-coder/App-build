package com.example.model

import androidx.compose.ui.graphics.Color

enum class ParticleMode(
    val id: String,
    val title: String,
    val tagline: String,
    val description: String,
    val physicsBadge: String,
    val costCoins: Long,
    val accentColor: Color,
    val secondaryColor: Color,
    val scaleHz: FloatArray
) {
    BLACK_HOLE(
        id = "BLACK_HOLE",
        title = "Black Hole",
        tagline = "Gravitational Singularity & Accretion Rings",
        description = "Spawns intense gravitational wells that bend spacetime trajectories, whip particles into glowing relativistic spirals, and detonate Hawking radiation shockwaves on release.",
        physicsBadge = "GRAVITY VORTEX",
        costCoins = 0L,
        accentColor = Color(0xFF00F5D4),
        secondaryColor = Color(0xFF9B5DE5),
        scaleHz = floatArrayOf(220.0f, 261.63f, 293.66f, 329.63f, 392.0f, 440.0f, 523.25f)
    ),
    SLIME_BOUNCE(
        id = "SLIME_BOUNCE",
        title = "Slime Bounce",
        tagline = "Elastic Tendrils & Jiggly Neon Blobs",
        description = "High-viscosity elastic droplets linked by glowing spring-tension tendrils that squish, ricochet off screen walls, and coalesce into bouncy bio-gel clusters around your touch.",
        physicsBadge = "ELASTIC WEB",
        costCoins = 120L,
        accentColor = Color(0xFF70E000),
        secondaryColor = Color(0xFF00F5D4),
        scaleHz = floatArrayOf(261.63f, 293.66f, 329.63f, 392.0f, 440.0f, 523.25f, 587.33f)
    ),
    LASER_SHATTER(
        id = "LASER_SHATTER",
        title = "Laser Shatter",
        tagline = "Ricochet Beams & Prismatic Shards",
        description = "Hyper-velocity photon vectors that reflect off boundaries with razor-sharp trails and fracture into geometric crystal shards and sparks whenever your finger slices through.",
        physicsBadge = "PHOTON SHARDS",
        costCoins = 280L,
        accentColor = Color(0xFFFF2A85),
        secondaryColor = Color(0xFFFFD166),
        scaleHz = floatArrayOf(329.63f, 392.0f, 440.0f, 493.88f, 587.33f, 659.25f, 783.99f)
    ),
    GALAXY_SWIRL(
        id = "GALAXY_SWIRL",
        title = "Galaxy Swirl",
        tagline = "Multi-Arm Spiral Nebula & Harmonic Orbits",
        description = "Logarithmic spiral arms of cosmic stardust with differential angular momentum that weave hypnotic multi-touch constellations and resonant harmonic chords.",
        physicsBadge = "COSMIC SPIRAL",
        costCoins = 500L,
        accentColor = Color(0xFFFFD166),
        secondaryColor = Color(0xFF00BBF9),
        scaleHz = floatArrayOf(196.0f, 246.94f, 293.66f, 369.99f, 392.0f, 493.88f, 587.33f)
    );

    companion object {
        fun fromId(id: String): ParticleMode =
            entries.firstOrNull { it.id == id } ?: BLACK_HOLE
    }
}

enum class AmoledPalette(
    val id: String,
    val title: String,
    val subtitle: String,
    val costCoins: Long,
    val colors: List<Color>
) {
    CYBER_NEON(
        id = "CYBER_NEON",
        title = "Cyber Pulse",
        subtitle = "Bioluminescent Cyan, Hyper-Magenta & Electric Violet",
        costCoins = 0L,
        colors = listOf(
            Color(0xFF00F5D4),
            Color(0xFFFF2A85),
            Color(0xFF9B5DE5),
            Color(0xFF00BBF9)
        )
    ),
    SOLAR_FLARE(
        id = "SOLAR_FLARE",
        title = "Solar Corona",
        subtitle = "Supernova Gold, Plasma Orange & Crimson Core",
        costCoins = 90L,
        colors = listOf(
            Color(0xFFFFD166),
            Color(0xFFFF6B35),
            Color(0xFFFF0054),
            Color(0xFFFFF3B0)
        )
    ),
    ABYSSAL_BIOLUME(
        id = "ABYSSAL_BIOLUME",
        title = "Abyssal Trench",
        subtitle = "Deep Sea Aqua, Electric Lime & Sapphire Glow",
        costCoins = 160L,
        colors = listOf(
            Color(0xFF70E000),
            Color(0xFF00F5D4),
            Color(0xFF0096C7),
            Color(0xFFB5E48C)
        )
    ),
    PRISMATIC_HYPER(
        id = "PRISMATIC_HYPER",
        title = "Prismatic Overdrive",
        subtitle = "Full-Spectrum Neon Chromatic Refraction",
        costCoins = 260L,
        colors = listOf(
            Color(0xFFFF007F),
            Color(0xFF00F5D4),
            Color(0xFFFFBE0B),
            Color(0xFF8338EC)
        )
    ),
    ROYAL_SUPERNOVA(
        id = "ROYAL_SUPERNOVA",
        title = "Astral Crown",
        subtitle = "Celestial Gold, Ultraviolet & Rose Quartz",
        costCoins = 400L,
        colors = listOf(
            Color(0xFFFFD700),
            Color(0xFFC77DFF),
            Color(0xFFFF758F),
            Color(0xFFE0AAFF)
        )
    );

    companion object {
        fun fromId(id: String): AmoledPalette =
            entries.firstOrNull { it.id == id } ?: CYBER_NEON
    }
}

enum class KineticUpgradeType(
    val id: String,
    val title: String,
    val description: String,
    val baseCost: Long,
    val maxLevel: Int
) {
    PARTICLE_DENSITY(
        id = "PARTICLE_DENSITY",
        title = "Particle Swarm Density",
        description = "Increases active glowing particles on the AMOLED canvas (+85 particles per level).",
        baseCost = 75L,
        maxLevel = 6
    ),
    COIN_HARVESTER(
        id = "COIN_HARVESTER",
        title = "Flux Coin Harvester",
        description = "Boosts passive Flux Coin yield & spawns golden magnetic orbs faster while touching.",
        baseCost = 85L,
        maxLevel = 6
    ),
    GRAVITY_AMPLIFIER(
        id = "GRAVITY_AMPLIFIER",
        title = "Kinetic Force Amplifier",
        description = "Amplifies touch attraction radius, shockwave power, and harmonic resonance.",
        baseCost = 100L,
        maxLevel = 5
    );

    fun costForNextLevel(currentLevel: Int): Long {
        if (currentLevel >= maxLevel) return 0L
        return baseCost * currentLevel + (currentLevel - 1) * 45L
    }
}
