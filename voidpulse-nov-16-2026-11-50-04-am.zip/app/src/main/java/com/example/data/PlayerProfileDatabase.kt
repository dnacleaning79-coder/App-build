package com.example.data

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.model.AmoledPalette
import com.example.model.KineticUpgradeType
import com.example.model.ParticleMode
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "player_profile")
data class PlayerProfileEntity(
    @PrimaryKey val id: Int = 1,
    val coins: Long = 60L,
    val totalCoinsEarned: Long = 60L,
    val selectedModeId: String = ParticleMode.BLACK_HOLE.id,
    val unlockedModesCsv: String = ParticleMode.BLACK_HOLE.id,
    val selectedPaletteId: String = AmoledPalette.CYBER_NEON.id,
    val unlockedPalettesCsv: String = AmoledPalette.CYBER_NEON.id,
    val particleDensityLevel: Int = 1,
    val coinHarvesterLevel: Int = 1,
    val gravityAmplifierLevel: Int = 1,
    val soundEnabled: Boolean = true,
    val hapticsEnabled: Boolean = true,
    val trailsEnabled: Boolean = true
) {
    fun unlockedModesSet(): Set<String> =
        unlockedModesCsv.split(",").map { it.trim() }.filter { it.isNotEmpty() }.toSet()

    fun unlockedPalettesSet(): Set<String> =
        unlockedPalettesCsv.split(",").map { it.trim() }.filter { it.isNotEmpty() }.toSet()

    fun isModeUnlocked(mode: ParticleMode): Boolean =
        mode.costCoins == 0L || unlockedModesSet().contains(mode.id)

    fun isPaletteUnlocked(palette: AmoledPalette): Boolean =
        palette.costCoins == 0L || unlockedPalettesSet().contains(palette.id)

    fun levelForUpgrade(type: KineticUpgradeType): Int = when (type) {
        KineticUpgradeType.PARTICLE_DENSITY -> particleDensityLevel
        KineticUpgradeType.COIN_HARVESTER -> coinHarvesterLevel
        KineticUpgradeType.GRAVITY_AMPLIFIER -> gravityAmplifierLevel
    }
}

@Dao
interface PlayerProfileDao {
    @Query("SELECT * FROM player_profile WHERE id = 1")
    fun observeProfile(): Flow<PlayerProfileEntity?>

    @Query("SELECT * FROM player_profile WHERE id = 1")
    suspend fun getProfileOnce(): PlayerProfileEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertProfile(profile: PlayerProfileEntity)
}

@Database(entities = [PlayerProfileEntity::class], version = 1, exportSchema = false)
abstract class VoidPulseDatabase : RoomDatabase() {
    abstract fun playerProfileDao(): PlayerProfileDao

    companion object {
        @Volatile
        private var INSTANCE: VoidPulseDatabase? = null

        fun getInstance(context: Context): VoidPulseDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    VoidPulseDatabase::class.java,
                    "voidpulse_offline.db"
                ).fallbackToDestructiveMigration(dropAllTables = true).build()
                INSTANCE = instance
                instance
            }
        }
    }
}

class PlayerRepository(private val dao: PlayerProfileDao) {
    val profileFlow: Flow<PlayerProfileEntity?> = dao.observeProfile()

    suspend fun ensureInitialized(): PlayerProfileEntity {
        val existing = dao.getProfileOnce()
        if (existing != null) return existing
        val initial = PlayerProfileEntity()
        dao.upsertProfile(initial)
        return initial
    }

    suspend fun addCoins(amount: Long) {
        if (amount <= 0L) return
        val current = ensureInitialized()
        dao.upsertProfile(
            current.copy(
                coins = current.coins + amount,
                totalCoinsEarned = current.totalCoinsEarned + amount
            )
        )
    }

    suspend fun selectOrUnlockMode(mode: ParticleMode): Boolean {
        val current = ensureInitialized()
        if (current.isModeUnlocked(mode)) {
            dao.upsertProfile(current.copy(selectedModeId = mode.id))
            return false // already unlocked, just selected
        }
        if (current.coins < mode.costCoins) return false
        val updatedModes = (current.unlockedModesSet() + mode.id).joinToString(",")
        dao.upsertProfile(
            current.copy(
                coins = current.coins - mode.costCoins,
                selectedModeId = mode.id,
                unlockedModesCsv = updatedModes
            )
        )
        return true // newly unlocked!
    }

    suspend fun selectOrUnlockPalette(palette: AmoledPalette): Boolean {
        val current = ensureInitialized()
        if (current.isPaletteUnlocked(palette)) {
            dao.upsertProfile(current.copy(selectedPaletteId = palette.id))
            return false
        }
        if (current.coins < palette.costCoins) return false
        val updatedPalettes = (current.unlockedPalettesSet() + palette.id).joinToString(",")
        dao.upsertProfile(
            current.copy(
                coins = current.coins - palette.costCoins,
                selectedPaletteId = palette.id,
                unlockedPalettesCsv = updatedPalettes
            )
        )
        return true
    }

    suspend fun purchaseUpgrade(type: KineticUpgradeType): Boolean {
        val current = ensureInitialized()
        val level = current.levelForUpgrade(type)
        if (level >= type.maxLevel) return false
        val cost = type.costForNextLevel(level)
        if (current.coins < cost) return false
        val next = when (type) {
            KineticUpgradeType.PARTICLE_DENSITY -> current.copy(
                coins = current.coins - cost,
                particleDensityLevel = level + 1
            )
            KineticUpgradeType.COIN_HARVESTER -> current.copy(
                coins = current.coins - cost,
                coinHarvesterLevel = level + 1
            )
            KineticUpgradeType.GRAVITY_AMPLIFIER -> current.copy(
                coins = current.coins - cost,
                gravityAmplifierLevel = level + 1
            )
        }
        dao.upsertProfile(next)
        return true
    }

    suspend fun toggleSound(): Boolean {
        val current = ensureInitialized()
        val nextState = !current.soundEnabled
        dao.upsertProfile(current.copy(soundEnabled = nextState))
        return nextState
    }

    suspend fun toggleHaptics(): Boolean {
        val current = ensureInitialized()
        val nextState = !current.hapticsEnabled
        dao.upsertProfile(current.copy(hapticsEnabled = nextState))
        return nextState
    }

    suspend fun toggleTrails(): Boolean {
        val current = ensureInitialized()
        val nextState = !current.trailsEnabled
        dao.upsertProfile(current.copy(trailsEnabled = nextState))
        return nextState
    }
}
