package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import com.example.model.AmoledPalette
import com.example.model.ParticleMode
import com.example.physics.AmoledParticleEngine
import com.example.ui.theme.AmoledBlack
import com.example.ui.theme.FluxGold
import kotlin.math.hypot
import kotlin.math.sin
import kotlinx.coroutines.isActive

@Composable
fun AmoledParticleCanvas(
    engine: AmoledParticleEngine,
    mode: ParticleMode,
    palette: AmoledPalette,
    forceLevel: Int,
    harvesterLevel: Int,
    targetParticleCount: Int,
    trailsEnabled: Boolean,
    onTouchDown: (Int, Float, Float, Float) -> Unit,
    onTouchMove: (Int, Float, Float, Float) -> Unit,
    onTouchUp: (Int) -> Unit,
    onCoinCollected: (Long, Offset) -> Unit,
    onCollisionPulse: (Float) -> Unit,
    modifier: Modifier = Modifier
) {
    var frameTick by remember { mutableLongStateOf(0L) }
    val currentMode by rememberUpdatedState(mode)
    val currentForceLevel by rememberUpdatedState(forceLevel)
    val currentHarvesterLevel by rememberUpdatedState(harvesterLevel)
    val currentOnCoin by rememberUpdatedState(onCoinCollected)
    val currentOnCollision by rememberUpdatedState(onCollisionPulse)

    LaunchedEffect(Unit) {
        var lastNanos = 0L
        while (isActive) {
            withFrameNanos { nanos ->
                val dtSec = if (lastNanos == 0L) {
                    0.016f
                } else {
                    ((nanos - lastNanos) / 1_000_000_000f).coerceIn(0.001f, 0.04f)
                }
                lastNanos = nanos
                engine.stepPhysics(
                    dtSec = dtSec,
                    mode = currentMode,
                    forceLevel = currentForceLevel,
                    harvesterLevel = currentHarvesterLevel,
                    onCoinCollected = currentOnCoin,
                    onCollisionPulse = currentOnCollision
                )
                frameTick = nanos
            }
        }
    }

    val paletteColors = palette.colors

    Canvas(
        modifier = modifier
            .fillMaxSize()
            .background(AmoledBlack)
            .testTag("amoled_particle_canvas")
            .pointerInput(Unit) {
                awaitEachGesture {
                    val activeSlots = mutableMapOf<Long, Int>()
                    var nextSlot = 0
                    do {
                        val event = awaitPointerEvent()
                        val heightPx = size.height.coerceAtLeast(1).toFloat()

                        for (change in event.changes) {
                            val pointerId = change.id.value
                            val pos = change.position
                            val normY = (pos.y / heightPx).coerceIn(0f, 1f)

                            if (change.pressed) {
                                val existingSlot = activeSlots[pointerId]
                                if (existingSlot == null) {
                                    val assigned = nextSlot % 5
                                    nextSlot++
                                    activeSlots[pointerId] = assigned
                                    onTouchDown(assigned, pos.x, pos.y, normY)
                                } else {
                                    onTouchMove(existingSlot, pos.x, pos.y, normY)
                                }
                                change.consume()
                            } else {
                                val releasedSlot = activeSlots.remove(pointerId)
                                if (releasedSlot != null) {
                                    onTouchUp(releasedSlot)
                                }
                            }
                        }
                    } while (event.changes.any { it.pressed })

                    activeSlots.values.forEach { slot ->
                        onTouchUp(slot)
                    }
                }
            }
    ) {
        // Read frameTick so Compose redraws on every vsync frame
        val tick = frameTick
        if (tick < 0L) return@Canvas

        engine.ensureInitialized(size.width, size.height, targetParticleCount)
        val count = engine.activeCount

        // 1. Render Mode-Specific Ambient & Touch Singularities on True Black AMOLED
        for (tIndex in engine.touchPoints.indices) {
            val tp = engine.touchPoints[tIndex]
            if (!tp.active) continue
            val center = Offset(tp.x, tp.y)
            val primaryColor = paletteColors[tIndex % paletteColors.size]
            val secondaryColor = paletteColors[(tIndex + 1) % paletteColors.size]

            when (mode) {
                ParticleMode.BLACK_HOLE -> {
                    // Glowing Accretion Halo + Dark Singularity Core
                    drawCircle(
                        brush = Brush.radialGradient(
                            colors = listOf(
                                Color.Black,
                                primaryColor.copy(alpha = 0.65f),
                                secondaryColor.copy(alpha = 0.22f),
                                Color.Transparent
                            ),
                            center = center,
                            radius = 185f
                        ),
                        radius = 185f,
                        center = center,
                        blendMode = BlendMode.Plus
                    )
                    drawCircle(
                        color = Color.Black,
                        radius = 34f,
                        center = center
                    )
                    drawCircle(
                        color = primaryColor.copy(alpha = 0.9f),
                        radius = 37f,
                        center = center,
                        style = Stroke(width = 3.5f),
                        blendMode = BlendMode.Plus
                    )
                }

                ParticleMode.SLIME_BOUNCE -> {
                    drawCircle(
                        brush = Brush.radialGradient(
                            colors = listOf(
                                primaryColor.copy(alpha = 0.42f),
                                secondaryColor.copy(alpha = 0.14f),
                                Color.Transparent
                            ),
                            center = center,
                            radius = 160f
                        ),
                        radius = 160f,
                        center = center,
                        blendMode = BlendMode.Plus
                    )
                }

                ParticleMode.LASER_SHATTER -> {
                    // Geometric prism diamond reticle
                    drawCircle(
                        color = primaryColor.copy(alpha = 0.55f),
                        radius = 95f,
                        center = center,
                        style = Stroke(width = 3f),
                        blendMode = BlendMode.Plus
                    )
                    drawCircle(
                        color = Color.White.copy(alpha = 0.85f),
                        radius = 14f,
                        center = center,
                        blendMode = BlendMode.Plus
                    )
                }

                ParticleMode.GALAXY_SWIRL -> {
                    drawCircle(
                        brush = Brush.radialGradient(
                            colors = listOf(
                                Color.White.copy(alpha = 0.75f),
                                primaryColor.copy(alpha = 0.45f),
                                secondaryColor.copy(alpha = 0.16f),
                                Color.Transparent
                            ),
                            center = center,
                            radius = 220f
                        ),
                        radius = 220f,
                        center = center,
                        blendMode = BlendMode.Plus
                    )
                }
            }
        }

        // 2. Slime Mode Elastic Tendril Web between nearby particles
        if (mode == ParticleMode.SLIME_BOUNCE) {
            val step = 3
            val maxLinkDist = 118f
            for (i in 0 until count step step) {
                val x1 = engine.px[i]
                val y1 = engine.py[i]
                val c = paletteColors[engine.colorIdx[i] % paletteColors.size]
                for (j in (i + step) until (i + 24).coerceAtMost(count) step step) {
                    val dx = engine.px[j] - x1
                    val dy = engine.py[j] - y1
                    if (kotlin.math.abs(dx) < maxLinkDist && kotlin.math.abs(dy) < maxLinkDist) {
                        val d = hypot(dx, dy)
                        if (d < maxLinkDist) {
                            val linkAlpha = ((1f - d / maxLinkDist) * 0.48f).coerceIn(0f, 1f)
                            drawLine(
                                color = c.copy(alpha = linkAlpha),
                                start = Offset(x1, y1),
                                end = Offset(engine.px[j], engine.py[j]),
                                strokeWidth = 2.6f,
                                cap = StrokeCap.Round,
                                blendMode = BlendMode.Plus
                            )
                        }
                    }
                }
            }
        }

        // 3. Render Main Particles & Velocity Glow Trails
        val trailFactor = when {
            !trailsEnabled -> 0f
            mode == ParticleMode.LASER_SHATTER -> 3.4f
            mode == ParticleMode.GALAXY_SWIRL -> 2.1f
            mode == ParticleMode.BLACK_HOLE -> 1.85f
            else -> 1.15f
        }

        for (i in 0 until count) {
            val x = engine.px[i]
            val y = engine.py[i]
            val e = engine.energy[i]
            val baseColor = paletteColors[engine.colorIdx[i] % paletteColors.size]
            val radius = engine.baseSize[i] * (0.85f + e * 0.65f)

            if (trailFactor > 0f) {
                val tailX = x - engine.vx[i] * 0.022f * trailFactor
                val tailY = y - engine.vy[i] * 0.022f * trailFactor
                drawLine(
                    color = baseColor.copy(alpha = (0.28f + e * 0.45f).coerceAtMost(0.85f)),
                    start = Offset(tailX, tailY),
                    end = Offset(x, y),
                    strokeWidth = radius * (if (mode == ParticleMode.LASER_SHATTER) 1.35f else 1.1f),
                    cap = StrokeCap.Round,
                    blendMode = BlendMode.Plus
                )
            }

            // Outer luminescent bloom
            drawCircle(
                color = baseColor.copy(alpha = (0.18f + e * 0.24f).coerceAtMost(0.55f)),
                radius = radius * 2.35f,
                center = Offset(x, y),
                blendMode = BlendMode.Plus
            )

            // Crisp neon core
            drawCircle(
                color = if (e > 0.78f) Color.White else baseColor,
                radius = radius * 0.78f,
                center = Offset(x, y),
                blendMode = BlendMode.Plus
            )
        }

        // 4. Render Shatter Shards
        for (s in engine.shards) {
            if (!s.active) continue
            val shardColor = paletteColors[s.colorIndex % paletteColors.size]
            val alpha = s.life.coerceIn(0f, 1f)
            drawLine(
                color = shardColor.copy(alpha = alpha),
                start = Offset(s.x, s.y),
                end = Offset(s.x - s.vx * 0.028f, s.y - s.vy * 0.028f),
                strokeWidth = 4.2f,
                cap = StrokeCap.Round,
                blendMode = BlendMode.Plus
            )
        }

        // 5. Render Expanding Shockwaves
        for (sw in engine.shockwaves) {
            if (!sw.active) continue
            val swColor = paletteColors[sw.colorIndex % paletteColors.size]
            drawCircle(
                color = swColor.copy(alpha = sw.alpha * 0.75f),
                radius = sw.radius,
                center = Offset(sw.x, sw.y),
                style = Stroke(width = 4.5f + (1f - sw.alpha) * 6f),
                blendMode = BlendMode.Plus
            )
        }

        // 6. Render Magnetic Golden Flux Coin Orbs
        for (orb in engine.fluxOrbs) {
            if (!orb.active) continue
            val pulse = 1f + sin(orb.pulsePhase) * 0.22f
            val center = Offset(orb.x, orb.y)
            drawCircle(
                color = FluxGold.copy(alpha = 0.32f),
                radius = 30f * pulse,
                center = center,
                blendMode = BlendMode.Plus
            )
            drawCircle(
                color = FluxGold,
                radius = 13f * pulse,
                center = center,
                blendMode = BlendMode.Plus
            )
            drawCircle(
                color = Color.White,
                radius = 5.5f,
                center = center,
                blendMode = BlendMode.Plus
            )
        }
    }
}
