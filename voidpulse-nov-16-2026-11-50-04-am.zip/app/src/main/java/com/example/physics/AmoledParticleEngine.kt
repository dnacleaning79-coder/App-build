package com.example.physics

import androidx.compose.ui.geometry.Offset
import com.example.model.ParticleMode
import kotlin.math.PI
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.random.Random

class TouchPointState(
    var id: Long = -1L,
    var x: Float = 0f,
    var y: Float = 0f,
    var prevX: Float = 0f,
    var prevY: Float = 0f,
    var active: Boolean = false,
    var holdTimeSec: Float = 0f
)

class AmoledShockwave(
    var x: Float = 0f,
    var y: Float = 0f,
    var radius: Float = 0f,
    var maxRadius: Float = 600f,
    var alpha: Float = 0f,
    var colorIndex: Int = 0,
    var active: Boolean = false
)

class FluxCoinOrb(
    var x: Float = 0f,
    var y: Float = 0f,
    var vx: Float = 0f,
    var vy: Float = 0f,
    var pulsePhase: Float = 0f,
    var ageSec: Float = 0f,
    var coinValue: Long = 5L,
    var active: Boolean = false
)

class ShatterShard(
    var x: Float = 0f,
    var y: Float = 0f,
    var vx: Float = 0f,
    var vy: Float = 0f,
    var life: Float = 0f,
    var colorIndex: Int = 0,
    var active: Boolean = false
)

class AmoledParticleEngine(private val maxCapacity: Int = 780) {

    val px = FloatArray(maxCapacity)
    val py = FloatArray(maxCapacity)
    val prevX = FloatArray(maxCapacity)
    val prevY = FloatArray(maxCapacity)
    val vx = FloatArray(maxCapacity)
    val vy = FloatArray(maxCapacity)
    val baseSize = FloatArray(maxCapacity)
    val colorIdx = IntArray(maxCapacity)
    val phase = FloatArray(maxCapacity)
    val energy = FloatArray(maxCapacity)

    val touchPoints = Array(5) { TouchPointState() }
    val shockwaves = Array(8) { AmoledShockwave() }
    val fluxOrbs = Array(12) { FluxCoinOrb() }
    val shards = Array(96) { ShatterShard() }

    var activeCount: Int = 320
        private set

    var canvasWidth: Float = 1080f
        private set
    var canvasHeight: Float = 2200f
        private set

    private var initialized = false
    private var globalTimeSec = 0f
    private var passiveAccumulator = 0f
    private var orbSpawnAccumulator = 0f

    var kineticExcitement: Float = 0f
        private set

    var kineticMultiplier: Float = 1.0f
        private set

    fun ensureInitialized(width: Float, height: Float, targetCount: Int) {
        if (width <= 10f || height <= 10f) return
        canvasWidth = width
        canvasHeight = height
        activeCount = targetCount.coerceIn(180, maxCapacity)

        if (!initialized) {
            initialized = true
            val rng = Random(42)
            for (i in 0 until maxCapacity) {
                val x = rng.nextFloat() * width
                val y = rng.nextFloat() * height
                px[i] = x
                py[i] = y
                prevX[i] = x
                prevY[i] = y
                val angle = rng.nextFloat() * (2f * PI.toFloat())
                val speed = 45f + rng.nextFloat() * 140f
                vx[i] = cos(angle) * speed
                vy[i] = sin(angle) * speed
                baseSize[i] = 3.2f + rng.nextFloat() * 5.8f
                colorIdx[i] = i % 4
                phase[i] = rng.nextFloat() * (2f * PI.toFloat())
                energy[i] = 0.2f + rng.nextFloat() * 0.5f
            }
        }
    }

    fun updateTargetCount(count: Int) {
        activeCount = count.coerceIn(180, maxCapacity)
    }

    fun stepPhysics(
        dtSec: Float,
        mode: ParticleMode,
        forceLevel: Int,
        harvesterLevel: Int,
        onCoinCollected: (Long, Offset) -> Unit,
        onCollisionPulse: (Float) -> Unit
    ) {
        val dt = dtSec.coerceIn(0.001f, 0.035f)
        globalTimeSec += dt

        val w = canvasWidth
        val h = canvasHeight
        val centerX = w * 0.5f
        val centerY = h * 0.5f
        val forceAmp = 1f + (forceLevel - 1) * 0.24f

        var activeTouches = 0
        var touchCentroidX = 0f
        var touchCentroidY = 0f
        var touchMotionSpeed = 0f

        for (t in touchPoints) {
            if (t.active) {
                activeTouches++
                t.holdTimeSec += dt
                touchCentroidX += t.x
                touchCentroidY += t.y
                val moveDist = hypot(t.x - t.prevX, t.y - t.prevY)
                touchMotionSpeed += moveDist / dt
                t.prevX = t.x
                t.prevY = t.y
            }
        }

        if (activeTouches > 0) {
            touchCentroidX /= activeTouches
            touchCentroidY /= activeTouches
            val boost = (0.35f + (touchMotionSpeed / 2200f).coerceAtMost(0.85f)) * dt * 2.4f
            kineticExcitement = (kineticExcitement + boost).coerceAtMost(1.0f)
        } else {
            kineticExcitement = (kineticExcitement - dt * 0.38f).coerceAtLeast(0f)
        }

        val harvestBonus = 1f + (harvesterLevel - 1) * 0.35f
        kineticMultiplier = (1.0f + kineticExcitement * 3.0f * harvestBonus)

        // Passive coin generation & magnetic orb spawning while interacting
        if (activeTouches > 0 || kineticExcitement > 0.15f) {
            val rate = (if (activeTouches > 0) 1.35f else 0.45f) * (1f + kineticExcitement * 1.6f) * harvestBonus
            passiveAccumulator += dt * rate
            orbSpawnAccumulator += dt * rate

            if (passiveAccumulator >= 1.15f) {
                passiveAccumulator -= 1.15f
                val earned = (1L + harvesterLevel / 2L) * (if (kineticExcitement > 0.65f) 2L else 1L)
                val pos = if (activeTouches > 0) Offset(touchCentroidX, touchCentroidY) else Offset(centerX, centerY)
                onCoinCollected(earned, pos)
            }

            if (orbSpawnAccumulator >= 2.1f) {
                orbSpawnAccumulator = 0f
                spawnFluxOrb(
                    nearX = if (activeTouches > 0) touchCentroidX else centerX,
                    nearY = if (activeTouches > 0) touchCentroidY else centerY,
                    value = (3L + harvesterLevel * 2L)
                )
            }
        }

        var boundaryHits = 0
        val count = activeCount

        for (i in 0 until count) {
            var x = px[i]
            var y = py[i]
            var velX = vx[i]
            var velY = vy[i]

            prevX[i] = x
            prevY[i] = y

            when (mode) {
                ParticleMode.BLACK_HOLE -> {
                    // Ambient orbital drift around screen center when idle
                    val cx = if (activeTouches > 0) touchCentroidX else centerX
                    val cy = if (activeTouches > 0) touchCentroidY else centerY
                    val dx = cx - x
                    val dy = cy - y
                    val distSq = dx * dx + dy * dy + 900f
                    val dist = sqrt(distSq)
                    val nx = dx / dist
                    val ny = dy / dist

                    if (activeTouches > 0) {
                        // Intense singularity pull + relativistic accretion swirl
                        val pull = (980000f * forceAmp) / (distSq + 4500f)
                        val swirl = (540f * forceAmp) / (dist * 0.045f + 1f)
                        velX += (nx * pull - ny * swirl) * dt
                        velY += (ny * pull + nx * swirl) * dt

                        // Event horizon slingshot
                        if (dist < 46f) {
                            velX += (-ny * 620f + nx * 180f) * dt
                            velY += (nx * 620f + ny * 180f) * dt
                            energy[i] = 1.0f
                        }
                    } else {
                        val gentlePull = 65f
                        val gentleSwirl = 95f
                        velX += (nx * gentlePull - ny * gentleSwirl) * dt
                        velY += (ny * gentlePull + nx * gentleSwirl) * dt
                    }
                    velX *= 0.986f
                    velY *= 0.986f
                }

                ParticleMode.SLIME_BOUNCE -> {
                    // Gravity + elastic spring attraction to fingers + bouncy walls
                    velY += 180f * dt // downward slime drip
                    val phaseWave = sin(globalTimeSec * 4.5f + phase[i]) * 48f
                    velX += phaseWave * dt

                    for (t in touchPoints) {
                        if (!t.active) continue
                        val dx = t.x - x
                        val dy = t.y - y
                        val dist = hypot(dx, dy).coerceAtLeast(1f)
                        if (dist < 380f * forceAmp) {
                            // Elastic spring toward blob radius ~85px
                            val targetRadius = 82f
                            val displacement = dist - targetRadius
                            val springForce = displacement * 7.8f * forceAmp
                            velX += (dx / dist) * springForce * dt
                            velY += (dy / dist) * springForce * dt
                            energy[i] = (energy[i] + dt * 1.8f).coerceAtMost(1f)
                        }
                    }
                    velX *= 0.972f
                    velY *= 0.972f
                }

                ParticleMode.LASER_SHATTER -> {
                    // Maintain high minimum photon speed
                    val speed = hypot(velX, velY).coerceAtLeast(1f)
                    val targetSpeed = (460f + (i % 5) * 95f) * (1f + kineticExcitement * 0.45f)
                    velX = (velX / speed) * (speed + (targetSpeed - speed) * 0.12f)
                    velY = (velY / speed) * (speed + (targetSpeed - speed) * 0.12f)

                    for (t in touchPoints) {
                        if (!t.active) continue
                        val dx = x - t.x
                        val dy = y - t.y
                        val dist = hypot(dx, dy).coerceAtLeast(1f)
                        if (dist < 145f * forceAmp) {
                            // Shatter reflection off touch prism!
                            val nx = dx / dist
                            val ny = dy / dist
                            val dot = velX * nx + velY * ny
                            if (dot < 0f) {
                                velX -= 2.1f * dot * nx
                                velY -= 2.1f * dot * ny
                            } else {
                                velX += nx * 520f * dt
                                velY += ny * 520f * dt
                            }
                            energy[i] = 1f
                            if (i % 4 == 0) {
                                spawnShatterShards(x, y, colorIdx[i])
                            }
                            boundaryHits++
                        }
                    }
                }

                ParticleMode.GALAXY_SWIRL -> {
                    val cx = if (activeTouches > 0) touchCentroidX else centerX
                    val cy = if (activeTouches > 0) touchCentroidY else centerY
                    val dx = x - cx
                    val dy = y - cy
                    val r = hypot(dx, dy).coerceAtLeast(8f)
                    val theta = atan2(dy, dx)

                    // 3-arm logarithmic spiral target angle
                    val armIndex = i % 3
                    val armOffset = armIndex * (2f * PI.toFloat() / 3f)
                    val spiralAngle = theta + 0.32f * kotlin.math.ln(r / 35f + 1f) - globalTimeSec * 1.4f + armOffset
                    val spiralPush = sin(spiralAngle * 3f) * 145f * forceAmp

                    val tangentX = -dy / r
                    val tangentY = dx / r
                    val radialX = -dx / r
                    val radialY = -dy / r

                    val orbitalSpeed = (340f + 4200f / (r + 55f)) * (if (activeTouches > 0) 1.45f * forceAmp else 0.85f)
                    val radialSpring = (r - (120f + (i % 7) * 42f)) * 1.85f - spiralPush * 0.35f

                    val desiredVx = tangentX * orbitalSpeed + radialX * radialSpring
                    val desiredVy = tangentY * orbitalSpeed + radialY * radialSpring

                    velX += (desiredVx - velX) * 4.2f * dt
                    velY += (desiredVy - velY) * 4.2f * dt
                }
            }

            x += velX * dt
            y += velY * dt

            // Screen boundary handling
            val bounceRestitution = when (mode) {
                ParticleMode.SLIME_BOUNCE -> 0.92f
                ParticleMode.LASER_SHATTER -> 1.0f
                else -> 0.78f
            }

            if (x < 8f) {
                x = 8f
                velX = kotlin.math.abs(velX) * bounceRestitution
                boundaryHits++
            } else if (x > w - 8f) {
                x = w - 8f
                velX = -kotlin.math.abs(velX) * bounceRestitution
                boundaryHits++
            }

            if (y < 8f) {
                y = 8f
                velY = kotlin.math.abs(velY) * bounceRestitution
                boundaryHits++
            } else if (y > h - 8f) {
                y = h - 8f
                velY = -kotlin.math.abs(velY) * bounceRestitution
                boundaryHits++
            }

            val currentSpeed = hypot(velX, velY)
            energy[i] = ((currentSpeed / 680f) + energy[i] * 0.85f).coerceIn(0.15f, 1.0f)

            px[i] = x
            py[i] = y
            vx[i] = velX
            vy[i] = velY
        }

        if (boundaryHits > 6 && activeTouches > 0) {
            onCollisionPulse((boundaryHits / 28f).coerceIn(0.25f, 1f))
        }

        // Step shatter shards
        for (s in shards) {
            if (!s.active) continue
            s.x += s.vx * dt
            s.y += s.vy * dt
            s.life -= dt * 2.2f
            if (s.life <= 0f) s.active = false
        }

        // Step shockwaves
        for (sw in shockwaves) {
            if (!sw.active) continue
            sw.radius += dt * 920f
            sw.alpha = (1f - sw.radius / sw.maxRadius).coerceIn(0f, 1f)
            if (sw.radius >= sw.maxRadius) sw.active = false
        }

        // Step magnetic Flux Coin Orbs
        for (orb in fluxOrbs) {
            if (!orb.active) continue
            orb.ageSec += dt
            orb.pulsePhase += dt * 7f

            val targetX = if (activeTouches > 0) touchCentroidX else centerX
            val targetY = if (activeTouches > 0) touchCentroidY else 140f
            val dx = targetX - orb.x
            val dy = targetY - orb.y
            val dist = hypot(dx, dy).coerceAtLeast(1f)

            val magnetStrength = if (activeTouches > 0 || orb.ageSec > 1.8f) 1450f else 220f
            orb.vx = (orb.vx + (dx / dist) * magnetStrength * dt) * 0.94f
            orb.vy = (orb.vy + (dy / dist) * magnetStrength * dt) * 0.94f
            orb.x += orb.vx * dt
            orb.y += orb.vy * dt

            if (dist < 64f || orb.ageSec > 3.6f) {
                orb.active = false
                spawnShockwave(orb.x, orb.y, maxRadius = 210f, colorIndex = 2)
                onCoinCollected(orb.coinValue, Offset(orb.x, orb.y))
            }
        }
    }

    fun triggerSupernovaBurst(centerX: Float, centerY: Float, powerMultiplier: Float = 1f) {
        spawnShockwave(centerX, centerY, maxRadius = 880f, colorIndex = 0)
        spawnShockwave(centerX, centerY, maxRadius = 560f, colorIndex = 1)
        for (i in 0 until activeCount) {
            val dx = px[i] - centerX
            val dy = py[i] - centerY
            val dist = hypot(dx, dy).coerceAtLeast(12f)
            val impulse = (780f * powerMultiplier) * (1f - (dist / 1200f).coerceAtMost(0.75f))
            vx[i] += (dx / dist) * impulse
            vy[i] += (dy / dist) * impulse
            energy[i] = 1.0f
        }
        spawnShatterShards(centerX, centerY, 0, count = 18)
    }

    fun spawnShockwave(x: Float, y: Float, maxRadius: Float = 620f, colorIndex: Int = 0) {
        val slot = shockwaves.firstOrNull { !it.active } ?: shockwaves[0]
        slot.x = x
        slot.y = y
        slot.radius = 16f
        slot.maxRadius = maxRadius
        slot.alpha = 1f
        slot.colorIndex = colorIndex
        slot.active = true
    }

    private fun spawnFluxOrb(nearX: Float, nearY: Float, value: Long) {
        val slot = fluxOrbs.firstOrNull { !it.active } ?: return
        val angle = Random.nextFloat() * (2f * PI.toFloat())
        val radius = 110f + Random.nextFloat() * 140f
        slot.x = (nearX + cos(angle) * radius).coerceIn(60f, canvasWidth - 60f)
        slot.y = (nearY + sin(angle) * radius).coerceIn(140f, canvasHeight - 180f)
        slot.vx = -sin(angle) * 160f
        slot.vy = cos(angle) * 160f
        slot.pulsePhase = 0f
        slot.ageSec = 0f
        slot.coinValue = value
        slot.active = true
    }

    private fun spawnShatterShards(x: Float, y: Float, colorIndex: Int, count: Int = 4) {
        var spawned = 0
        for (s in shards) {
            if (!s.active) {
                val angle = Random.nextFloat() * (2f * PI.toFloat())
                val speed = 220f + Random.nextFloat() * 440f
                s.x = x
                s.y = y
                s.vx = cos(angle) * speed
                s.vy = sin(angle) * speed
                s.life = 0.65f + Random.nextFloat() * 0.35f
                s.colorIndex = colorIndex
                s.active = true
                spawned++
                if (spawned >= count) break
            }
        }
    }
}
