package com.example.sensory

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import kotlin.concurrent.thread
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin

class ProceduralSynthEngine {

    private class Voice(
        var active: Boolean = false,
        var freqHz: Float = 440f,
        var targetFreqHz: Float = 440f,
        var phase: Double = 0.0,
        var subPhase: Double = 0.0,
        var envTime: Float = 0f,
        var duration: Float = 0.35f,
        var amplitude: Float = 0.25f,
        var harmonicMix: Float = 0.3f,
        var fmDepth: Float = 0f
    )

    private val sampleRate = 24000
    private val voices = Array(14) { Voice() }
    private val voiceLock = Any()

    @Volatile
    var isEnabled: Boolean = true

    @Volatile
    private var running = true
    private var audioThread: Thread? = null

    init {
        startSynthThread()
    }

    private fun startSynthThread() {
        audioThread = thread(start = true, isDaemon = true, name = "VoidPulseSynth") {
            var track: AudioTrack? = null
            try {
                val minBuf = AudioTrack.getMinBufferSize(
                    sampleRate,
                    AudioFormat.CHANNEL_OUT_MONO,
                    AudioFormat.ENCODING_PCM_16BIT
                ).coerceAtLeast(1024)

                track = AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_GAME)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                            .build()
                    )
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(sampleRate)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                            .build()
                    )
                    .setBufferSizeInBytes(minBuf * 2)
                    .setTransferMode(AudioTrack.MODE_STREAM)
                    .build()

                track.play()

                val chunkSize = 256
                val buffer = ShortArray(chunkSize)
                val dt = 1f / sampleRate.toFloat()
                val twoPi = 2.0 * PI

                while (running) {
                    if (!isEnabled) {
                        buffer.fill(0)
                        track.write(buffer, 0, chunkSize)
                        Thread.sleep(16)
                        continue
                    }

                    synchronized(voiceLock) {
                        for (i in 0 until chunkSize) {
                            var mix = 0f
                            for (vIndex in voices.indices) {
                                val v = voices[vIndex]
                                if (!v.active) continue

                                v.envTime += dt
                                if (v.envTime >= v.duration) {
                                    v.active = false
                                    continue
                                }

                                // Smooth frequency glide
                                v.freqHz += (v.targetFreqHz - v.freqHz) * 0.008f

                                // Attack + exponential decay envelope
                                val attack = (v.envTime / 0.006f).coerceAtMost(1f)
                                val decay = exp((-5.2f * v.envTime / v.duration).toDouble()).toFloat()
                                val env = attack * decay * v.amplitude

                                val mod = if (v.fmDepth > 0f) {
                                    sin(v.subPhase) * v.fmDepth
                                } else {
                                    0.0
                                }

                                val fundamental = sin(v.phase + mod).toFloat()
                                val octave = sin(v.phase * 2.0).toFloat() * v.harmonicMix
                                val fifth = sin(v.phase * 1.498).toFloat() * (v.harmonicMix * 0.45f)

                                mix += (fundamental + octave + fifth) * env

                                v.phase += twoPi * v.freqHz / sampleRate
                                if (v.phase > twoPi) v.phase -= twoPi
                                v.subPhase += twoPi * (v.freqHz * 0.5) / sampleRate
                                if (v.subPhase > twoPi) v.subPhase -= twoPi
                            }

                            // Soft saturation limiter
                            val clamped = (mix / (1f + kotlin.math.abs(mix * 0.65f))).coerceIn(-0.95f, 0.95f)
                            buffer[i] = (clamped * Short.MAX_VALUE).toInt().toShort()
                        }
                    }

                    track.write(buffer, 0, chunkSize)
                }
            } catch (_: Throwable) {
                // Safe fallback in headless/test environments without audio hardware
            } finally {
                try {
                    track?.stop()
                    track?.release()
                } catch (_: Throwable) {
                }
            }
        }
    }

    private fun allocateVoice(
        freqHz: Float,
        targetFreqHz: Float = freqHz,
        duration: Float = 0.35f,
        amplitude: Float = 0.20f,
        harmonicMix: Float = 0.30f,
        fmDepth: Float = 0f
    ) {
        if (!isEnabled) return
        synchronized(voiceLock) {
            var target = voices.firstOrNull { !it.active }
            if (target == null) {
                target = voices.maxByOrNull { it.envTime / it.duration } ?: voices[0]
            }
            target.active = true
            target.freqHz = freqHz
            target.targetFreqHz = targetFreqHz
            target.phase = 0.0
            target.subPhase = 0.0
            target.envTime = 0f
            target.duration = duration
            target.amplitude = amplitude
            target.harmonicMix = harmonicMix
            target.fmDepth = fmDepth
        }
    }

    private var lastChimeMs = 0L

    fun triggerHarmonicChime(scale: FloatArray, normalizedY: Float, velocityBoost: Float = 0f) {
        if (!isEnabled || scale.isEmpty()) return
        val now = System.currentTimeMillis()
        if (now - lastChimeMs < 55L) return
        lastChimeMs = now

        val index = ((1f - normalizedY.coerceIn(0f, 1f)) * (scale.size - 1)).toInt()
            .coerceIn(0, scale.lastIndex)
        val baseFreq = scale[index] * (1f + velocityBoost.coerceIn(0f, 0.25f) * 0.5f)
        allocateVoice(
            freqHz = baseFreq,
            targetFreqHz = baseFreq * 1.005f,
            duration = 0.42f,
            amplitude = 0.16f,
            harmonicMix = 0.38f,
            fmDepth = 0.4f
        )
    }

    private var lastBassMs = 0L

    fun triggerBassPulse(intensity: Float = 1f) {
        if (!isEnabled) return
        val now = System.currentTimeMillis()
        if (now - lastBassMs < 110L) return
        lastBassMs = now

        val startFreq = 92f + 28f * intensity.coerceIn(0f, 1.5f)
        allocateVoice(
            freqHz = startFreq,
            targetFreqHz = 48f,
            duration = 0.38f,
            amplitude = (0.26f * intensity).coerceIn(0.10f, 0.34f),
            harmonicMix = 0.18f,
            fmDepth = 1.4f
        )
    }

    fun triggerCrispUiClick(pitchMultiplier: Float = 1f) {
        if (!isEnabled) return
        allocateVoice(
            freqHz = 980f * pitchMultiplier,
            targetFreqHz = 1420f * pitchMultiplier,
            duration = 0.065f,
            amplitude = 0.22f,
            harmonicMix = 0.5f,
            fmDepth = 0.8f
        )
        allocateVoice(
            freqHz = 1650f * pitchMultiplier,
            targetFreqHz = 820f * pitchMultiplier,
            duration = 0.045f,
            amplitude = 0.15f,
            harmonicMix = 0.2f
        )
    }

    fun triggerEpicModesButtonSound() {
        if (!isEnabled) return
        // Warm sub-bass impact + shimmering pentatonic triad chord
        allocateVoice(freqHz = 110f, targetFreqHz = 55f, duration = 0.36f, amplitude = 0.28f, harmonicMix = 0.2f, fmDepth = 1.2f)
        allocateVoice(freqHz = 440f, targetFreqHz = 442f, duration = 0.45f, amplitude = 0.18f, harmonicMix = 0.45f)
        allocateVoice(freqHz = 554.37f, targetFreqHz = 556f, duration = 0.52f, amplitude = 0.16f, harmonicMix = 0.45f)
        allocateVoice(freqHz = 659.25f, targetFreqHz = 662f, duration = 0.60f, amplitude = 0.16f, harmonicMix = 0.55f)
        allocateVoice(freqHz = 880f, targetFreqHz = 1320f, duration = 0.28f, amplitude = 0.14f, harmonicMix = 0.6f, fmDepth = 0.6f)
    }

    fun triggerCoinCollectSound() {
        if (!isEnabled) return
        allocateVoice(
            freqHz = 1046.5f,
            targetFreqHz = 1567.98f,
            duration = 0.18f,
            amplitude = 0.15f,
            harmonicMix = 0.55f
        )
    }

    fun triggerUnlockFanfare() {
        if (!isEnabled) return
        val notes = floatArrayOf(523.25f, 659.25f, 783.99f, 1046.50f, 1318.51f)
        notes.forEachIndexed { idx, freq ->
            allocateVoice(
                freqHz = freq * (0.98f + idx * 0.005f),
                targetFreqHz = freq,
                duration = 0.35f + idx * 0.12f,
                amplitude = 0.18f,
                harmonicMix = 0.5f,
                fmDepth = 0.35f
            )
        }
        allocateVoice(freqHz = 130.81f, targetFreqHz = 65.41f, duration = 0.55f, amplitude = 0.28f, harmonicMix = 0.25f, fmDepth = 1.5f)
    }

    fun release() {
        running = false
    }
}
