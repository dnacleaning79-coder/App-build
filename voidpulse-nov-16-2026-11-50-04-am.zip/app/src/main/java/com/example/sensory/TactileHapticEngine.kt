package com.example.sensory

import android.content.Context
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager

class TactileHapticEngine(context: Context) {

    private val vibrator: Vibrator? = try {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val manager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
            manager?.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        }
    } catch (_: Throwable) {
        null
    }

    @Volatile
    var isEnabled: Boolean = true

    private var lastCollisionTickMs = 0L
    private var lastVortexPulseMs = 0L

    fun tickParticleCollision(intensity: Float = 0.6f) {
        if (!isEnabled) return
        val now = System.currentTimeMillis()
        if (now - lastCollisionTickMs < 42L) return
        lastCollisionTickMs = now

        val amp = (intensity.coerceIn(0.15f, 1f) * 155).toInt().coerceIn(25, 255)
        vibrateOneShot(durationMs = 8L, amplitude = amp)
    }

    fun pulseVortexTouch(strength: Float = 0.8f) {
        if (!isEnabled) return
        val now = System.currentTimeMillis()
        if (now - lastVortexPulseMs < 75L) return
        lastVortexPulseMs = now

        val amp = (strength.coerceIn(0.25f, 1f) * 210).toInt().coerceIn(45, 255)
        vibrateOneShot(durationMs = 16L, amplitude = amp)
    }

    fun snapUiButton() {
        if (!isEnabled) return
        vibrateWaveform(
            timings = longArrayOf(0L, 12L, 24L, 8L),
            amplitudes = intArrayOf(0, 210, 0, 120)
        )
    }

    fun epicModesButtonCascade() {
        if (!isEnabled) return
        vibrateWaveform(
            timings = longArrayOf(0L, 14L, 22L, 18L, 28L, 32L),
            amplitudes = intArrayOf(0, 150, 0, 220, 0, 255)
        )
    }

    fun coinHarvestTick() {
        if (!isEnabled) return
        vibrateWaveform(
            timings = longArrayOf(0L, 7L, 18L, 11L),
            amplitudes = intArrayOf(0, 125, 0, 195)
        )
    }

    fun celebrateUnlock() {
        if (!isEnabled) return
        vibrateWaveform(
            timings = longArrayOf(0L, 18L, 30L, 22L, 30L, 28L, 35L, 55L),
            amplitudes = intArrayOf(0, 140, 0, 185, 0, 225, 0, 255)
        )
    }

    private fun vibrateOneShot(durationMs: Long, amplitude: Int) {
        val vib = vibrator ?: return
        try {
            if (!vib.hasVibrator()) return
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vib.vibrate(VibrationEffect.createOneShot(durationMs, amplitude.coerceIn(1, 255)))
            } else {
                @Suppress("DEPRECATION")
                vib.vibrate(durationMs)
            }
        } catch (_: Throwable) {
        }
    }

    private fun vibrateWaveform(timings: LongArray, amplitudes: IntArray) {
        val vib = vibrator ?: return
        try {
            if (!vib.hasVibrator()) return
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vib.vibrate(VibrationEffect.createWaveform(timings, amplitudes, -1))
            } else {
                @Suppress("DEPRECATION")
                vib.vibrate(25L)
            }
        } catch (_: Throwable) {
        }
    }
}
