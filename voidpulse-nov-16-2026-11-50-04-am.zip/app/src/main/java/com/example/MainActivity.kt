package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.offset
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.components.AmoledParticleCanvas
import com.example.ui.components.EpicBottomControlDeck
import com.example.ui.components.FloatingKineticTopHud
import com.example.ui.components.KineticVaultOverlay
import com.example.ui.theme.AmoledBlack
import com.example.ui.theme.FluxGold
import com.example.ui.theme.MyApplicationTheme
import com.example.viewmodel.ParticleSandboxViewModel
import kotlin.math.roundToInt

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                VoidPulseSandboxScreen()
            }
        }
    }
}

@Composable
fun VoidPulseSandboxScreen(
    viewModel: ParticleSandboxViewModel = viewModel(
        factory = ParticleSandboxViewModel.Factory(LocalContext.current)
    )
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val density = LocalDensity.current

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(AmoledBlack)
    ) {
        // 1. Full-Bleed True-Black AMOLED Interactive Particle Canvas
        AmoledParticleCanvas(
            engine = viewModel.particleEngine,
            mode = uiState.activeMode,
            palette = uiState.activePalette,
            forceLevel = uiState.profile.gravityAmplifierLevel,
            harvesterLevel = uiState.profile.coinHarvesterLevel,
            targetParticleCount = uiState.activeParticleTargetCount,
            trailsEnabled = uiState.profile.trailsEnabled,
            onTouchDown = viewModel::onTouchDown,
            onTouchMove = viewModel::onTouchMove,
            onTouchUp = viewModel::onTouchUp,
            onCoinCollected = viewModel::onStepCoinEarned,
            onCollisionPulse = viewModel::onCollisionHaptic,
            modifier = Modifier.fillMaxSize()
        )

        // 2. Floating Coin Popups on Canvas
        uiState.floatingGains.forEach { gain ->
            Box(
                modifier = Modifier.offset {
                    IntOffset(
                        x = (gain.x - with(density) { 28.dp.toPx() }).roundToInt(),
                        y = (gain.y - with(density) { 36.dp.toPx() }).roundToInt()
                    )
                }
            ) {
                Text(
                    text = "+${gain.amount}",
                    style = MaterialTheme.typography.titleMedium.copy(
                        color = FluxGold,
                        fontWeight = FontWeight.Bold
                    )
                )
            }
        }

        // 3. Top Kinetic HUD (Flux Coins, Kinetic Multiplier, Sensory Toggles)
        FloatingKineticTopHud(
            coins = uiState.profile.coins,
            coinPulseSeq = uiState.coinPulseSeq,
            kineticMultiplier = viewModel.particleEngine.kineticMultiplier,
            activeMode = uiState.activeMode,
            activePalette = uiState.activePalette,
            soundEnabled = uiState.profile.soundEnabled,
            hapticsEnabled = uiState.profile.hapticsEnabled,
            trailsEnabled = uiState.profile.trailsEnabled,
            bannerMessage = uiState.bannerMessage,
            onToggleSound = viewModel::onToggleSound,
            onToggleHaptics = viewModel::onToggleHaptics,
            onToggleTrails = viewModel::onToggleTrails,
            onCoinPillClicked = viewModel::onOpenModesVault,
            modifier = Modifier.align(Alignment.TopCenter)
        )

        // 4. Bottom Control Deck with Epic Modes & Vault Button + Nova Burst
        EpicBottomControlDeck(
            activeMode = uiState.activeMode,
            affordableUnlocksCount = uiState.affordableUnlocksCount,
            modesButtonPulseCount = uiState.modesButtonPulseCount,
            onQuickSwapMode = viewModel::onQuickCycleNextMode,
            onOpenModesVault = viewModel::onOpenModesVault,
            onTriggerNovaBurst = viewModel::onTriggerNovaBurst,
            modifier = Modifier.align(Alignment.BottomCenter)
        )

        // 5. Kinetic Vault Sheet Overlay (Modes, AMOLED Palettes, Upgrades)
        AnimatedVisibility(
            visible = uiState.isVaultOpen,
            enter = fadeIn() + slideInVertically { it / 2 },
            exit = fadeOut() + slideOutVertically { it / 2 },
            modifier = Modifier.align(Alignment.BottomCenter)
        ) {
            KineticVaultOverlay(
                profile = uiState.profile,
                activeMode = uiState.activeMode,
                activePalette = uiState.activePalette,
                selectedTab = uiState.selectedVaultTab,
                onSelectTab = viewModel::onSelectVaultTab,
                onModeAction = viewModel::onModeCardAction,
                onPaletteAction = viewModel::onPaletteCardAction,
                onUpgradeAction = viewModel::onPurchaseUpgrade,
                onClose = viewModel::onCloseModesVault
            )
        }
    }
}
