package com.example.viewmodel

import android.content.Context
import androidx.compose.ui.geometry.Offset
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.PlayerProfileEntity
import com.example.data.PlayerRepository
import com.example.data.VoidPulseDatabase
import com.example.model.AmoledPalette
import com.example.model.KineticUpgradeType
import com.example.model.ParticleMode
import com.example.physics.AmoledParticleEngine
import com.example.sensory.ProceduralSynthEngine
import com.example.sensory.TactileHapticEngine
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class FloatingCoinGain(
    val id: Long,
    val amount: Long,
    val x: Float,
    val y: Float
)

data class SandboxUiState(
    val profile: PlayerProfileEntity = PlayerProfileEntity(),
    val activeMode: ParticleMode = ParticleMode.BLACK_HOLE,
    val activePalette: AmoledPalette = AmoledPalette.CYBER_NEON,
    val isVaultOpen: Boolean = false,
    val selectedVaultTab: Int = 0,
    val modesButtonPulseCount: Int = 0,
    val coinPulseSeq: Int = 0,
    val floatingGains: List<FloatingCoinGain> = emptyList(),
    val bannerMessage: String? = null
) {
    val activeParticleTargetCount: Int
        get() = 280 + (profile.particleDensityLevel - 1) * 85

    val affordableUnlocksCount: Int
        get() {
            val modeCount = ParticleMode.entries.count { !profile.isModeUnlocked(it) && profile.coins >= it.costCoins }
            val paletteCount = AmoledPalette.entries.count { !profile.isPaletteUnlocked(it) && profile.coins >= it.costCoins }
            val upgradeCount = KineticUpgradeType.entries.count {
                val lvl = profile.levelForUpgrade(it)
                lvl < it.maxLevel && profile.coins >= it.costForNextLevel(lvl)
            }
            return modeCount + paletteCount + upgradeCount
        }
}

class ParticleSandboxViewModel(
    private val repository: PlayerRepository,
    val synthEngine: ProceduralSynthEngine,
    val hapticEngine: TactileHapticEngine
) : ViewModel() {

    val particleEngine = AmoledParticleEngine(maxCapacity = 780)

    private val isVaultOpenFlow = MutableStateFlow(false)
    private val selectedVaultTabFlow = MutableStateFlow(0)
    private val modesButtonPulseFlow = MutableStateFlow(0)
    private val coinPulseSeqFlow = MutableStateFlow(0)
    private val floatingGainsFlow = MutableStateFlow<List<FloatingCoinGain>>(emptyList())
    private val bannerMessageFlow = MutableStateFlow<String?>(null)

    private var gainIdCounter = 1L

    init {
        viewModelScope.launch {
            val initial = repository.ensureInitialized()
            synthEngine.isEnabled = initial.soundEnabled
            hapticEngine.isEnabled = initial.hapticsEnabled
        }
    }

    val uiState: StateFlow<SandboxUiState> = combine(
        repository.profileFlow,
        isVaultOpenFlow,
        selectedVaultTabFlow,
        modesButtonPulseFlow,
        combine(coinPulseSeqFlow, floatingGainsFlow, bannerMessageFlow) { seq, gains, banner ->
            Triple(seq, gains, banner)
        }
    ) { profileOrNull, vaultOpen, tabIndex, btnPulse, triple ->
        val profile = profileOrNull ?: PlayerProfileEntity()
        val mode = ParticleMode.fromId(profile.selectedModeId)
        val palette = AmoledPalette.fromId(profile.selectedPaletteId)
        synthEngine.isEnabled = profile.soundEnabled
        hapticEngine.isEnabled = profile.hapticsEnabled
        particleEngine.updateTargetCount(280 + (profile.particleDensityLevel - 1) * 85)

        SandboxUiState(
            profile = profile,
            activeMode = mode,
            activePalette = palette,
            isVaultOpen = vaultOpen,
            selectedVaultTab = tabIndex,
            modesButtonPulseCount = btnPulse,
            coinPulseSeq = triple.first,
            floatingGains = triple.second,
            bannerMessage = triple.third
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = SandboxUiState()
    )

    fun onTouchDown(slotIndex: Int, x: Float, y: Float, normalizedY: Float) {
        val slot = particleEngine.touchPoints.getOrNull(slotIndex) ?: return
        slot.x = x
        slot.y = y
        slot.prevX = x
        slot.prevY = y
        slot.holdTimeSec = 0f
        slot.active = true

        val mode = uiState.value.activeMode
        particleEngine.spawnShockwave(x, y, maxRadius = 290f, colorIndex = slotIndex % 4)
        synthEngine.triggerBassPulse(intensity = 0.85f)
        synthEngine.triggerHarmonicChime(mode.scaleHz, normalizedY, velocityBoost = 0.1f)
        hapticEngine.pulseVortexTouch(strength = 0.85f)
    }

    fun onTouchMove(slotIndex: Int, x: Float, y: Float, normalizedY: Float) {
        val slot = particleEngine.touchPoints.getOrNull(slotIndex) ?: return
        val dx = x - slot.x
        val dy = y - slot.y
        val dist = kotlin.math.hypot(dx, dy)
        slot.x = x
        slot.y = y
        slot.active = true

        if (dist > 14f) {
            val velocityBoost = (dist / 120f).coerceIn(0f, 0.35f)
            synthEngine.triggerHarmonicChime(uiState.value.activeMode.scaleHz, normalizedY, velocityBoost)
            hapticEngine.pulseVortexTouch(strength = (0.35f + velocityBoost).coerceAtMost(0.95f))
        }
    }

    fun onTouchUp(slotIndex: Int) {
        val slot = particleEngine.touchPoints.getOrNull(slotIndex) ?: return
        if (slot.active) {
            val heldLong = slot.holdTimeSec > 0.28f
            slot.active = false
            if (heldLong || uiState.value.activeMode == ParticleMode.BLACK_HOLE) {
                particleEngine.triggerSupernovaBurst(
                    centerX = slot.x,
                    centerY = slot.y,
                    powerMultiplier = 0.72f + (uiState.value.profile.gravityAmplifierLevel - 1) * 0.15f
                )
                synthEngine.triggerBassPulse(intensity = 1.0f)
                hapticEngine.snapUiButton()
            }
        }
    }

    fun onStepCoinEarned(amount: Long, position: Offset) {
        if (amount <= 0L) return
        synthEngine.triggerCoinCollectSound()
        hapticEngine.coinHarvestTick()
        coinPulseSeqFlow.value += 1

        val gainId = gainIdCounter++
        val newGain = FloatingCoinGain(id = gainId, amount = amount, x = position.x, y = position.y)
        floatingGainsFlow.value = (floatingGainsFlow.value + newGain).takeLast(6)

        viewModelScope.launch {
            repository.addCoins(amount)
            delay(850L)
            floatingGainsFlow.value = floatingGainsFlow.value.filterNot { it.id == gainId }
        }
    }

    fun onCollisionHaptic(intensity: Float) {
        hapticEngine.tickParticleCollision(intensity)
    }

    fun onOpenModesVault() {
        modesButtonPulseCountIncrement()
        synthEngine.triggerEpicModesButtonSound()
        hapticEngine.epicModesButtonCascade()
        particleEngine.spawnShockwave(
            x = particleEngine.canvasWidth * 0.5f,
            y = particleEngine.canvasHeight * 0.88f,
            maxRadius = 750f,
            colorIndex = 0
        )
        isVaultOpenFlow.value = true
    }

    fun onCloseModesVault() {
        synthEngine.triggerCrispUiClick(0.88f)
        hapticEngine.snapUiButton()
        isVaultOpenFlow.value = false
    }

    fun onSelectVaultTab(tabIndex: Int) {
        synthEngine.triggerCrispUiClick(1.0f + tabIndex * 0.12f)
        hapticEngine.snapUiButton()
        selectedVaultTabFlow.value = tabIndex
    }

    fun onQuickCycleNextMode() {
        modesButtonPulseCountIncrement()
        val currentState = uiState.value
        val allModes = ParticleMode.entries
        val currentIdx = allModes.indexOf(currentState.activeMode)
        // Find next unlocked mode, or if only 1 mode is unlocked, open the Vault so user can unlock more!
        val unlockedModes = allModes.filter { currentState.profile.isModeUnlocked(it) }
        if (unlockedModes.size <= 1) {
            showBanner("Unlock Slime Bounce, Laser Shatter & Galaxy Swirl in the Vault!")
            onOpenModesVault()
            return
        }
        val nextUnlocked = allModes
            .drop(currentIdx + 1)
            .plus(allModes.take(currentIdx + 1))
            .first { currentState.profile.isModeUnlocked(it) }

        viewModelScope.launch {
            repository.selectOrUnlockMode(nextUnlocked)
            synthEngine.triggerEpicModesButtonSound()
            hapticEngine.epicModesButtonCascade()
            particleEngine.triggerSupernovaBurst(
                centerX = particleEngine.canvasWidth * 0.5f,
                cityY = particleEngine.canvasHeight * 0.5f
            )
            showBanner("Switched to ${nextUnlocked.title} Mode")
        }
    }

    private fun AmoledParticleEngine.triggerSupernovaBurst(centerX: Float, cityY: Float) {
        this.triggerSupernovaBurst(centerX, cityY, 1.0f)
    }

    fun onModeCardAction(mode: ParticleMode) {
        viewModelScope.launch {
            val profile = uiState.value.profile
            val wasUnlocked = profile.isModeUnlocked(mode)
            if (!wasUnlocked && profile.coins < mode.costCoins) {
                synthEngine.triggerCrispUiClick(0.65f)
                hapticEngine.snapUiButton()
                showBanner("Need ${mode.costCoins - profile.coins} more Flux Coins to unlock ${mode.title}!")
                return@launch
            }

            val newlyUnlocked = repository.selectOrUnlockMode(mode)
            if (newlyUnlocked) {
                synthEngine.triggerUnlockFanfare()
                hapticEngine.celebrateUnlock()
                showBanner("UNLOCKED ${mode.title.uppercase()} MODE!")
            } else {
                synthEngine.triggerEpicModesButtonSound()
                hapticEngine.snapUiButton()
                showBanner("${mode.title} Mode Active")
            }
            particleEngine.triggerSupernovaBurst(
                centerX = particleEngine.canvasWidth * 0.5f,
                centerY = particleEngine.canvasHeight * 0.5f,
                powerMultiplier = 1.15f
            )
        }
    }

    fun onPaletteCardAction(palette: AmoledPalette) {
        viewModelScope.launch {
            val profile = uiState.value.profile
            val wasUnlocked = profile.isPaletteUnlocked(palette)
            if (!wasUnlocked && profile.coins < palette.costCoins) {
                synthEngine.triggerCrispUiClick(0.65f)
                hapticEngine.snapUiButton()
                showBanner("Need ${palette.costCoins - profile.coins} more Flux Coins for ${palette.title}!")
                return@launch
            }

            val newlyUnlocked = repository.selectOrUnlockPalette(palette)
            if (newlyUnlocked) {
                synthEngine.triggerUnlockFanfare()
                hapticEngine.celebrateUnlock()
                showBanner("Unlocked ${palette.title} AMOLED Palette!")
            } else {
                synthEngine.triggerCrispUiClick(1.18f)
                hapticEngine.snapUiButton()
                showBanner("Equipped ${palette.title} Palette")
            }
            particleEngine.spawnShockwave(
                x = particleEngine.canvasWidth * 0.5f,
                y = particleEngine.canvasHeight * 0.5f,
                maxRadius = 720f,
                colorIndex = 1
            )
        }
    }

    fun onPurchaseUpgrade(type: KineticUpgradeType) {
        viewModelScope.launch {
            val profile = uiState.value.profile
            val currentLvl = profile.levelForUpgrade(type)
            if (currentLvl >= type.maxLevel) return@launch
            val cost = type.costForNextLevel(currentLvl)
            if (profile.coins < cost) {
                synthEngine.triggerCrispUiClick(0.65f)
                hapticEngine.snapUiButton()
                showBanner("Need ${cost - profile.coins} more Flux Coins for ${type.title}!")
                return@launch
            }

            val success = repository.purchaseUpgrade(type)
            if (success) {
                synthEngine.triggerUnlockFanfare()
                hapticEngine.celebrateUnlock()
                showBanner("${type.title} upgraded to Lv.${currentLvl + 1}!")
            }
        }
    }

    fun onTriggerNovaBurst() {
        synthEngine.triggerEpicModesButtonSound()
        hapticEngine.epicModesButtonCascade()
        val w = particleEngine.canvasWidth
        val h = particleEngine.canvasHeight
        particleEngine.triggerSupernovaBurst(
            centerX = w * 0.5f,
            centerY = h * 0.5f,
            powerMultiplier = 1.25f + (uiState.value.profile.gravityAmplifierLevel - 1) * 0.2f
        )
        onStepCoinEarned(
            amount = 5L + uiState.value.profile.coinHarvesterLevel * 2L,
            position = Offset(w * 0.5f, h * 0.45f)
        )
    }

    fun onToggleSound() {
        viewModelScope.launch {
            val enabled = repository.toggleSound()
            synthEngine.isEnabled = enabled
            if (enabled) synthEngine.triggerCrispUiClick(1.1f)
            hapticEngine.snapUiButton()
        }
    }

    fun onToggleHaptics() {
        viewModelScope.launch {
            val enabled = repository.toggleHaptics()
            hapticEngine.isEnabled = enabled
            synthEngine.triggerCrispUiClick(1.05f)
            if (enabled) hapticEngine.snapUiButton()
        }
    }

    fun onToggleTrails() {
        viewModelScope.launch {
            repository.toggleTrails()
            synthEngine.triggerCrispUiClick(1.15f)
            hapticEngine.snapUiButton()
        }
    }

    private fun modesButtonPulseCountIncrement() {
        modesButtonPulseFlow.value += 1
    }

    private fun showBanner(message: String) {
        bannerMessageFlow.value = message
        viewModelScope.launch {
            delay(2400L)
            if (bannerMessageFlow.value == message) {
                bannerMessageFlow.value = null
            }
        }
    }

    override fun onCleared() {
        super.onCleared()
        synthEngine.release()
    }

    class Factory(private val context: Context) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            val db = VoidPulseDatabase.getInstance(context)
            val repo = PlayerRepository(db.playerProfileDao())
            val synth = ProceduralSynthEngine()
            val haptics = TactileHapticEngine(context.applicationContext)
            return ParticleSandboxViewModel(repo, synth, haptics) as T
        }
    }
}
